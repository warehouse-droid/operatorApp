# Local Docker runtime

The Docker environment files and database backups in this folder are ignored by Git.

Prepare the runtime environment without printing secrets:

```powershell
node docker/prepare-env.mjs
```

All Compose commands must use the generated environment file:

```powershell
docker compose --env-file docker/env/.env up -d db
docker compose --env-file docker/env/.env --profile tools run --rm bootstrap-data
docker compose --env-file docker/env/.env --profile tools run --rm migrate
docker compose --env-file docker/env/.env up -d ollama
docker compose --env-file docker/env/.env --profile tools run --rm ollama-pull
docker compose --env-file docker/env/.env up -d app
```

The app defaults to `http://localhost:3001`. For cutover, set `MBBS_APP_HOST_PORT=3000` in `docker/env/.env` and recreate the app container after the host Node server is stopped.

Use the helper to change the persistent host port without exposing or replacing secrets:

```powershell
node docker/set-host-port.mjs 3000
docker compose --env-file docker/env/.env up -d --force-recreate app
```

Create an ignored custom-format PostgreSQL backup:

```powershell
powershell -ExecutionPolicy Bypass -File docker/backup-docker-db.ps1
```

Normal operation:

```powershell
docker compose --env-file docker/env/.env ps
docker compose --env-file docker/env/.env logs -f app
docker compose --env-file docker/env/.env restart app
docker compose --env-file docker/env/.env down
docker compose --env-file docker/env/.env up -d
```

## VM update

From the repository root on the Ubuntu VM, run the automated updater:

```bash
bash docker/update-vm.sh
```

The updater creates a PostgreSQL backup, pulls `origin/codex/dockerVer`, builds the
new images, stops only the app, applies migrations, recreates the app container,
and verifies the configured host port with `/health`.

Optional overrides:

```bash
BRANCH=codex/dockerVer bash docker/update-vm.sh
HEALTH_URL=http://127.0.0.1:3000/health bash docker/update-vm.sh
SKIP_BACKUP=1 bash docker/update-vm.sh
```

The script intentionally stops if the VM Git worktree contains local changes.
Commit or stash those changes before running it.

Do not use `docker compose down -v` during normal operation because `-v` deletes the PostgreSQL, app-data, and Ollama model volumes.

## Independent localhost:3099

The secondary Docker project uses the same working tree with
`docker-compose.v2.yml`, loads `docker/env/.env.old`, and binds to
`http://127.0.0.1:3099`. It does not use the retired NetSuite relay network.

```bash
docker compose -f docker-compose.yml -f docker-compose.v2.yml build app
docker compose -f docker-compose.yml -f docker-compose.v2.yml run --rm --no-deps app npm run migrate
docker compose -f docker-compose.yml -f docker-compose.v2.yml up -d --force-recreate app
```

See `docs/dispatch-v2-local.md` for the environment contract and isolation checks.
