import crypto from "node:crypto";
import { applyPendingDispatchPlanMaintenance } from "./dispatch-plan-maintenance.js";

import { query, withTransaction } from "./db.js";
import { persistedDispatchPlan } from './dispatch-plan-fence.js';
import { lockDispatchPlanEditLease, assertDispatchPlanEditLease } from './dispatch-plan-lease-repository.js';
import { assertSalesDeliveryPlanningAllowed, fulfilledSalesDeliveryPlanningRefs } from "./dispatch-fulfilled-so-repository.js";
import { canonicalizeDispatchCoGroupIdentities } from "./dispatch-co-group-identity.js";
import {
  deactivateDispatchGlobalOrderDefinitions,
  reconcileDispatchPlanGlobalOrderDefinitions,
  syncDispatchDeliveryGroupsFromPlan
} from "./dispatch-delivery-group-repository.js";
import {
  assertActiveDispatchCosForPlan,
  reconcileDispatchPlanLocalCos
} from "./dispatch-co-lifecycle.js";
import { DISPATCH_FLEET_PLANNING_LOCK } from "./dispatch-fleet-status.js";
import { dispatchLoadAssignment } from "./dispatch-load-assignment.js";
import { materializeDispatchPickupVisits } from "./dispatch-pickup-visits.js";
import {
  dispatchPlannedAssignmentMap,
  dispatchPlanV2Summary,
  refreshDispatchPlanAuthoritativeOrderProjection,
  scrubBilledSalesOrderFamiliesFromPlan
} from "./dispatch-plan-repository.js";
import {
  applyDispatchPlanDelta,
  dispatchCheckpointDecision,
  dispatchCheckpointRetention,
  extractDispatchOrderRelationEdges
} from "./dispatch-planner-optimization.js";
import {
  assertHistoricalInactiveSalesOrdersReconciled,
  assertNoDriverPwaCompletedDispatchRefs
} from "./dispatch-history-mode.js";
import {
  assertNoClosedNetSuiteOrders,
  scrubClosedNetSuiteOrdersFromOperationalPlan
} from "./netsuite-closed-order-repository.js";
import { operationalPlanOrderRefs } from "./netsuite-closed-order-policy.js";
import {
  applyDispatchPlanMutation,
  assertDispatchPlanFence,
  buildCompactDispatchSnapshot,
  digestDispatchPlan,
  dispatchPlanBoard,
  evaluateExecutedPrefixPolicy
} from "./dispatch-planner-performance.js";

const SNAPSHOT_SCHEMA_VERSION = 2;
const DISPATCH_COMPANY_TIME_ZONE = "America/Toronto";
const SNAPSHOT_SUMMARY_REPAIR_SOURCE = "dispatchV2-schema-repair";
const SNAPSHOT_SUMMARY_SAVE_SOURCE = "dispatchV2-save";
const MISSING_V2_SUMMARY_MARKER_SQL = `COALESCE(
  CASE
    WHEN (s.summary #>> '{dispatchPlanFormat,version}') ~ '^[0-9]+$'
      THEN (s.summary #>> '{dispatchPlanFormat,version}')::int
    ELSE 0
  END,
  0
) < 2`;

function text(value) {
  return String(value ?? "").trim();
}

function planDate(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {return value.toISOString().slice(0, 10);}
  return text(value).slice(0, 10);
}

function dispatchCompanyDate(value = new Date()) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-CA", {
    timeZone: DISPATCH_COMPANY_TIME_ZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(value).map((part) => [part.type, part.value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function snapshotMarkerTimestamp(row = {}) {
  const value = row.saved_at || row.original_saved_at || row.archived_at || row.created_at || row.updated_at;
  if (value instanceof Date && !Number.isNaN(value.getTime())) {return value.toISOString();}
  return text(value) || new Date().toISOString();
}

function stableValue(value) {
  if (Array.isArray(value)) {return value.map(stableValue);}
  if (!value || typeof value !== "object") {return value;}
  const ordered = Object.create(null);
  for (const key of Object.keys(value).sort((left, right) => left.localeCompare(right))) {
    if (value[key] !== undefined) {ordered[key] = stableValue(value[key]);}
  }
  return ordered;
}

function requestHash(command = {}) {
  const submittedHash = text(command.sourceRequestHash).toLowerCase();
  if (/^[a-f0-9]{64}$/u.test(submittedHash)) {return submittedHash;}
  return crypto.createHash("sha256").update(JSON.stringify(stableValue({
    commandId: text(command.commandId),
    baseRevision: Number(command.baseRevision),
    baseDigest: text(command.baseDigest),
    commandType: text(command.commandType || command.type),
    payload: command.payload || {}
  }))).digest("hex");
}

function commandError(message, code, status = 409, details = {}) {
  return Object.assign(new Error(message), { code, status, ...details });
}

function rowPlan(row = {}) {
  const summary = row.summary && typeof row.summary === "object" ? row.summary : {};
  return canonicalizeDispatchCoGroupIdentities({
    digest: persistedDispatchPlan(row).digest,
    id: text(row.id || row.plan_id),
    planId: text(row.id || row.plan_id),
    planDate: planDate(row.plan_date),
    status: row.status || "draft",
    note: row.note || "",
    revision: Number(row.revision || 0),
    savedAt: row.saved_at || row.updated_at || null,
    orders: Array.isArray(row.orders) ? row.orders : [],
    trucks: Array.isArray(row.trucks) ? row.trucks : [],
    summary: Number(row.schema_version || 1) >= SNAPSHOT_SCHEMA_VERSION
      ? dispatchPlanV2Summary(summary, {
          source: SNAPSHOT_SUMMARY_REPAIR_SOURCE,
          migratedAt: snapshotMarkerTimestamp(row)
        })
      : summary
  });
}

function slimAssignedOrder(order = {}) {
  const keys = [
    "id", "orderId", "orderRef", "tranid", "refNumber", "type", "status", "statusText",
    "customOrderId", "customOrder", "localDispatchStatus", "orderKind", "systemManaged",
    "salesOrderReattempt", "parentSalesOrderId", "parentOrderRef", "reloadCycleId", "billingDisposition",
    "customer", "customerName", "address", "pickupAddress", "pickupAddressOverride",
    "sourceAddress", "defaultSourceAddress", "dropoffLocation", "pickupLocation",
    "pickupLocations", "sourceYard", "destinationYard", "destinationAddress", "destinationLocationId",
    "expectedDeliveryDate", "windowStart", "windowEnd", "items", "pallets", "layers",
    "salesQty", "salesQuantities", "committedQty", "packed", "weight", "totalWeightLbs",
    "unloadMinutes", "travelMinutes", "stopMinutes", "instructions", "notes",
    "originalOrderId", "sourceOrderId", "relatedSoId", "originalPoRef", "sourcePoRef",
    "sourcePoRefs", "correspondingPoRefs", "childOrders",
    "childOrderDetails", "groupAliases", "transitCo", "transitOriginalPickupLocations",
    "transitOriginalSourceYard", "directPickupManifest", "poPickupManifest", "poRouteProjection", "orderDependencies", "dependencyLabels",
    "dependencyDirectPickup", "dependencyWaitingForTransfer", "dependencyAttention",
    "dependencyUncovered", "dependencyUncoveredQuantity", "planOwned", "isSplit", "isGrouped",
    "groupPlanId", "groupPlanDate",
    "globalGroupDefinition", "globalGroupSourcePlanId", "globalGroupSourcePlanDate",
    "globalOrderDefinition", "globalOrderDefinitionKind", "globalOrderSourcePlanId", "globalOrderSourcePlanDate",
    "sourceTable", "netsuiteId", "dispatchRef", "dependency", "dependencies", "mbt",
    "historicalReconciliationComplete", "historicalPlanDate"
  ];
  const slim = Object.fromEntries(keys.filter((key) => order[key] !== undefined).map((key) => [key, order[key]]));
  const identity = text(slim.id);
  for (const duplicateKey of ["orderId", "orderRef", "tranid", "refNumber"]) {
    if (identity && text(slim[duplicateKey]) === identity) {delete slim[duplicateKey];}
  }
  return slim;
}

function publicPlan(plan = {}) {
  const compact = buildCompactDispatchSnapshot(plan);
  const digest = plan.digest || digestDispatchPlan(plan);
  return {
    exists: true,
    id: text(plan.id || plan.planId),
    planId: text(plan.id || plan.planId),
    planDate: planDate(plan.planDate),
    status: plan.status || "draft",
    note: plan.note || "",
    revision: Number(plan.revision || 0),
    savedAt: plan.savedAt || null,
    schemaVersion: SNAPSHOT_SCHEMA_VERSION,
    digest,
    summary: compact.summary || {},
    trucks: compact.trucks || [],
    assignedOrderSnapshots: (compact.orders || []).map(slimAssignedOrder),
    board: dispatchPlanBoard(compact)
  };
}

async function reconcileCancelledLocalCos(plan, options = {}) {
  return reconcileDispatchPlanLocalCos(await reconcileDispatchPlanGlobalOrderDefinitions(plan, options));
}

export async function syncDispatchPlanLoadProjection(plan = {}) {
  // The load projection depends on Driver route materialization, whose module
  // already participates in the Dispatch repository graph. Resolve it only at
  // operation time so V2 commands can keep both assignment projections in the
  // same transaction without introducing an ESM initialization cycle.
  const { syncDispatchPlanLoadAssignments } = await import("./dispatch-load-assignment-repository.js");
  return syncDispatchPlanLoadAssignments(plan, { allowBin: true });
}

async function selectPlan({ planId = "", date = "", lock = false, enrich = true } = {}) {
  const cleanId = text(planId);
  const cleanDate = planDate(date);
  const params = [];
  const clauses = [];
  if (cleanId) {
    params.push(cleanId);
    clauses.push(`p.id = $${params.length}`);
  }
  if (cleanDate) {
    params.push(cleanDate);
    clauses.push(`p.plan_date = $${params.length}::date`);
  }
  if (!clauses.length) {throw commandError("A plan ID or plan date is required.", "DISPATCH_PLAN_SELECTOR_REQUIRED", 400);}
  const result = await query(
    `SELECT p.id, p.plan_date::text AS plan_date, p.status, p.note, p.revision,
            p.created_at, p.updated_at, s.saved_at, s.orders, s.trucks, s.summary,
            s.schema_version
       FROM dispatch_plans p
       LEFT JOIN dispatch_plan_snapshots s ON s.plan_id = p.id
      WHERE ${clauses.join(" AND ")}
      LIMIT 1
      ${lock ? "FOR UPDATE OF p" : ""}`,
    params
  );
  if (!result.rows[0]) {return null;}
  if (!enrich) {return persistedDispatchPlan(result.rows[0]);}
  const reconciled = await reconcileCancelledLocalCos(rowPlan(result.rows[0]));
  return (await scrubClosedNetSuiteOrdersFromOperationalPlan(reconciled)).plan;
}

export async function getDispatchV2Bootstrap({ planId = "", date = "" } = {}) {
  const plan = await selectPlan({ planId, date });
  if (!plan) {
    return {
      exists: false,
      plan: {
        exists: false,
        id: null,
        planId: null,
        planDate: planDate(date),
        revision: 0,
        digest: "",
        schemaVersion: SNAPSHOT_SCHEMA_VERSION,
        trucks: [],
        assignedOrderSnapshots: [],
        board: { orderRefs: [], truckCount: 0, loadCount: 0, stopCount: 0 }
      }
    };
  }
  return { exists: true, plan: publicPlan(plan) };
}

export async function repairDispatchV2SummaryMarkers({
  planId = "",
  date = "",
  limit = 25
} = {}) {
  const selectedPlanId = text(planId);
  if (selectedPlanId && !/^\d+$/u.test(selectedPlanId)) {
    throw new TypeError("planId must be a positive integer.");
  }
  const selectedDate = planDate(date || dispatchCompanyDate());
  if (!selectedPlanId && !/^\d{4}-\d{2}-\d{2}$/u.test(selectedDate)) {
    throw new TypeError("date must use YYYY-MM-DD format.");
  }
  const safeLimit = Math.min(Math.max(Number(limit) || 25, 1), 100);
  return withTransaction(async () => {
    await query("SELECT pg_advisory_xact_lock(hashtext($1))", [DISPATCH_FLEET_PLANNING_LOCK]);
    const candidates = await query(
      `SELECT p.id, p.plan_date::text AS plan_date, p.status, p.note, p.revision,
              p.created_at, p.updated_at, s.saved_at, s.orders, s.trucks, s.summary,
              s.schema_version
         FROM dispatch_plans p
         JOIN dispatch_plan_snapshots s ON s.plan_id = p.id
        WHERE s.schema_version >= 2
          AND ${MISSING_V2_SUMMARY_MARKER_SQL}
          AND (
            ($1::bigint IS NOT NULL AND p.id = $1::bigint)
            OR ($1::bigint IS NULL AND p.plan_date = $2::date)
          )
        ORDER BY p.plan_date DESC, p.id DESC
        LIMIT $3
        FOR UPDATE OF p, s`,
      [selectedPlanId || null, selectedDate || null, safeLimit]
    );
    const repairedPlanIds = [];
    for (const row of candidates.rows) {
      const summary = dispatchPlanV2Summary(row.summary || {}, {
        source: SNAPSHOT_SUMMARY_REPAIR_SOURCE,
        migratedAt: snapshotMarkerTimestamp(row)
      });
      const repairedPlan = buildCompactDispatchSnapshot({
        id: text(row.id),
        planId: text(row.id),
        planDate: planDate(row.plan_date),
        status: row.status || "draft",
        note: row.note || "",
        revision: Number(row.revision || 0),
        orders: Array.isArray(row.orders) ? row.orders : [],
        trucks: Array.isArray(row.trucks) ? row.trucks : [],
        summary
      });
      const counts = snapshotCounts(repairedPlan);
      const updated = await query(
        `UPDATE dispatch_plan_snapshots s
            SET summary = $2::jsonb,
                plan_digest = $3,
                order_count = $4,
                truck_count = $5,
                load_count = $6,
                stop_count = $7
          WHERE s.plan_id = $1
            AND s.schema_version >= 2
            AND ${MISSING_V2_SUMMARY_MARKER_SQL}
          RETURNING s.plan_id::text AS plan_id`,
        [
          row.id,
          JSON.stringify(summary),
          digestDispatchPlan(repairedPlan),
          counts.orderCount,
          counts.truckCount,
          counts.loadCount,
          counts.stopCount
        ]
      );
      if (updated.rows[0]?.plan_id) {repairedPlanIds.push(updated.rows[0].plan_id);}
    }
    return {
      date: selectedDate,
      scanned: candidates.rows.length,
      repaired: repairedPlanIds.length,
      planIds: repairedPlanIds
    };
  });
}

async function existingReceipt(commandId, hash, planId = '') {
  const result = await query(
    `SELECT command_id, plan_id, request_hash, result
       FROM dispatch_plan_commands
      WHERE command_id = $1
      LIMIT 1`,
    [commandId]
  );
  const row = result.rows[0];
  if (!row) {return null;}
  if (row.request_hash !== hash || (planId && String(row.plan_id) !== String(planId))) {
    throw commandError(
      "This command ID was already used for a different change.",
      "DISPATCH_COMMAND_ID_REUSED",
      409
    );
  }
  return row.result;
}

export async function getDispatchV2CommandReplay({ command = {}, planId = '' } = {}) {
  const commandId = text(command.commandId);
  if (!commandId) {return null;}
  const payload = await existingReceipt(commandId, requestHash(command), planId);
  if (!payload) {return null;}
  if (payload.receipt?.compact === true && !payload.plan) {
    const plan = await selectPlan({ planId: payload.receipt.planId });
    if (plan) {return { payload: { ...payload, plan: publicPlan(plan) }, replay: true };}
  }
  return { payload, replay: true };
}

function dispatchAssignmentEtaTime(stop = {}) {
  const direct = text(stop.arriveTime || stop.plannedArrive);
  if (direct) {return direct;}
  const rawArrival = stop?.timing?.arrival;
  if (rawArrival === null || rawArrival === undefined || rawArrival === "") {return "";}
  const arrival = Number(rawArrival);
  if (!Number.isFinite(arrival) || arrival < 0) {return "";}
  const minute = Math.floor(arrival);
  return `${String(Math.floor(minute / 60)).padStart(2, "0")}:${String(minute % 60).padStart(2, "0")}`;
}

function assignmentLocations(plan = {}) {
  const locations = new Map();
  for (const truck of plan.trucks || []) {
    for (const load of truck?.loads || []) {
      const loadAssignment = dispatchLoadAssignment(truck, load);
      for (const stop of load?.stops || []) {
        const stopType = text(stop.type).toLowerCase();
        const deliveryPriority = ["drop", "dropoff", "delivery"].includes(stopType) ? 2 : 1;
        const refs = [...new Set([
          stop.orderId,
          stop.order_id,
          stop.orderRef,
          ...(Array.isArray(stop.orderRefs) ? stop.orderRefs : [])
        ].map(text).filter(Boolean))];
        for (const ref of refs) {
          const key = ref.toLowerCase();
          const existing = locations.get(key);
          if (existing && existing.deliveryPriority >= deliveryPriority) {continue;}
          locations.set(key, {
            orderRef: ref,
            loadId: text(load.id),
            stopId: text(stop.id),
            truckId: text(truck.id),
            truckPlate: loadAssignment.truckPlate,
            loadName: text(load.name),
            parkingSpot: loadAssignment.parkingSpot,
            driverLogin: loadAssignment.driverLogin,
            driverName: loadAssignment.driverName,
            etaTime: dispatchAssignmentEtaTime(stop),
            deliveryPriority
          });
        }
      }
    }
  }
  return locations;
}

function nestedOrderMap(plan = {}) {
  const orders = new Map();
  const visit = (order) => {
    const ref = text(order?.id || order?.orderId || order?.orderRef || order?.tranid || order?.refNumber);
    if (!ref || orders.has(ref.toLowerCase())) {return;}
    orders.set(ref.toLowerCase(), order);
    for (const child of Array.isArray(order?.childOrderDetails) ? order.childOrderDetails : []) {visit(child);}
  };
  for (const order of Array.isArray(plan.orders) ? plan.orders : []) {visit(order);}
  return orders;
}

function splitParentRef(order = {}, orderReference = "") {
  const explicitParent = text(order?.originalOrderId || order?.parentOrderRef);
  if (explicitParent) {return explicitParent;}
  if (
    text(order?.type).toUpperCase() === "CUSTOM"
    || order?.customOrder === true
    || text(order?.sourceTable).toLowerCase() === "dispatch_custom_orders"
  ) {return "";}
  const ref = text(orderReference || order?.id || order?.orderId || order?.orderRef);
  return /-S\d+$/iu.test(ref) ? ref.replace(/-S\d+$/iu, "") : "";
}

function dispatchAssignmentOrderKind(order = {}) {
  if (text(order?.sourceTable).toLowerCase() === "scm_vrma_orders") {return "VRMA";}
  const kind = text(order?.type || order?.orderKind).toUpperCase();
  return ["PO", "TO", "VRMA"].includes(kind) ? kind : "";
}

export function dispatchPlanAssignmentRows(plan = {}) {
  const locations = assignmentLocations(plan);
  const orders = nestedOrderMap(plan);
  const rows = [];
  const seen = new Set();
  const add = ({ orderRef, plannedOrderRef, assignmentKind, details }) => {
    const ref = text(orderRef);
    const plannedRef = text(plannedOrderRef) || ref;
    const key = ref.toLowerCase();
    if (!ref || seen.has(key)) {return;}
    seen.add(key);
    const location = locations.get(plannedRef.toLowerCase()) || locations.get(key) || {};
    const order = orders.get(key) || orders.get(plannedRef.toLowerCase()) || {};
    const orderKind = text(details?.dispatchOrderKind).toUpperCase()
      || dispatchAssignmentOrderKind(order);
    rows.push({
      orderRef: ref,
      plannedOrderRef: plannedRef,
      assignmentKind,
      loadId: text(location.loadId),
      stopId: text(location.stopId),
      assignment: {
        ...details,
        plannedOrderRef: plannedRef,
        dispatchOrderKind: orderKind,
        dispatchEtaTime: text(details?.dispatchEtaTime || location.etaTime),
        dispatchTruckId: text(location.truckId),
        dispatchTruckPlate: text(details?.dispatchTruckPlate || location.truckPlate),
        dispatchLoadName: text(details?.dispatchLoadName || location.loadName),
        dispatchParkingSpot: text(details?.dispatchParkingSpot || location.parkingSpot),
        dispatchDriverLogin: text(details?.dispatchDriverLogin || location.driverLogin),
        dispatchDriverName: text(details?.dispatchDriverName || location.driverName),
        dispatchLoadId: text(location.loadId),
        dispatchStopId: text(location.stopId)
      }
    });
  };
  for (const [ref, assignment] of dispatchPlannedAssignmentMap(plan)) {
    const details = { ...(assignment || {}) };
    const plannedRef = text(details.plannedOrderRef) || ref;
    add({
      orderRef: ref,
      plannedOrderRef: plannedRef,
      assignmentKind: ref.toLowerCase() === plannedRef.toLowerCase() ? "direct" : "group_member",
      details
    });
  }
  // Modern compact plans carry `orderRefs` on delivery/pickup stops, while
  // legacy boards carried one `orderId` on a `drop` stop. Projection must
  // cover both shapes so cross-date ownership never depends on snapshot JSON.
  for (const location of locations.values()) {
    add({
      orderRef: location.orderRef,
      plannedOrderRef: location.orderRef,
      assignmentKind: "direct",
      details: {
        dispatchPlanned: true,
        dispatchPlanId: plan.id ? String(plan.id) : "",
        dispatchPlanDate: String(plan.planDate || "").slice(0, 10),
        dispatchTruckPlate: location.truckPlate,
        dispatchLoadName: location.loadName
      }
    });
  }
  for (const row of [...rows]) {
    const assignedOrder = orders.get(row.orderRef.toLowerCase());
    const parentRef = splitParentRef(assignedOrder, row.orderRef);
    if (parentRef && parentRef.toLowerCase() !== row.orderRef.toLowerCase()) {add({
      orderRef: parentRef,
      plannedOrderRef: row.plannedOrderRef,
      assignmentKind: "split_parent_alias",
      details: { ...row.assignment, splitChildOrderRef: row.orderRef }
    });}
  }
  return rows;
}

export async function listDispatchPlanOrderAssignmentsProjection({
  orderRefs = [],
  excludePlanId = "",
  excludePlanDate = ""
} = {}) {
  const refs = [...new Set(
    (orderRefs || []).map((ref) => text(ref).toLowerCase()).filter(Boolean)
  )];
  const result = await query(
    `SELECT assignment.plan_id::text AS plan_id,
            assignment.plan_date::text AS plan_date,
            plan.status,
            assignment.order_ref,
            assignment.planned_order_ref,
            assignment.assignment_kind,
            assignment.load_id,
            assignment.stop_id,
            assignment.assignment
       FROM dispatch_plan_order_assignments assignment
       JOIN dispatch_plans plan ON plan.id = assignment.plan_id
      WHERE plan.status <> 'cancelled'
        AND (NULLIF($1, '') IS NULL OR assignment.plan_id <> NULLIF($1, '')::bigint)
        AND ($2 = '' OR assignment.plan_date <> $2::date)
        AND NOT EXISTS (
          SELECT 1
            FROM dispatch_global_order_groups retired_group
           WHERE retired_group.active = false
             AND lower(retired_group.group_ref) IN (
               lower(assignment.order_ref), lower(assignment.planned_order_ref)
             )
        )
        AND NOT EXISTS (
          SELECT 1
            FROM dispatch_global_order_splits retired_split
           WHERE retired_split.active = false
             AND lower(retired_split.split_ref) IN (
               lower(assignment.order_ref), lower(assignment.planned_order_ref)
             )
        )
        AND (
          cardinality($3::text[]) = 0
          OR lower(assignment.order_ref) = ANY($3::text[])
        )
      ORDER BY assignment.plan_date DESC, plan.updated_at DESC,
               assignment.plan_id DESC, lower(assignment.order_ref)`,
    [text(excludePlanId), text(excludePlanDate).slice(0, 10), refs]
  );
  return result.rows.map((row) => ({
    planId: text(row.plan_id),
    planDate: text(row.plan_date).slice(0, 10),
    status: text(row.status),
    orderRef: text(row.order_ref),
    plannedOrderRef: text(row.planned_order_ref),
    assignmentKind: text(row.assignment_kind),
    loadId: text(row.load_id),
    stopId: text(row.stop_id),
    assignment: row.assignment && typeof row.assignment === "object" ? row.assignment : {}
  }));
}

async function refreshDispatchAssignmentProjectionReadiness(runQuery = query) {
  const result = await runQuery(
    `UPDATE dispatch_order_catalog_state state
        SET assignments_ready = NOT EXISTS (
              SELECT 1
                FROM dispatch_plans plan
                LEFT JOIN dispatch_plan_projection_state projection
                  ON projection.plan_id = plan.id
               WHERE plan.status <> 'cancelled'
                 AND (
                   projection.plan_id IS NULL
                   OR projection.source_revision <> COALESCE(plan.revision, 0)
                 )
            ),
            updated_at = now()
      WHERE state.singleton = true
      RETURNING assignments_ready`
  );
  return result.rows[0]?.assignments_ready === true;
}

export async function syncDispatchPlanOrderAssignments(plan = {}, { execute = query } = {}) {
  const runQuery = typeof execute === "function" ? execute : query;
  const rows = dispatchPlanAssignmentRows(plan);
  await runQuery("DELETE FROM dispatch_plan_order_assignments WHERE plan_id = $1", [plan.id]);
  if (rows.length) {await runQuery(
    `INSERT INTO dispatch_plan_order_assignments (
       plan_id, plan_date, order_ref, planned_order_ref, assignment_kind,
       load_id, stop_id, assignment, updated_at
     )
     SELECT $1, $2::date, source.order_ref, source.planned_order_ref,
            source.assignment_kind, source.load_id, source.stop_id,
            source.assignment, now()
       FROM jsonb_to_recordset($3::jsonb) AS source(
         order_ref text, planned_order_ref text, assignment_kind text,
         load_id text, stop_id text, assignment jsonb
       )
     ON CONFLICT (plan_id, order_ref) DO UPDATE
       SET plan_date = EXCLUDED.plan_date,
           planned_order_ref = EXCLUDED.planned_order_ref,
           assignment_kind = EXCLUDED.assignment_kind,
           load_id = EXCLUDED.load_id,
           stop_id = EXCLUDED.stop_id,
           assignment = EXCLUDED.assignment,
           updated_at = now()`,
    [plan.id, plan.planDate, JSON.stringify(rows.map((row) => ({
      order_ref: row.orderRef,
      planned_order_ref: row.plannedOrderRef,
      assignment_kind: row.assignmentKind,
      load_id: row.loadId,
      stop_id: row.stopId,
      assignment: row.assignment
    })))]
  );}
  await runQuery(
    `INSERT INTO dispatch_plan_projection_state (plan_id, source_revision, projected_at)
     VALUES ($1, $2, now())
     ON CONFLICT (plan_id) DO UPDATE
       SET source_revision = EXCLUDED.source_revision,
           projected_at = now()`,
    [plan.id, Number(plan.revision || 0)]
  );
  await refreshDispatchAssignmentProjectionReadiness(runQuery);
}

export async function syncDispatchPlanRelationEdges(plan = {}, { execute = query } = {}) {
  const runQuery = typeof execute === "function" ? execute : query;
  const edges = extractDispatchOrderRelationEdges(plan);
  await runQuery("DELETE FROM dispatch_order_relation_edges WHERE plan_id = $1", [plan.id]);
  if (!edges.length) {return;}
  await runQuery(
    `INSERT INTO dispatch_order_relation_edges (
       plan_id, relation_type, owner_ref, member_ref, metadata, source_revision, updated_at
     )
     SELECT $1, source.relation_type, source.owner_ref, source.member_ref,
            source.metadata, $2, now()
       FROM jsonb_to_recordset($3::jsonb) AS source(
         relation_type text, owner_ref text, member_ref text, metadata jsonb
       )`,
    [plan.id, Number(plan.revision || 0), JSON.stringify(edges.map((edge) => ({
      relation_type: edge.relationType,
      owner_ref: edge.ownerRef,
      member_ref: edge.memberRef,
      metadata: edge.metadata
    })))]
  );
}

export async function backfillDispatchPlanProjections({ batchSize = 25 } = {}) {
  const safeBatchSize = Math.min(Math.max(Number(batchSize) || 25, 1), 100);
  return withTransaction(async () => {
    await query("SELECT pg_advisory_xact_lock(hashtext($1))", [DISPATCH_FLEET_PLANNING_LOCK]);
    let projected = 0;
    let lastPlanId = 0;
    while (true) {
      const active = await query(
        `SELECT p.id, p.plan_date::text AS plan_date, p.status, p.note, p.revision,
                p.created_at, p.updated_at, s.saved_at, s.orders, s.trucks, s.summary,
                s.schema_version
           FROM dispatch_plans p
           JOIN dispatch_plan_snapshots s ON s.plan_id = p.id
           LEFT JOIN dispatch_plan_projection_state projection ON projection.plan_id = p.id
          WHERE p.status <> 'cancelled'
            AND p.id > $1
            AND (
              projection.plan_id IS NULL
              OR projection.source_revision <> COALESCE(p.revision, 0)
            )
          ORDER BY p.id
          LIMIT $2
          FOR UPDATE OF p, s`,
        [lastPlanId, safeBatchSize]
      );
      if (!active.rowCount) {break;}
      for (const row of active.rows) {
        const plan = await reconcileCancelledLocalCos(rowPlan(row));
        await syncDispatchPlanLoadProjection(plan);
        await syncDispatchPlanOrderAssignments(plan);
        await syncDispatchPlanRelationEdges(plan);
        projected += 1;
        lastPlanId = Number(row.id);
      }
      await new Promise((resolve) => setImmediate(resolve));
    }
    const pending = await query(
      `SELECT count(*)::int AS count
         FROM dispatch_plans plan
         LEFT JOIN dispatch_plan_projection_state projection ON projection.plan_id = plan.id
        WHERE plan.status <> 'cancelled'
          AND (
            projection.plan_id IS NULL
            OR projection.source_revision <> COALESCE(plan.revision, 0)
          )`
    );
    const remaining = Number(pending.rows[0]?.count || 0);
    const ready = await refreshDispatchAssignmentProjectionReadiness();
    return { projected, remaining, ready };
  });
}

async function otherDateAssignment(plan, orderReference) {
  const materialized = await query(
    `SELECT assignment.plan_id::text AS plan_id, assignment.plan_date::text AS plan_date,
            assignment.load_id, assignment.stop_id
       FROM dispatch_plan_order_assignments assignment
       JOIN dispatch_plans p ON p.id = assignment.plan_id
      WHERE assignment.plan_id <> $1
        AND p.status <> 'cancelled'
        AND NOT EXISTS (
          SELECT 1
            FROM dispatch_global_order_groups retired_group
           WHERE retired_group.active = false
             AND lower(retired_group.group_ref) IN (
               lower(assignment.order_ref), lower(assignment.planned_order_ref)
             )
        )
        AND NOT EXISTS (
          SELECT 1
            FROM dispatch_global_order_splits retired_split
           WHERE retired_split.active = false
             AND lower(retired_split.split_ref) IN (
               lower(assignment.order_ref), lower(assignment.planned_order_ref)
             )
        )
        AND lower(assignment.order_ref) = lower($2)
      ORDER BY assignment.plan_date DESC
      LIMIT 1`,
    [plan.id, orderReference]
  );
  if (materialized.rows[0]) {return materialized.rows[0];}
  return null;
}

async function assertOtherPlanAssignmentProjectionsReady(plan) {
  const pendingAssignments = () => query(
    `SELECT other_plan.id::text AS plan_id,
            other_plan.plan_date::text AS plan_date,
            other_plan.revision::int AS revision,
            projection.source_revision::int AS source_revision
       FROM dispatch_plans other_plan
       LEFT JOIN dispatch_plan_projection_state projection
         ON projection.plan_id = other_plan.id
      WHERE other_plan.id <> $1
        AND other_plan.status <> 'cancelled'
        AND (
          projection.plan_id IS NULL
          OR projection.source_revision <> COALESCE(other_plan.revision, 0)
        )
      ORDER BY other_plan.plan_date DESC, other_plan.id DESC
      LIMIT 10`,
    [plan.id]
  );
  let pending = await pendingAssignments();
  if (!pending.rowCount) {return;}
  try {
    await backfillDispatchPlanProjections({ batchSize: 25 });
  } catch {
    // The command remains fail-closed below. A later maintenance tick can
    // retry the same idempotent repair without risking a duplicate assignment.
  }
  pending = await pendingAssignments();
  if (!pending.rowCount) {return;}
  throw commandError(
    "Dispatch assignment index is still warming up. Retry after projection backfill completes.",
    "DISPATCH_ASSIGNMENT_PROJECTION_NOT_READY",
    409,
    {
      conflicts: pending.rows.map((row) => ({
        planId: text(row.plan_id),
        planDate: planDate(row.plan_date),
        revision: Number(row.revision || 0),
        projectedRevision: row.source_revision === null ? null : Number(row.source_revision)
      }))
    }
  );
}

async function assertAssignmentDateAvailable(plan, command) {
  const commandType = text(command.commandType || command.type);
  let refs = [];
  if (commandType === "assign_order") {
    refs = [text(command.payload?.orderRef)].filter(Boolean);
  } else if (
    commandType === "replace_plan"
    || (command.payload?.planDelta && typeof command.payload.planDelta === "object")
  ) {
    const candidate = commandType === "replace_plan"
      ? { trucks: command.payload?.trucks || [] }
      : applyDispatchPlanDelta(plan, command.payload.planDelta);
    const previousRefs = new Set(dispatchPlanBoard(plan).orderRefs.map((ref) => text(ref).toLowerCase()));
    refs = dispatchPlanBoard(candidate).orderRefs
      .map(text)
      .filter((ref) => ref && !previousRefs.has(ref.toLowerCase()));
  }
  const uniqueRefs = [...new Set(refs)];
  if (!uniqueRefs.length) {return;}
  await assertOtherPlanAssignmentProjectionsReady(plan);
  await assertNoDriverPwaCompletedDispatchRefs(uniqueRefs, "add these orders to Dispatch");
  await assertSalesDeliveryPlanningAllowed(uniqueRefs, "add these orders to Dispatch");
  const fulfilledRefs = new Set((await fulfilledSalesDeliveryPlanningRefs(uniqueRefs)).map(ref => ref.toLowerCase()));
  await assertHistoricalInactiveSalesOrdersReconciled({
    planDate: plan.planDate,
    orderRefs: uniqueRefs.filter(ref => !fulfilledRefs.has(ref.toLowerCase())),
    action: "add these orders to Dispatch"
  });
  for (const ref of uniqueRefs) {
    const conflict = await otherDateAssignment(plan, ref);
    if (!conflict) {continue;}
    throw commandError(`${ref} is already planned on ${planDate(conflict.plan_date)}.`, "DISPATCH_ORDER_ALREADY_PLANNED", 409, {
      conflicts: [{ orderRef: ref, planId: text(conflict.plan_id), planDate: planDate(conflict.plan_date) }]
    });
  }
}

function commandOrderRefs(command = {}, plan = {}) {
  const commandType = text(command.commandType || command.type);
  const payload = command.payload && typeof command.payload === "object" ? command.payload : {};
  const refs = [
    payload.orderRef,
    payload.sourceOrderRef,
    payload.targetOrderRef,
    ...(Array.isArray(payload.orderRefs) ? payload.orderRefs : []),
    ...(Array.isArray(payload.affectedOrderRefs) ? payload.affectedOrderRefs : []),
    ...(Array.isArray(payload.operatorAlertRefs) ? payload.operatorAlertRefs : [])
  ];
  if (payload.co && typeof payload.co === "object") {
    refs.push(...operationalPlanOrderRefs({ orders: [payload.co] }));
  }
  if (commandType === "replace_plan") {
    refs.push(...operationalPlanOrderRefs({
      orders: Array.isArray(payload.orders) ? payload.orders : [],
      trucks: Array.isArray(payload.trucks) ? payload.trucks : []
    }));
  } else if (payload.planDelta && typeof payload.planDelta === "object" && !Array.isArray(payload.planDelta)) {
    refs.push(...operationalPlanOrderRefs(applyDispatchPlanDelta(plan, payload.planDelta)));
  }
  return [...new Set(refs.map(text).filter(Boolean))];
}

async function activityForPlan(planId) {
  const result = await query(
    `SELECT status, load_id, stop_id, stop_type, order_refs, job_details
       FROM driver_job_records
      WHERE plan_id = $1
        AND status IN ('in_progress', 'complete')
      ORDER BY id`,
    [planId]
  );
  return result.rows;
}

function snapshotCounts(plan = {}) {
  const board = dispatchPlanBoard(plan);
  return {
    orderCount: (plan.orders || []).length,
    truckCount: board.truckCount,
    loadCount: board.loadCount,
    stopCount: board.stopCount
  };
}

async function recordDispatchCommandCheckpointState(previousPlan = {}, nextPlan = {}) {
  await query(
    `INSERT INTO dispatch_plan_checkpoint_state (
       plan_id, last_checkpoint_revision, last_checkpoint_at,
       commands_since_checkpoint, checkpoint_due, due_trigger, updated_at
     ) VALUES ($1, $2, COALESCE($3::timestamptz, now()), 0, false, '', now())
     ON CONFLICT (plan_id) DO NOTHING`,
    [nextPlan.id, Number(previousPlan.revision || 0), previousPlan.savedAt || null]
  );
  const current = await query(
    `SELECT last_checkpoint_revision, last_checkpoint_at, commands_since_checkpoint
       FROM dispatch_plan_checkpoint_state
      WHERE plan_id = $1
      FOR UPDATE`,
    [nextPlan.id]
  );
  const state = current.rows[0] || {};
  const commandsSinceCheckpoint = Number(state.commands_since_checkpoint || 0) + 1;
  const decision = dispatchCheckpointDecision({
    commandsSinceCheckpoint,
    lastCheckpointAt: state.last_checkpoint_at,
    now: nextPlan.savedAt || new Date()
  });
  await query(
    `UPDATE dispatch_plan_checkpoint_state
        SET commands_since_checkpoint = $2,
            checkpoint_due = $3,
            due_trigger = $4,
            updated_at = now()
      WHERE plan_id = $1`,
    [nextPlan.id, commandsSinceCheckpoint, decision.due, decision.trigger]
  );
}

export async function applyDispatchV2Command({ planId, command = {}, actorId = null, editLease = null } = {}) {
  const commandId = text(command.commandId);
  const commandType = text(command.commandType || command.type);
  if (!commandId || !commandType || !Number.isFinite(Number(command.baseRevision))) {
    throw commandError("commandId, commandType, and baseRevision are required.", "DISPATCH_COMMAND_INVALID", 400);
  }
  const hash = requestHash({ ...command, commandType });
  let deferredAssignmentError = null;
  const transactionResult = await withTransaction(async () => {
    await query("SELECT pg_advisory_xact_lock(hashtext($1))", [DISPATCH_FLEET_PLANNING_LOCK]);
    await lockDispatchPlanEditLease(editLease);
    const persistedPlan = await selectPlan({ planId, lock: true, enrich: false });
    if (!persistedPlan) {throw commandError("Dispatch plan not found.", "DISPATCH_PLAN_NOT_FOUND", 404);}
    if (editLease && planDate(editLease.planDate) !== persistedPlan.planDate) {throw commandError('Edit lease belongs to a different plan date.', 'DISPATCH_PLAN_EDIT_LEASE_REQUIRED');}
    const replay = await existingReceipt(commandId, hash, planId);
    if (replay) {
      return {
        payload: replay.receipt?.compact === true && !replay.plan
          ? { ...replay, plan: publicPlan(persistedPlan) }
          : replay,
        replay: true
      };
    }
    assertDispatchPlanFence(persistedPlan, command, { required: Boolean(editLease), computedDigest: persistedPlan.digest });
    const plan = (await scrubClosedNetSuiteOrdersFromOperationalPlan(await reconcileCancelledLocalCos(persistedPlan))).plan;
    await assertNoClosedNetSuiteOrders(commandOrderRefs({ ...command, commandType }, plan), "be changed in Dispatch");
    try {
      await assertAssignmentDateAvailable(plan, { ...command, commandType });
    } catch (error) {
      if ([
        "DISPATCH_ASSIGNMENT_PROJECTION_NOT_READY",
        "DISPATCH_ORDER_ALREADY_PLANNED"
      ].includes(error?.code)) {
        deferredAssignmentError = error;
        return null;
      }
      throw error;
    }
    const result = applyDispatchPlanMutation({
      plan,
      command: { ...command, type: commandType }
    });
    const commandReactivatedRefs = [
      ...(Array.isArray(command.payload?.reactivatedGlobalOrderRefs)
        ? command.payload.reactivatedGlobalOrderRefs
        : []),
      ...(commandType === "group_orders"
        ? [command.payload?.groupRef, result.patch?.group?.ref]
        : []),
      ...(commandType === "split_order"
        ? (result.patch?.split?.parts || []).map((part) => part?.refNumber || part?.id)
        : [])
    ].map(text).filter(Boolean);
    result.plan = await reconcileCancelledLocalCos(result.plan, {
      reactivatedGlobalOrderRefs: commandReactivatedRefs,
      rejectRetiredGlobalOrderRefs: true
    });
    result.plan = await applyPendingDispatchPlanMaintenance(result.plan);
    result.plan = await scrubBilledSalesOrderFamiliesFromPlan(result.plan);
    // Global definitions can replace hydrated group lines with raw allocation
    // quantities. Refresh relationships after that replacement, just as a full
    // save does, before deciding which physical pickups are actually required.
    result.plan = await refreshDispatchPlanAuthoritativeOrderProjection(result.plan);
    const pickupVisits = materializeDispatchPickupVisits(result.plan, {
      previousPlan: plan,
      allowLegacyPassthrough: true
    });
    if (pickupVisits.conflicts.length) {
      const first = pickupVisits.conflicts[0];
      throw commandError(first.message, first.code, 409, { conflicts: pickupVisits.conflicts });
    }
    result.plan = pickupVisits.plan;
    result.plan.summary = dispatchPlanV2Summary(result.plan.summary || {}, {
      previousSummary: plan.summary || {},
      source: SNAPSHOT_SUMMARY_SAVE_SOURCE
    });
    const policy = evaluateExecutedPrefixPolicy({
      previousPlan: plan,
      nextPlan: result.plan,
      activity: await activityForPlan(plan.id)
    });
    if (!policy.allowed) {
      throw commandError(policy.conflicts[0].message, policy.conflicts[0].code, 409, { conflicts: policy.conflicts });
    }
    await assertActiveDispatchCosForPlan(result.plan);
    if (plan.savedAt && command.compactReceipt !== true) {
      const previousCounts = snapshotCounts(persistedPlan);
      await query(
        `INSERT INTO dispatch_plan_snapshot_history (
           plan_id, plan_date, revision, orders, trucks, summary,
           original_saved_at, archive_reason, session_id,
           schema_version, plan_digest, order_count, truck_count, load_count, stop_count
         ) VALUES (
           $1, $2::date, $3, $4::jsonb, $5::jsonb, $6::jsonb,
           $7, 'before_incremental_command', $8,
           $9, $10, $11, $12, $13, $14
         )`,
        [
          plan.id,
          plan.planDate,
          plan.revision,
          JSON.stringify(persistedPlan.orders || []),
          JSON.stringify(persistedPlan.trucks || []),
          JSON.stringify(persistedPlan.summary || {}),
          plan.savedAt,
          text(command.sessionId),
          SNAPSHOT_SCHEMA_VERSION,
          persistedPlan.digest,
          previousCounts.orderCount,
          previousCounts.truckCount,
          previousCounts.loadCount,
          previousCounts.stopCount
        ]
      );
    }
    const updated = await query(
      `UPDATE dispatch_plans
          SET revision = revision + 1,
              updated_at = now()
        WHERE id = $1
          AND revision = $2
        RETURNING revision, updated_at`,
      [plan.id, Number(command.baseRevision)]
    );
    if (!updated.rows[0]) {
      throw commandError("Dispatch plan changed before this command was applied.", "STALE_DISPATCH_PLAN", 409);
    }
    result.plan.revision = Number(updated.rows[0].revision);
    result.plan.savedAt = updated.rows[0].updated_at;
    const digest = digestDispatchPlan(result.plan);
    result.plan.digest = digest;
    const counts = snapshotCounts(result.plan);
    await query(
      `UPDATE dispatch_plan_snapshots
          SET orders = $2::jsonb,
              trucks = $3::jsonb,
              summary = $4::jsonb,
              saved_at = now(),
              schema_version = $5,
              plan_digest = $6,
              order_count = $7,
              truck_count = $8,
              load_count = $9,
              stop_count = $10
        WHERE plan_id = $1`,
      [
        plan.id,
        JSON.stringify(result.plan.orders || []),
        JSON.stringify(result.plan.trucks || []),
        JSON.stringify(result.plan.summary || {}),
        SNAPSHOT_SCHEMA_VERSION,
        digest,
        counts.orderCount,
        counts.truckCount,
        counts.loadCount,
        counts.stopCount
      ]
    );
    // A V2 command may add, remove, move, or reassign a load. Keep the Driver
    // execution/status projection atomic with the snapshot and order index.
    // Load first so the order projection's readiness refresh observes both.
    await syncDispatchPlanLoadProjection(result.plan);
    await syncDispatchPlanOrderAssignments(result.plan);
    await syncDispatchPlanRelationEdges(result.plan);
    if (command.compactReceipt === true) {await recordDispatchCommandCheckpointState(plan, result.plan);}
    // Operator reads this projection instead of the plan JSON. Keep it in the
    // command transaction so a refresh cannot resurrect a just-ungrouped order.
    await syncDispatchDeliveryGroupsFromPlan(result.plan, {
      reactivatedGlobalOrderRefs: commandReactivatedRefs,
      rejectRetiredGlobalOrderRefs: true
    });
    const retainedRefs = new Set((result.plan.orders || [])
      .map((order) => text(order?.id).toLowerCase())
      .filter(Boolean));
    const commandRetiredRefs = [
      ...(Array.isArray(command.payload?.retiredGlobalOrderRefs)
        ? command.payload.retiredGlobalOrderRefs
        : []),
      ...(commandType === "ungroup_orders" ? [command.payload?.groupRef] : []),
      ...(commandType === "unsplit_order" && Array.isArray(result.patch?.unsplit?.removedPartRefs)
        ? result.patch.unsplit.removedPartRefs
        : [])
    ];
    await deactivateDispatchGlobalOrderDefinitions(commandRetiredRefs
      .map(text)
      .filter((ref) => ref && !retainedRefs.has(ref.toLowerCase()))
      .slice(0, 200));
    const payload = {
      plan: publicPlan(result.plan),
      patch: result.patch,
      acknowledgement: { commandId, revision: result.plan.revision, digest, patch: result.patch }
    };
    if (editLease) {await assertDispatchPlanEditLease(editLease);}
    const storedPayload = command.compactReceipt === true
      ? {
          patch: payload.patch,
          acknowledgement: payload.acknowledgement,
          receipt: {
            compact: true,
            planId: plan.id,
            planDate: plan.planDate,
            appliedRevision: result.plan.revision,
            digest
          }
        }
      : payload;
    await query(
      `INSERT INTO dispatch_plan_commands (
         command_id, plan_id, plan_date, command_type, request_hash,
         base_revision, applied_revision, session_id, actor_id, result
       ) VALUES ($1, $2, $3::date, $4, $5, $6, $7, $8, $9, $10::jsonb)`,
      [
        commandId,
        plan.id,
        plan.planDate,
        commandType,
        hash,
        Number(command.baseRevision),
        result.plan.revision,
        text(command.sessionId),
        actorId || null,
        JSON.stringify(storedPayload)
      ]
    );
    await query(
      `INSERT INTO dispatch_plan_followup_outbox (command_id, plan_id, command_type)
       VALUES ($1, $2, $3)
       ON CONFLICT (command_id) DO NOTHING`,
      [commandId, plan.id, commandType]
    );
    return { payload, replay: false };
  });
  if (deferredAssignmentError) {throw deferredAssignmentError;}
  return transactionResult;
}

function checkpointResult(row = {}) {
  return {
    id: text(row.id),
    planId: text(row.plan_id),
    planDate: planDate(row.plan_date),
    revision: Number(row.revision || 0),
    archivedAt: row.archived_at || null,
    archiveReason: row.archive_reason || "",
    checkpointKind: row.checkpoint_kind || "legacy",
    checkpointKey: row.checkpoint_key || "",
    retentionUntil: row.retention_until || null,
    digest: row.plan_digest || "",
    orderCount: Number(row.order_count || 0),
    truckCount: Number(row.truck_count || 0),
    loadCount: Number(row.load_count || 0),
    stopCount: Number(row.stop_count || 0)
  };
}

export async function createDispatchV2Checkpoint({
  planId,
  kind = "manual",
  reason = "",
  sessionId = "",
  checkpointKey = "",
  expectedRevision = null,
  expectedDigest = "",
  editLease = null
} = {}) {
  const checkpointKind = text(kind).toLowerCase();
  if (!["periodic", "manual", "lifecycle"].includes(checkpointKind)) {
    throw commandError("Unsupported Dispatch checkpoint kind.", "DISPATCH_CHECKPOINT_KIND_INVALID", 400);
  }
  const cleanKey = text(checkpointKey).slice(0, 240);
  const cleanReason = text(reason).replace(/[^a-z0-9_-]+/giu, "_").slice(0, 80) || checkpointKind;
  return withTransaction(async () => {
    await query("SELECT pg_advisory_xact_lock(hashtext($1))", [DISPATCH_FLEET_PLANNING_LOCK]);
    await lockDispatchPlanEditLease(editLease);
    if (cleanKey) {
      const existing = await query(
        `SELECT id::text, plan_id::text, plan_date::text, revision, archived_at,
                archive_reason, checkpoint_kind, checkpoint_key, retention_until,
                plan_digest, order_count, truck_count, load_count, stop_count
           FROM dispatch_plan_snapshot_history
          WHERE plan_id = $1
            AND checkpoint_kind = $2
            AND checkpoint_key = $3
          LIMIT 1`,
        [planId, checkpointKind, cleanKey]
      );
      if (existing.rows[0]) {return { ...checkpointResult(existing.rows[0]), replay: true };}
    }
    const plan = await selectPlan({ planId, lock: true, enrich: false });
    if (!plan) {throw commandError("Dispatch plan not found.", "DISPATCH_PLAN_NOT_FOUND", 404);}
    const revision = Number(plan.revision || 0);
    const digest = digestDispatchPlan(plan);
    if (expectedRevision !== null && expectedRevision !== undefined && Number(expectedRevision) !== revision) {
      throw commandError("Dispatch plan changed before the checkpoint was created.", "STALE_DISPATCH_PLAN", 409, {
        expectedRevision: Number(expectedRevision), currentRevision: revision
      });
    }
    if (text(expectedDigest) && text(expectedDigest) !== digest) {
      throw commandError("Dispatch plan content changed before the checkpoint was created.", "STALE_DISPATCH_PLAN", 409, {
        expectedDigest: text(expectedDigest), currentDigest: digest
      });
    }
    const counts = snapshotCounts(plan);
    const retentionDays = dispatchCheckpointRetention({ kind: checkpointKind });
    const inserted = await query(
      `INSERT INTO dispatch_plan_snapshot_history (
         plan_id, plan_date, revision, orders, trucks, summary,
         original_saved_at, archive_reason, session_id,
         schema_version, plan_digest, order_count, truck_count, load_count, stop_count,
         checkpoint_kind, checkpoint_key, retention_until
       ) VALUES (
         $1, $2::date, $3, $4::jsonb, $5::jsonb, $6::jsonb,
         $7, $8, $9,
         $10, $11, $12, $13, $14, $15,
         $16, $17, now() + ($18::text || ' days')::interval
       )
       RETURNING id::text, plan_id::text, plan_date::text, revision, archived_at,
                 archive_reason, checkpoint_kind, checkpoint_key, retention_until,
                 plan_digest, order_count, truck_count, load_count, stop_count`,
      [
        plan.id, plan.planDate, revision,
        JSON.stringify(plan.orders || []), JSON.stringify(plan.trucks || []), JSON.stringify(plan.summary || {}),
        plan.savedAt || null, `checkpoint_${checkpointKind}_${cleanReason}`, text(sessionId),
        SNAPSHOT_SCHEMA_VERSION, digest, counts.orderCount, counts.truckCount, counts.loadCount, counts.stopCount,
        checkpointKind, cleanKey, retentionDays
      ]
    );
    await query(
      `INSERT INTO dispatch_plan_checkpoint_state (
         plan_id, last_checkpoint_revision, last_checkpoint_at,
         commands_since_checkpoint, checkpoint_due, due_trigger, updated_at
       ) VALUES ($1, $2, now(), 0, false, '', now())
       ON CONFLICT (plan_id) DO UPDATE
         SET last_checkpoint_revision = EXCLUDED.last_checkpoint_revision,
             last_checkpoint_at = EXCLUDED.last_checkpoint_at,
             commands_since_checkpoint = 0,
             checkpoint_due = false,
             due_trigger = '',
             updated_at = now()`,
      [plan.id, revision]
    );
    return { ...checkpointResult(inserted.rows[0]), replay: false };
  });
}

export async function createDueDispatchV2Checkpoints({ limit = 25 } = {}) {
  const safeLimit = Math.min(Math.max(Number(limit) || 25, 1), 100);
  const due = await query(
    `SELECT state.plan_id::text, plan.revision::int
       FROM dispatch_plan_checkpoint_state state
       JOIN dispatch_plans plan ON plan.id = state.plan_id
      WHERE plan.status <> 'cancelled'
        AND state.commands_since_checkpoint > 0
        AND (
          state.checkpoint_due = true
          OR state.commands_since_checkpoint >= 25
          OR state.last_checkpoint_at <= now() - interval '5 minutes'
        )
      ORDER BY state.last_checkpoint_at, state.plan_id
      LIMIT $1`,
    [safeLimit]
  );
  const checkpoints = [];
  for (const row of due.rows) {
    try {
      checkpoints.push(await createDispatchV2Checkpoint({
        planId: row.plan_id,
        kind: "periodic",
        reason: "cadence",
        checkpointKey: `periodic:${row.revision}`,
        expectedRevision: Number(row.revision),
        sessionId: "dispatch-v2-checkpoint-worker"
      }));
    } catch (error) {
      if (error?.code !== "STALE_DISPATCH_PLAN") {throw error;}
    }
  }
  return { created: checkpoints.length, checkpoints };
}

export async function listDispatchV2Checkpoints({ planId, date = "" } = {}) {
  const params = [planId];
  const dateClause = date ? "AND h.plan_date = $2::date" : "";
  if (date) {params.push(planDate(date));}
  const result = await query(
    `SELECT h.id::text AS id, h.plan_id::text AS plan_id, h.plan_date::text AS plan_date,
            h.revision::int AS revision, h.original_saved_at, h.archived_at,
            h.archive_reason, h.session_id, h.schema_version, h.plan_digest,
            h.checkpoint_kind, h.checkpoint_key, h.retention_until, h.resolved_at,
            h.order_count, h.truck_count, h.load_count, h.stop_count
       FROM dispatch_plan_snapshot_history h
      WHERE h.plan_id = $1
        ${dateClause}
      ORDER BY h.archived_at DESC, h.id DESC
      LIMIT 200`,
    params
  );
  return result.rows.map((row) => ({
    id: row.id,
    planId: row.plan_id,
    planDate: planDate(row.plan_date),
    revision: Number(row.revision || 0),
    originalSavedAt: row.original_saved_at,
    archivedAt: row.archived_at,
    archiveReason: row.archive_reason || "",
    checkpointKind: row.checkpoint_kind || "legacy",
    checkpointKey: row.checkpoint_key || "",
    retentionUntil: row.retention_until || null,
    resolvedAt: row.resolved_at || null,
    sessionId: row.session_id || "",
    schemaVersion: Number(row.schema_version || 1),
    digest: row.plan_digest || "",
    orderCount: Number(row.order_count || 0),
    truckCount: Number(row.truck_count || 0),
    loadCount: Number(row.load_count || 0),
    stopCount: Number(row.stop_count || 0)
  }));
}

export async function getDispatchV2Checkpoint({ planId, checkpointId } = {}) {
  const result = await query(
    `SELECT h.id, h.plan_id, h.plan_date::text AS plan_date, h.revision,
            h.orders, h.trucks, h.summary, h.original_saved_at, h.archived_at,
            h.schema_version
       FROM dispatch_plan_snapshot_history h
      WHERE h.plan_id = $1
        AND h.id = $2
      LIMIT 1`,
    [planId, checkpointId]
  );
  if (!result.rows[0]) {return null;}
  const plan = rowPlan({ ...result.rows[0], id: result.rows[0].plan_id });
  return publicPlan((await scrubClosedNetSuiteOrdersFromOperationalPlan(plan)).plan);
}

export async function pruneExpiredDispatchV2Checkpoints({ retentionDays = 7, batchSize = 500 } = {}) {
  // Kept for API compatibility; the bounded snapshot-count policy supersedes
  // age-based deletion.
  void retentionDays;
  const safeBatchSize = Math.min(Math.max(Number(batchSize) || 500, 1), 1000);
  const result = await query(
    `WITH ranked AS MATERIALIZED (
       SELECT history.id,
              history.plan_date,
              history.archived_at,
              row_number() OVER (
                PARTITION BY history.plan_id
                ORDER BY history.archived_at DESC, history.id DESC
              ) AS retained_rank
         FROM dispatch_plan_snapshot_history history
        WHERE NOT (
          history.resolved_at IS NULL
          AND (history.checkpoint_kind = 'recovery' OR history.archive_reason = 'save_recovery')
        )
     ), candidates AS MATERIALIZED (
       SELECT ranked.id, ranked.archived_at
         FROM ranked
        WHERE (
          ranked.plan_date < (now() AT TIME ZONE 'America/Toronto')::date
          OR ranked.retained_rank > 4
        )
        ORDER BY ranked.archived_at, ranked.id
        LIMIT $1
     ), deleted AS (
       DELETE FROM dispatch_plan_snapshot_history history
        USING candidates
        WHERE history.id = candidates.id
        RETURNING history.id
     )
     SELECT deleted.id
       FROM deleted
       JOIN candidates ON candidates.id = deleted.id
      ORDER BY candidates.archived_at, deleted.id`,
    [safeBatchSize]
  );
  return { deleted: result.rowCount, checkpointIds: result.rows.map((row) => text(row.id)) };
}

export async function pendingDispatchV2Followups({ limit = 25 } = {}) {
  const safeLimit = Math.min(Math.max(Number(limit) || 25, 1), 100);
  const result = await query(
    `WITH candidates AS (
       SELECT outbox.id
         FROM dispatch_plan_followup_outbox outbox
        WHERE (
          (outbox.status IN ('pending', 'failed') AND outbox.available_at <= now())
          OR (outbox.status = 'running' AND outbox.updated_at < now() - interval '10 minutes')
        )
        ORDER BY outbox.id
        FOR UPDATE SKIP LOCKED
        LIMIT $1
     ), claimed AS (
       UPDATE dispatch_plan_followup_outbox outbox
          SET status = 'running', updated_at = now()
         FROM candidates
        WHERE outbox.id = candidates.id
        RETURNING outbox.*
     )
     SELECT claimed.id, claimed.command_id, claimed.plan_id, claimed.command_type,
            claimed.attempts, claimed.progress, command.result
       FROM claimed
       JOIN dispatch_plan_commands command ON command.command_id = claimed.command_id
      ORDER BY claimed.id`,
    [safeLimit]
  );
  return result.rows;
}

export async function advanceDispatchV2Followup(id, stage) {
  const allowedStages = new Set([
    "order_dependencies",
    "co_assignments",
    "scm_schedule",
    "delivery_materialization"
  ]);
  const cleanStage = text(stage);
  if (!allowedStages.has(cleanStage)) {
    throw commandError("Unsupported Dispatch follow-up stage.", "DISPATCH_FOLLOWUP_STAGE_INVALID", 400);
  }
  const result = await query(
    `UPDATE dispatch_plan_followup_outbox
        SET progress = jsonb_set(
              COALESCE(progress, '{}'::jsonb),
              ARRAY[$2]::text[],
              jsonb_build_object('completedAt', now()),
              true
            ),
            updated_at = now()
      WHERE id = $1
        AND status = 'running'
      RETURNING progress`,
    [id, cleanStage]
  );
  if (!result.rows[0]) {
    throw commandError("The Dispatch follow-up is no longer owned by this worker.", "DISPATCH_FOLLOWUP_NOT_RUNNING", 409);
  }
  return result.rows[0].progress || {};
}

export async function completeDispatchV2Followup(id) {
  await query(
    `UPDATE dispatch_plan_followup_outbox
        SET status = 'complete', completed_at = now(), updated_at = now()
      WHERE id = $1
        AND status = 'running'`,
    [id]
  );
}

export async function failDispatchV2Followup(id, error) {
  await query(
    `UPDATE dispatch_plan_followup_outbox
        SET status = 'failed', attempts = attempts + 1,
            last_error = $2, available_at = now() + interval '1 minute', updated_at = now()
      WHERE id = $1
        AND status = 'running'`,
    [id, text(error?.message || error).slice(0, 2000)]
  );
}
