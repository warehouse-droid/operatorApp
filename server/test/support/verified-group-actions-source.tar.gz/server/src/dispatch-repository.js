import { notifyDispatchPlanMaintenance } from "./dispatch-plan-maintenance.js";
import { deferDispatchPlanMaintenance, enqueueDispatchPlanMaintenance } from "./dispatch-plan-maintenance-queue.js";
import { reconcileCoDirectToCargo, restoreCoSourceRequirement } from "./co-direct-to-cargo.js";
import crypto from "node:crypto";
import { withCoSourcePackingHandoff } from "./co-source-packing-handoff.js";
import { VOYAGE_DISPATCH_YARD } from "./dispatch-sales-order-locations.js";
import { pool, query, withTransaction } from "./db.js";
import { resumeSmartScmBlanketCoveredPlanningExclusions } from "./smart-scm-planning-exclusion-repository.js";
import { dispatchLoadAssignment } from "./dispatch-load-assignment.js";
import { DISPATCH_FLEET_PLANNING_LOCK } from "./dispatch-fleet-status.js";
import { updateDispatchSalesSplitDetails } from "./dispatch-delivery-group-repository.js";
import { applyDispatchGroupAction } from "./dispatch-group-action-repository.js";
import { assertDispatchExecutedPrefixPreserved } from "./dispatch-executed-prefix-repository.js";
import {
  syncDispatchPlanOrderAssignments,
  syncDispatchPlanRelationEdges
} from "./dispatch-planner-v2-repository.js";
import { digestDispatchPlan } from "./dispatch-planner-performance.js";
import { isNetSuiteSandboxEnvironment } from "./config.js";
import {
  createPurchaseOrderDispatchEnricher,
  enrichPurchaseOrderDispatch,
  enrichSalesOrderDispatch,
  enrichTransferDispatch,
  useNetSuiteAddressMappingValue
} from "./dispatch-enrichment.js";
import { resolveDispatchSalesTarget } from "./dispatch-order-target-repository.js";
import { cancelDispatchCoGlobally } from "./dispatch-co-lifecycle.js";
import {
  exactNetSuiteClosedSql,
  netSuiteClosedOrderFamilySql
} from "./netsuite-closed-order-policy.js";
import { assertNoClosedNetSuiteOrders, listClosedNetSuiteOrders } from "./netsuite-closed-order-repository.js";
import {
  dispatchLocationsShareYard,
  uniqueDispatchLocations
} from "./dispatch-location.js";
import { dispatchOrderPalletQuantity } from "./dispatch-special-order-pallets.js";
import { projectPurchaseOrderRouteResidual } from "./dispatch-po-route-projection.js";
import { scmScheduleRouteOptions } from "./scm-schedule-route-options.js";
import {
  adjustBlanketSplitAllocation,
  assertSplitQuantityAvailable
} from "./scm-po-split-adjustment.js";
import {
  isUnchangedScmPoPickup,
  scmPoPickupNeedsNetSuiteAddressLookup
} from "./scm-po-pickup-save-policy.js";
import {
  isRemarkOnlyScmSchedulePatch,
  normalizeScmScheduleRemarkOverride,
  resolveScmScheduleRemark
} from "./scm-schedule-remark.js";
import { createCoalescingWorkQueue } from "./coalescing-work-queue.js";

function toNumber(value) {
  return Number(value || 0) || 0;
}

const CUSTOMER_PICKUP_DELIVERY_METHOD = "Pick-Up";
const DEFAULT_DISPATCH_ORDERS_PER_TYPE = 500;
const MAX_DISPATCH_ORDERS_PER_TYPE = 2000;
const SCM_VRMA_OWN_YARDS = [
  { code: "3445", name: "3445", address: "3445 Kennedy Road, Toronto, ON" },
  { code: "2967", name: "2967", address: "2967 Kennedy Road, Toronto, ON" },
  { code: "12441", name: "12441", address: "12441 Woodbine Avenue, Whitchurch-Stouffville, ON" },
  { code: "150", name: "150", address: "150 Clark Blvd, Brampton, ON L6T 4Y8, Canada" }
];
const SCM_VRMA_OWN_YARD_CODES = new Set(SCM_VRMA_OWN_YARDS.map((yard) => yard.code));
const SCM_VRMA_FALLBACK_UNITS = new Set(["PLT", "SQFT", "PC"]);

function exactBilledSalesOrderSql(alias) {
  return `(
    UPPER(BTRIM(COALESCE(${alias}.status, ''))) = 'G'
    OR UPPER(REGEXP_REPLACE(
         REGEXP_REPLACE(BTRIM(COALESCE(${alias}.status_text, '')), '\\s*:\\s*', ':', 'g'),
         '\\s+', ' ', 'g'
       ))
       IN ('BILLED', 'SALES ORDER:BILLED')
  )`;
}

function netSuitePendingApprovalSql(alias) {
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(String(alias || ""))) {
    throw new TypeError("A safe NetSuite order SQL alias is required.");
  }
  return `(
    UPPER(BTRIM(COALESCE(${alias}.status, ''))) = 'A'
    OR COALESCE(${alias}.status_text, '') ~*
      '^[[:space:]]*((sales|purchase|transfer)[[:space:]]+order[[:space:]]*:[[:space:]]*)?pending([[:space:]]+supervisor)?[[:space:]]+approval[[:space:]]*$'
  )`;
}

function billedSalesOrderFamilySql(alias) {
  return `(
    ${exactBilledSalesOrderSql(alias)}
    OR EXISTS (
      SELECT 1
        FROM dispatch_scm_so_splits family_membership
        JOIN sales_orders billed_source
          ON billed_source.netsuite_id = family_membership.source_so_id
       WHERE (
         family_membership.source_so_id = ${alias}.netsuite_id
         OR family_membership.split_so_id = ${alias}.netsuite_id
       )
         AND ${exactBilledSalesOrderSql("billed_source")}
    )
    OR EXISTS (
      SELECT 1
        FROM dispatch_scm_so_splits family_membership
        JOIN dispatch_scm_so_splits billed_membership
          ON billed_membership.source_so_id = family_membership.source_so_id
        JOIN sales_orders billed_split
          ON billed_split.netsuite_id = billed_membership.split_so_id
       WHERE (
         family_membership.source_so_id = ${alias}.netsuite_id
         OR family_membership.split_so_id = ${alias}.netsuite_id
       )
         AND ${exactBilledSalesOrderSql("billed_split")}
    )
  )`;
}

function dispatchItemHasConversion(item) {
  return toNumber(item.toPlt) > 0 || toNumber(item.toLyr) > 0 || toNumber(item.toSec) > 0 || toNumber(item.toPcs) > 0;
}

function deriveDispatchUnitsFromSalesQty(item, salesQty) {
  if (!dispatchItemHasConversion(item)) return item;
  let remaining = Math.max(toNumber(salesQty), 0);
  const next = { ...item, pallets: 0, layers: 0, sections: 0, pieces: 0, quantity: remaining };
  const conversions = [
    ["pallets", "toPlt"],
    ["layers", "toLyr"],
    ["sections", "toSec"],
    ["pieces", "toPcs"]
  ];
  for (const [qtyField, conversionField] of conversions) {
    const conversion = toNumber(item[conversionField]);
    if (!conversion || remaining <= 0) continue;
    const units = Math.floor((remaining / conversion) + 0.000001);
    next[qtyField] = units;
    remaining = Math.round((remaining - (units * conversion)) * 1000000) / 1000000;
  }
  return next;
}

function normalizeDispatchItems(items = []) {
  return (items || []).map((item) => {
    if (toNumber(item.netsuiteReceivedQty) <= 0) return item;
    return deriveDispatchUnitsFromSalesQty(item, item.quantity);
  });
}

function dispatchItemHasQuantity(item = {}) {
  return toNumber(item.pallets) > 0
    || toNumber(item.layers) > 0
    || toNumber(item.sections) > 0
    || toNumber(item.pieces) > 0
    || toNumber(item.quantity) > 0;
}

function purchaseOrderDropoffs(items = [], {
  destinationLocationId = null,
  destinationYard = "",
  destinationAddress = "",
  destinationAddressOverride = ""
} = {}) {
  const headerLocationId = normalizeScmDestinationLocationId(destinationLocationId);
  const headerYard = locationTextFromId(headerLocationId)
    || String(destinationYard || "").trim();
  const cleanAddressOverride = String(destinationAddressOverride || "").trim();
  const matchesHeaderDestination = (locationId, yard) => {
    if (headerLocationId && locationId) return Number(headerLocationId) === Number(locationId);
    if (!headerYard || !yard) return false;
    return String(headerYard).trim().toLowerCase() === String(yard).trim().toLowerCase();
  };
  const groups = new Map();
  for (const item of items.filter(dispatchItemHasQuantity)) {
    const locationId = normalizeScmDestinationLocationId(item.destinationLocationId)
      || normalizeScmDestinationLocationId(destinationLocationId);
    const yard = locationTextFromId(locationId)
      || String(item.destinationYard || destinationYard || "").trim();
    const key = locationId ? `location:${locationId}` : `yard:${yard.toLowerCase()}`;
    if (!groups.has(key)) {
      const defaultAddress = SCM_VRMA_OWN_YARDS.find((candidate) => candidate.code === yard)?.address
        || destinationAddress
        || yard;
      groups.set(key, {
        key,
        destinationLocationId: locationId || null,
        destinationYard: yard,
        defaultAddress,
        address: cleanAddressOverride && matchesHeaderDestination(locationId, yard)
          ? cleanAddressOverride
          : defaultAddress,
        lineRowIds: [],
        pallets: 0,
        layers: 0,
        sections: 0,
        pieces: 0,
        salesQty: 0,
        weight: 0
      });
    }
    const group = groups.get(key);
    if (item.lineRowId !== undefined && item.lineRowId !== null) group.lineRowIds.push(item.lineRowId);
    group.pallets += toNumber(item.pallets);
    group.layers += toNumber(item.layers);
    group.sections += toNumber(item.sections);
    group.pieces += toNumber(item.pieces);
    group.salesQty += toNumber(item.quantity);
    group.weight += toNumber(item.lineWeight);
  }
  if (!groups.size && (destinationYard || destinationLocationId)) {
    const locationId = normalizeScmDestinationLocationId(destinationLocationId)
      || normalizeScmDestinationLocationId(destinationYard);
    const yard = locationTextFromId(locationId) || String(destinationYard || "").trim();
    const key = locationId ? `location:${locationId}` : `yard:${yard.toLowerCase()}`;
    const defaultAddress = destinationAddress
      || SCM_VRMA_OWN_YARDS.find((candidate) => candidate.code === yard)?.address
      || yard;
    groups.set(key, {
      key,
      destinationLocationId: locationId || null,
      destinationYard: yard,
      defaultAddress,
      address: cleanAddressOverride || defaultAddress,
      lineRowIds: [],
      pallets: 0,
      layers: 0,
      sections: 0,
      pieces: 0,
      salesQty: 0,
      weight: 0
    });
  }
  if (groups.size === 1 && !headerLocationId && !headerYard && cleanAddressOverride) {
    const [soleDropoff] = groups.values();
    soleDropoff.address = cleanAddressOverride;
  }
  return [...groups.values()].map((dropoff) => ({
    ...dropoff,
    pallets: Math.round(dropoff.pallets * 1000000) / 1000000,
    layers: Math.round(dropoff.layers * 1000000) / 1000000,
    sections: Math.round(dropoff.sections * 1000000) / 1000000,
    pieces: Math.round(dropoff.pieces * 1000000) / 1000000,
    salesQty: Math.round(dropoff.salesQty * 1000000) / 1000000,
    weight: Math.round(dropoff.weight * 1000) / 1000
  }));
}

function dateOnly(value) {
  if (!value) return "";
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  const text = String(value);
  return text.includes("T") ? text.slice(0, 10) : text;
}

function uniqueDispatchRefs(values = []) {
  const refs = [];
  const seen = new Set();
  for (const value of Array.isArray(values) ? values : []) {
    const ref = String(value || "").trim();
    const key = ref.toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    refs.push(ref);
  }
  return refs;
}

function rowToDispatchOrder(row) {
  const totalPallets = toNumber(row.total_pallet_qty);
  const totalLayers = toNumber(row.total_layer_qty);
  const fallbackQty = toNumber(row.total_quantity);
  const visibleRef = row.dispatch_type === "PO" && row.dispatch_ref ? row.dispatch_ref : row.tranid;
  const localOrderDetails = row.local_order_details
    && typeof row.local_order_details === "object"
    && !Array.isArray(row.local_order_details)
    ? row.local_order_details
    : {};
  const allocationPickups = Array.isArray(row.allocation_pickup_locations)
    ? row.allocation_pickup_locations.filter(Boolean)
    : [];
  const basePickup = row.pickup_location ? [row.pickup_location] : [];
  const pickupLocations = row.transit_co_to_yard
    ? [row.transit_co_to_yard]
    : uniqueDispatchLocations([...basePickup, ...allocationPickups]);
  const address = row.dispatch_type === "PO"
    ? row.drop_address || row.dispatch_address || row.source_address || ""
    : row.drop_address || row.dispatch_address || "";
  const items = normalizeDispatchItems(row.items || []);
  const pallets = dispatchOrderPalletQuantity({
    items,
    reportedPallets: totalPallets,
    fallbackSalesQuantity: fallbackQty,
    preserveReportedPallets: row.source_table === "scm_vrma_orders"
  });
  const salesByUnit = new Map();
  for (const item of items) {
    const unit = String(item.unit || "Qty").trim() || "Qty";
    salesByUnit.set(unit, toNumber(salesByUnit.get(unit)) + toNumber(item.quantity));
  }
  const salesQuantities = [...salesByUnit.entries()].map(([unit, quantity]) => ({ unit, quantity }));
  const transitCo = row.transit_co_ref ? {
    id: row.transit_co_ref,
    fromYard: row.transit_co_from_yard || row.pickup_location || "",
    toYard: row.transit_co_to_yard || "",
    status: row.transit_co_status || "",
    sourceOrderId: visibleRef,
    source: "local-db"
  } : null;
  const effectiveSourceYard = transitCo?.toYard || row.pickup_location || "";
  const destinationYard = row.destination_location || "";
  const destinationAddress = row.default_drop_address || row.drop_address || row.dispatch_address || "";
  const dropoffs = row.dispatch_type === "PO"
    ? purchaseOrderDropoffs(items, {
        destinationLocationId: row.destination_location_id,
        destinationYard,
        destinationAddress,
        destinationAddressOverride: row.delivery_address_override
      })
    : [];
  const sourcePoRefs = Array.isArray(row.scm_source_po_refs)
    ? uniqueDispatchRefs(row.scm_source_po_refs)
    : [];
  const correspondingPoRefs = Array.isArray(row.scm_corresponding_po_refs)
    ? uniqueDispatchRefs(row.scm_corresponding_po_refs)
    : [];
  return {
    id: visibleRef,
    netsuiteId: row.netsuite_id,
    type: row.dispatch_type,
    sourceTable: row.source_table,
    ...(row.dispatch_type === "CO" ? {
      createdAt: row.local_order_created_at,
      updatedAt: row.local_order_updated_at || row.local_order_created_at
    } : {}),
    isBlanket: row.is_blanket_po === true,
    isScmSplit: row.scm_is_split === true,
    sourceOrderId: row.dispatch_type === "CO"
      ? localOrderDetails.sourceOrderId
        || (String(visibleRef || "").startsWith("CO-") ? String(visibleRef).slice(3) : "")
      : "",
    sourceOrderType: row.dispatch_type === "CO" ? localOrderDetails.sourceOrderType || "" : "",
    originalPoRef: row.dispatch_type === "PO" ? row.tranid : "",
    dispatchRef: row.dispatch_ref || "",
    sourcePoRef: sourcePoRefs[0] || "",
    sourcePoRefs,
    correspondingPoRefs,
    customer: row.party || "",
    address,
    sourceYard: effectiveSourceYard,
    sourceAddress: row.pickup_address_override || row.source_address || "",
    defaultSourceAddress: row.source_address || "",
    pickupAddressOverride: row.pickup_address_override || "",
    destinationAddress: row.drop_address || "",
    defaultDestinationAddress: row.default_drop_address || row.drop_address || "",
    deliveryAddressOverride: row.delivery_address_override || "",
    destinationLocationId: row.destination_location_id || null,
    expectedDeliveryDate: dateOnly(row.expected_delivery_date),
    windowStart: row.dispatch_window_start || "",
    windowEnd: row.dispatch_window_end || "",
    instructions: row.dispatch_instructions || "",
    notes: row.dispatch_instructions || "",
    vendorYard: row.dispatch_vendor_yard || "",
    parseSource: row.dispatch_parse_source || "",
    pickupLocations,
    transitOriginalPickupLocations: transitCo?.fromYard ? [transitCo.fromYard] : [],
    transitOriginalSourceYard: transitCo?.fromYard || undefined,
    transitCo,
    destinationYard,
    dropoffs,
    pallets,
    layers: totalLayers,
    salesQty: fallbackQty,
    salesQuantities,
    packed: {
      pallets: toNumber(row.total_packed_pallet_qty),
      layers: toNumber(row.total_packed_layer_qty),
      sections: toNumber(row.total_packed_section_qty),
      pieces: toNumber(row.total_packed_piece_qty)
    },
    weight: Math.round(toNumber(row.total_weight_lbs) * 1000) / 1000,
    items,
    raw: row,
    netsuiteStatus: row.status || "",
    netsuiteStatusText: row.status_text || "",
    fulfillmentStatus: row.fulfillment_status || "",
    netsuiteActive: row.netsuite_active !== false,
    testFixture: isNetSuiteSandboxEnvironment() && /^TSTDEP-SO-/i.test(String(row.tranid || "")),
    operatorStatus: row.operator_status || "",
    localYardOrderStatus: row.local_yard_order_status || "Open",
    dispatchPlanned: Boolean(row.dispatch_planned),
    dispatchPlanDate: dateOnly(row.dispatch_plan_date),
    dispatchTruckPlate: row.dispatch_truck_plate || "",
    dispatchLoadName: row.dispatch_load_name || "",
    dispatchParkingSpot: row.dispatch_parking_spot || "",
    childOrders: Array.isArray(localOrderDetails.childOrderIds)
      ? localOrderDetails.childOrderIds.filter(Boolean)
      : Array.isArray(row.scm_child_orders) ? row.scm_child_orders.filter(Boolean) : [],
    childOrderDetails: Array.isArray(localOrderDetails.childOrderDetails)
      ? localOrderDetails.childOrderDetails.filter(Boolean)
      : [],
    groupAliases: Array.isArray(localOrderDetails.groupAliases)
      ? localOrderDetails.groupAliases.filter(Boolean)
      : [],
    scm: {
      method: row.scm_method || "MBT",
      status: row.scm_status || (
        row.dispatch_type === "PO" && row.source_table === "purchase_orders"
          ? "Hold"
          : "Queued"
      ),
      scheduleId: Number(row.scm_schedule_id) || null,
      updatedAt: row.scm_concurrency_updated_at || row.scm_updated_at || null,
      isSpecialOrder: Boolean(row.scm_is_special_order),
      groupRef: row.scm_group_ref || "",
      packingSlipRef: row.scm_packing_slip_ref || "",
      dropoffPoint: row.scm_dropoff_point || "",
      etaDate: dateOnly(row.scm_eta_date),
      etaTime: row.scm_eta_time || "",
      driver: row.scm_driver || "",
      notes: row.scm_notes || "",
      remarkOverride: row.scm_remark_override || ""
    }
  };
}

function locationIdFromText(value) {
  const text = String(value || "").trim();
  if (text === "3445") return 1;
  if (text === "2967") return 28;
  if (text === "12441") return 15;
  if (text === "150") return 26;
  if (text === "195") return 4;
  return null;
}

function locationTextFromId(value) {
  const text = String(value || "").trim();
  if (text === "1") return "3445";
  if (text === "13" || text === "28") return "2967";
  if (text === "15") return "12441";
  if (text === "26") return "150";
  if (text === "4") return "195";
  return String(value || "").trim();
}

function normalizeScmDestinationLocationId(value) {
  const id = Number(value || 0);
  if ([1, 15, 28, 26].includes(id)) return id;
  const text = String(value || "").trim();
  return locationIdFromText(text);
}

function scmScheduleDestinationLocationIdSql(field) {
  return `CASE BTRIM(COALESCE(${field}, ''))
    WHEN '3445' THEN 1
    WHEN '12441' THEN 15
    WHEN '2967' THEN 28
    WHEN '150' THEN 26
    ELSE NULL
  END`;
}

function scmScheduleDestinationLocationSql(field) {
  return `CASE BTRIM(COALESCE(${field}, ''))
    WHEN '3445' THEN '3445'
    WHEN '12441' THEN '12441'
    WHEN '2967' THEN '2967'
    WHEN '150' THEN '150'
    ELSE NULL
  END`;
}

function yardAddressSql(field) {
  return `CASE
    WHEN ${field} = '3445' THEN '3445 Kennedy Road, Toronto, ON'
    WHEN ${field} = '2967' THEN '2967 Kennedy Road, Toronto, ON'
    WHEN ${field} = '12441' THEN '12441 Woodbine Avenue, Whitchurch-Stouffville, ON'
    WHEN ${field} = '150' THEN '150 Clark Blvd, Brampton, ON L6T 4Y8, Canada'
    WHEN ${field} = '195' THEN '${VOYAGE_DISPATCH_YARD.address}'
    ELSE ''
  END`;
}

export async function listDispatchOrders({
  type = null,
  includeHiddenScm = false,
  includeAllDiscoverableScmPurchaseOrders = false,
  unboundedPerType = false,
  includeInactiveSalesOrderSearchCandidates = false,
  includeFulfilledSalesDeliveries = false,
  includeScmLinkedSearchRefs = false,
  search = "",
  perTypeLimit = DEFAULT_DISPATCH_ORDERS_PER_TYPE,
  exactOrderRefs = []
} = {}) {
  const searchTerm = String(search || "").trim().slice(0, 120);
  const cleanPerTypeLimit = Math.min(Math.max(Number(perTypeLimit) || DEFAULT_DISPATCH_ORDERS_PER_TYPE, 1), MAX_DISPATCH_ORDERS_PER_TYPE);
  const normalizedType = String(type || "").trim().toUpperCase();
  const includeInactiveSalesOrders = Boolean(includeInactiveSalesOrderSearchCandidates && searchTerm);
  const normalizedExactOrderRefs = [...new Set((Array.isArray(exactOrderRefs) ? exactOrderRefs : [])
    .map((ref) => String(ref || "").trim().toUpperCase())
    .filter(Boolean))].slice(0, 200);
  const params = [
    Boolean(includeHiddenScm),
    isNetSuiteSandboxEnvironment(),
    searchTerm,
    cleanPerTypeLimit,
    normalizedType,
    includeInactiveSalesOrders,
    Boolean(includeScmLinkedSearchRefs && searchTerm),
    normalizedExactOrderRefs,
    Boolean(includeAllDiscoverableScmPurchaseOrders),
    Boolean(unboundedPerType),
    Boolean(includeFulfilledSalesDeliveries && (searchTerm || normalizedExactOrderRefs.length))
  ];
  const result = await query(
    `
    WITH requested_exact_refs(requested_ref, numeric_id) AS (
      SELECT normalized.requested_ref,
             CASE
               WHEN normalized.requested_ref ~ '^-?[0-9]{1,19}$'
                AND normalized.requested_ref::numeric BETWEEN
                      -9223372036854775808::numeric AND 9223372036854775807::numeric
               THEN normalized.requested_ref::bigint
               ELSE NULL
             END AS numeric_id
        FROM (
          SELECT DISTINCT UPPER(BTRIM(value)) AS requested_ref
            FROM unnest($8::text[]) input(value)
           WHERE BTRIM(value) <> ''
        ) normalized
    ),
    exact_so_seed_ids(order_id) AS (
      SELECT candidate.netsuite_id
        FROM requested_exact_refs requested
        JOIN sales_orders candidate
          ON UPPER(BTRIM(candidate.tranid)) = requested.requested_ref
      UNION
      SELECT candidate.netsuite_id
        FROM requested_exact_refs requested
        JOIN sales_orders candidate ON candidate.netsuite_id = requested.numeric_id
       WHERE requested.numeric_id IS NOT NULL
      UNION
      SELECT family.source_so_id
        FROM requested_exact_refs requested
        JOIN dispatch_scm_so_splits family
          ON UPPER(BTRIM(family.source_so_ref)) = requested.requested_ref
          OR UPPER(BTRIM(family.split_so_ref)) = requested.requested_ref
      UNION
      SELECT family.split_so_id
        FROM requested_exact_refs requested
        JOIN dispatch_scm_so_splits family
          ON UPPER(BTRIM(family.source_so_ref)) = requested.requested_ref
          OR UPPER(BTRIM(family.split_so_ref)) = requested.requested_ref
    ),
    exact_so_source_ids(source_id) AS (
      SELECT DISTINCT COALESCE(family.source_so_id, seed.order_id)
        FROM exact_so_seed_ids seed
        LEFT JOIN dispatch_scm_so_splits family ON family.split_so_id = seed.order_id
    ),
    exact_so_ids(order_id) AS (
      SELECT source.source_id FROM exact_so_source_ids source
      UNION
      SELECT family.split_so_id
        FROM exact_so_source_ids source
        JOIN dispatch_scm_so_splits family ON family.source_so_id = source.source_id
    ),
    exact_po_seed_ids(order_id) AS (
      SELECT candidate.netsuite_id
        FROM requested_exact_refs requested
        JOIN purchase_orders candidate
          ON UPPER(BTRIM(candidate.tranid)) = requested.requested_ref
          OR UPPER(BTRIM(candidate.dispatch_ref)) = requested.requested_ref
      UNION
      SELECT candidate.netsuite_id
        FROM requested_exact_refs requested
        JOIN purchase_orders candidate ON candidate.netsuite_id = requested.numeric_id
       WHERE requested.numeric_id IS NOT NULL
      UNION
      SELECT family.source_po_id
        FROM requested_exact_refs requested
        JOIN dispatch_scm_po_splits family
          ON UPPER(BTRIM(family.source_po_ref)) = requested.requested_ref
          OR UPPER(BTRIM(family.split_po_ref)) = requested.requested_ref
       WHERE family.source_po_id IS NOT NULL
      UNION
      SELECT family.split_po_id
        FROM requested_exact_refs requested
        JOIN dispatch_scm_po_splits family
          ON UPPER(BTRIM(family.source_po_ref)) = requested.requested_ref
          OR UPPER(BTRIM(family.split_po_ref)) = requested.requested_ref
       WHERE family.split_po_id IS NOT NULL
    ),
    exact_po_source_ids(source_id) AS (
      SELECT DISTINCT COALESCE(family.source_po_id, seed.order_id)
        FROM exact_po_seed_ids seed
        LEFT JOIN dispatch_scm_po_splits family ON family.split_po_id = seed.order_id
    ),
    exact_po_ids(order_id) AS (
      SELECT source.source_id FROM exact_po_source_ids source
      UNION
      SELECT family.split_po_id
        FROM exact_po_source_ids source
        JOIN dispatch_scm_po_splits family ON family.source_po_id = source.source_id
       WHERE family.split_po_id IS NOT NULL
    ),
    exact_to_seed_ids(order_id) AS (
      SELECT candidate.netsuite_id
        FROM requested_exact_refs requested
        JOIN transfer_orders candidate
          ON UPPER(BTRIM(candidate.tranid)) = requested.requested_ref
      UNION
      SELECT candidate.netsuite_id
        FROM requested_exact_refs requested
        JOIN transfer_orders candidate ON candidate.netsuite_id = requested.numeric_id
       WHERE requested.numeric_id IS NOT NULL
      UNION
      SELECT family.source_to_id
        FROM requested_exact_refs requested
        JOIN dispatch_scm_to_splits family
          ON UPPER(BTRIM(family.source_to_ref)) = requested.requested_ref
          OR UPPER(BTRIM(family.split_to_ref)) = requested.requested_ref
      UNION
      SELECT family.split_to_id
        FROM requested_exact_refs requested
        JOIN dispatch_scm_to_splits family
          ON UPPER(BTRIM(family.source_to_ref)) = requested.requested_ref
          OR UPPER(BTRIM(family.split_to_ref)) = requested.requested_ref
    ),
    exact_to_source_ids(source_id) AS (
      SELECT DISTINCT COALESCE(family.source_to_id, seed.order_id)
        FROM exact_to_seed_ids seed
        LEFT JOIN dispatch_scm_to_splits family ON family.split_to_id = seed.order_id
    ),
    exact_to_ids(order_id) AS (
      SELECT source.source_id FROM exact_to_source_ids source
      UNION
      SELECT family.split_to_id
        FROM exact_to_source_ids source
        JOIN dispatch_scm_to_splits family ON family.source_to_id = source.source_id
    ),
    active_po_split_lookup AS (
      SELECT relation.po_id,
             BOOL_OR(relation.is_split) AS is_split,
             jsonb_agg(DISTINCT relation.source_po_ref ORDER BY relation.source_po_ref) AS source_po_refs,
             jsonb_agg(DISTINCT relation.split_po_ref ORDER BY relation.split_po_ref) AS corresponding_po_refs
        FROM (
          SELECT split.source_po_id AS po_id, split.source_po_ref, split.split_po_ref, false AS is_split
            FROM dispatch_scm_po_splits split
           WHERE split.status = 'active'
          UNION ALL
          SELECT split.split_po_id AS po_id, split.source_po_ref, split.split_po_ref, true AS is_split
            FROM dispatch_scm_po_splits split
           WHERE split.status = 'active'
       ) relation
       GROUP BY relation.po_id
    ),
    active_group_po_ref_lookup AS (
      SELECT lower(linked_group.group_ref) AS group_ref_key,
             jsonb_agg(DISTINCT COALESCE(linked_split.source_po_ref, member_po.tranid)
                       ORDER BY COALESCE(linked_split.source_po_ref, member_po.tranid)) AS source_po_refs,
             jsonb_agg(DISTINCT linked_member.order_ref ORDER BY linked_member.order_ref) AS corresponding_po_refs
        FROM scm_schedule_groups linked_group
        JOIN scm_schedule_group_members linked_member
          ON linked_member.group_id = linked_group.id
        JOIN purchase_orders member_po
          ON lower(COALESCE(NULLIF(member_po.dispatch_ref, ''), member_po.tranid)) = lower(linked_member.order_ref)
        LEFT JOIN dispatch_scm_po_splits linked_split
          ON linked_split.split_po_id = member_po.netsuite_id
         AND linked_split.status = 'active'
       WHERE linked_group.status = 'active'
         AND lower(COALESCE(linked_split.source_po_ref, member_po.tranid)) <> lower(linked_member.order_ref)
       GROUP BY lower(linked_group.group_ref)
    ),
    so_alloc AS (
      SELECT sales_line_id,
             SUM(allocated_pallet_qty) AS allocated_pallet_qty,
             SUM(allocated_layer_qty) AS allocated_layer_qty,
             SUM(allocated_section_qty) AS allocated_section_qty,
             SUM(allocated_piece_qty) AS allocated_piece_qty,
             SUM(allocated_sales_qty) AS allocated_sales_qty
        FROM dispatch_so_po_allocations
       WHERE status = 'active'
       GROUP BY sales_line_id
    ),
    po_alloc AS (
      SELECT po_line_id,
             SUM(allocated_pallet_qty) AS allocated_pallet_qty,
             SUM(allocated_layer_qty) AS allocated_layer_qty,
             SUM(allocated_section_qty) AS allocated_section_qty,
             SUM(allocated_piece_qty) AS allocated_piece_qty,
             SUM(allocated_sales_qty) AS allocated_sales_qty
        FROM dispatch_so_po_allocations
       WHERE status = 'active'
       GROUP BY po_line_id
    ),
    scm_po_split_alloc AS (
      SELECT l.source_line_id,
             SUM(l.pallet_qty) AS split_pallet_qty,
             SUM(l.layer_qty) AS split_layer_qty,
             SUM(l.section_qty) AS split_section_qty,
             SUM(l.piece_qty) AS split_piece_qty,
             SUM(l.sales_qty) AS split_sales_qty
        FROM dispatch_scm_po_split_lines l
        JOIN dispatch_scm_po_splits s ON s.id = l.split_id
       WHERE s.status = 'active'
       GROUP BY l.source_line_id
    ),
    delivery_order_source AS (
      SELECT
        netsuite_id,
        tranid,
        trandate AS source_order_date,
        'sales_order'::text AS order_type,
        customer,
        NULL::text AS destination_location,
        expected_delivery_date,
        outbound_location,
        NULL::text AS source_location,
        NULL::bigint AS destination_location_id,
        dispatch_address,
        dispatch_pickup_address,
        dispatch_window_start,
        dispatch_window_end,
        dispatch_instructions,
        dispatch_parse_source,
        operator_status,
        local_yard_order_status,
        dispatch_planned,
        dispatch_plan_date,
        dispatch_truck_plate,
        dispatch_load_name,
        dispatch_parking_spot,
        fulfillment_status,
        status,
        status_text,
        CASE WHEN $2::boolean AND COALESCE(is_test_fixture, false) THEN true ELSE netsuite_active END AS netsuite_active
      FROM sales_orders
      WHERE sales_order_type <> '${CUSTOMER_PICKUP_DELIVERY_METHOD.replaceAll("'", "''")}'
        AND ($11::boolean OR NOT ${billedSalesOrderFamilySql("sales_orders")})
        AND NOT ${netSuiteClosedOrderFamilySql("sales_orders", "SO")}
        AND (COALESCE(is_test_fixture, false) = false OR $2::boolean)
        AND (
          cardinality($8::text[]) = 0
          OR netsuite_id IN (SELECT order_id FROM exact_so_ids)
        )
      UNION ALL
      SELECT
        netsuite_id,
        tranid,
        trandate AS source_order_date,
        'transfer_order'::text AS order_type,
        NULL::text AS customer,
        to_location AS destination_location,
        expected_delivery_date,
        from_location AS outbound_location,
        from_location AS source_location,
        to_location_id AS destination_location_id,
        dispatch_address,
        dispatch_pickup_address,
        dispatch_window_start,
        dispatch_window_end,
        dispatch_instructions,
        dispatch_parse_source,
        outbound_operator_status AS operator_status,
        local_yard_order_status,
        dispatch_planned,
        dispatch_plan_date,
        dispatch_truck_plate,
        dispatch_load_name,
        dispatch_parking_spot,
        fulfillment_status,
        status,
        status_text,
        netsuite_active
      FROM transfer_orders
      WHERE from_location_id IS NOT NULL
        AND NOT ${netSuiteClosedOrderFamilySql("transfer_orders", "TO")}
        AND (
          cardinality($8::text[]) = 0
          OR netsuite_id IN (SELECT order_id FROM exact_to_ids)
        )
    ),
    delivery_line_source AS (
      SELECT
        sales_order_id AS order_id,
        id,
        line_id,
        item_id,
        item_name,
        sku,
        item_description,
        item_type,
        item_type_text,
        quantity,
        unit,
        item_weight,
        pallet_qty,
        layer_qty,
        section_qty,
        piece_qty,
        packed_pallet_qty,
        packed_layer_qty,
        packed_section_qty,
        packed_piece_qty,
        to_plt,
        to_lyr,
        to_sec,
        to_pcs,
        CASE
          WHEN ($2::boolean AND COALESCE(o.is_test_fixture, false)) OR $6::boolean THEN true
          ELSE l.netsuite_active
        END AS netsuite_active
      FROM sales_order_lines l
      JOIN sales_orders o ON o.netsuite_id = l.sales_order_id
      WHERE cardinality($8::text[]) = 0
         OR l.sales_order_id IN (SELECT order_id FROM exact_so_ids)
      UNION ALL
      SELECT
        transfer_order_id AS order_id,
        id,
        line_id,
        item_id,
        item_name,
        sku,
        item_description,
        item_type,
        item_type_text,
        quantity,
        unit,
        item_weight,
        pallet_qty,
        layer_qty,
        section_qty,
        piece_qty,
        packed_pallet_qty,
        packed_layer_qty,
        packed_section_qty,
        packed_piece_qty,
        to_plt,
        to_lyr,
        to_sec,
        to_pcs,
        netsuite_active
      FROM transfer_order_lines
      WHERE line_stage = 'outbound'
        AND (
          cardinality($8::text[]) = 0
          OR transfer_order_id IN (SELECT order_id FROM exact_to_ids)
        )
    ),
    receiving_order_source AS (
      SELECT
        netsuite_id,
        tranid,
        dispatch_ref,
        trandate AS source_order_date,
        'purchase_order'::text AS order_type,
        vendor,
        source_location,
        destination_location,
        destination_location_id,
        expected_delivery_date,
        dispatch_vendor_yard,
        dispatch_address,
        dispatch_delivery_address,
        dispatch_pickup_address,
        dispatch_window_start,
        dispatch_window_end,
        dispatch_instructions,
        dispatch_parse_source,
        NULL::date AS dispatch_plan_date,
        NULL::text AS dispatch_truck_plate,
        NULL::text AS dispatch_load_name,
        NULL::text AS dispatch_parking_spot,
        status_text,
        ${netSuitePendingApprovalSql("purchase_orders")} AS pending_approval,
        initial_scm_status,
        is_blanket_po,
        netsuite_active
      FROM purchase_orders
      WHERE ($9::boolean OR NOT ${netSuiteClosedOrderFamilySql("purchase_orders", "PO")})
        AND (
          cardinality($8::text[]) = 0
          OR netsuite_id IN (SELECT order_id FROM exact_po_ids)
        )
      UNION ALL
      SELECT
        netsuite_id,
        tranid,
        NULL::text AS dispatch_ref,
        trandate AS source_order_date,
        'transfer_order'::text AS order_type,
        NULL::text AS vendor,
        from_location AS source_location,
        to_location AS destination_location,
        to_location_id AS destination_location_id,
        expected_delivery_date,
        NULL::text AS dispatch_vendor_yard,
        dispatch_address,
        ''::text AS dispatch_delivery_address,
        dispatch_pickup_address,
        dispatch_window_start,
        dispatch_window_end,
        dispatch_instructions,
        dispatch_parse_source,
        dispatch_plan_date,
        dispatch_truck_plate,
        dispatch_load_name,
        dispatch_parking_spot,
        status_text,
        ${netSuitePendingApprovalSql("transfer_orders")} AS pending_approval,
        'Queued'::text AS initial_scm_status,
        false AS is_blanket_po,
        netsuite_active
      FROM transfer_orders
      WHERE to_location_id IS NOT NULL
        AND NOT ${netSuiteClosedOrderFamilySql("transfer_orders", "TO")}
        AND (
          cardinality($8::text[]) = 0
          OR netsuite_id IN (SELECT order_id FROM exact_to_ids)
        )
    ),
    po_split_child_line_sequence AS (
      SELECT DISTINCT ON (ledger.split_line_id)
             ledger.split_line_id,
             COALESCE(
               NULLIF(source.raw->>'lineSequenceNumber', ''),
               NULLIF(source.raw->>'line_sequence_number', ''),
               NULLIF(source.raw->>'netSuiteLineSequence', '')
             ) AS netsuite_line_sequence
        FROM dispatch_scm_po_split_lines ledger
        JOIN dispatch_scm_po_splits header
          ON header.id = ledger.split_id
         AND header.status = 'active'
        JOIN purchase_order_lines source ON source.id = ledger.source_line_id
       ORDER BY ledger.split_line_id, header.updated_at DESC, header.id DESC
    ),
    receiving_line_source AS (
      SELECT
        po_line.purchase_order_id AS order_id,
        po_line.id,
        po_line.line_id,
        COALESCE(
          NULLIF(po_line.raw->>'lineSequenceNumber', ''),
          NULLIF(po_line.raw->>'line_sequence_number', ''),
          NULLIF(po_line.raw->>'netSuiteLineSequence', ''),
          child_sequence.netsuite_line_sequence
        ) AS netsuite_line_sequence,
        po_line.item_id,
        po_line.item_name,
        po_line.sku,
        po_line.item_description,
        po_line.quantity,
        po_line.unit,
        po_line.item_weight,
        po_line.pallet_qty,
        po_line.layer_qty,
        po_line.section_qty,
        po_line.piece_qty,
        po_line.netsuite_received_qty,
        po_line.netsuite_received_baseline_qty,
        po_line.to_plt,
        po_line.to_lyr,
        po_line.to_sec,
        po_line.to_pcs,
        po_line.location_id,
        po_line.location,
        po_line.netsuite_active
      FROM purchase_order_lines po_line
      LEFT JOIN po_split_child_line_sequence child_sequence
        ON child_sequence.split_line_id = po_line.id
      WHERE cardinality($8::text[]) = 0
         OR po_line.purchase_order_id IN (SELECT order_id FROM exact_po_ids)
      UNION ALL
      SELECT
        transfer_order_id AS order_id,
        id,
        line_id,
        COALESCE(
          NULLIF(raw->>'lineSequenceNumber', ''),
          NULLIF(raw->>'line_sequence_number', ''),
          NULLIF(raw->>'netSuiteLineSequence', '')
        ) AS netsuite_line_sequence,
        item_id,
        item_name,
        sku,
        item_description,
        quantity,
        unit,
        item_weight,
        pallet_qty,
        layer_qty,
        section_qty,
        piece_qty,
        netsuite_received_qty,
        netsuite_received_qty AS netsuite_received_baseline_qty,
        to_plt,
        to_lyr,
        to_sec,
        to_pcs,
        location_id,
        location,
        netsuite_active
      FROM transfer_order_lines
      WHERE line_stage = 'receiving'
        AND (
          cardinality($8::text[]) = 0
          OR transfer_order_id IN (SELECT order_id FROM exact_to_ids)
        )
    ),
    so_alloc_pickups AS (
      SELECT a.sales_order_id,
             jsonb_agg(DISTINCT COALESCE(NULLIF(po.dispatch_vendor_yard, ''), NULLIF(po.source_location, ''), NULLIF(po.vendor, ''))) FILTER (
               WHERE COALESCE(NULLIF(po.dispatch_vendor_yard, ''), NULLIF(po.source_location, ''), NULLIF(po.vendor, '')) IS NOT NULL
             ) AS pickup_locations
        FROM dispatch_so_po_allocations a
        JOIN purchase_orders po ON po.netsuite_id = a.po_order_id
       WHERE a.status = 'active'
       GROUP BY a.sales_order_id
    ),
    delivery AS (
      SELECT
        o.netsuite_id,
        o.tranid,
        NULL::text AS dispatch_ref,
        o.source_order_date,
        CASE WHEN o.order_type = 'transfer_order' THEN 'TO' ELSE 'SO' END AS dispatch_type,
        CASE WHEN o.order_type = 'transfer_order' THEN 'transfer_orders' ELSE 'sales_orders' END AS source_table,
        COALESCE(o.customer, o.destination_location, '') AS party,
        o.expected_delivery_date,
        o.outbound_location AS pickup_location,
        o.dispatch_pickup_address AS pickup_address_override,
        CASE WHEN o.outbound_location = '195' THEN '${VOYAGE_DISPATCH_YARD.address}' ELSE NULL END AS source_address,
        o.destination_location,
        o.destination_location_id,
        CASE
          WHEN o.order_type = 'transfer_order' THEN ${yardAddressSql("o.destination_location")}
          ELSE o.dispatch_address
        END AS default_drop_address,
        ''::text AS delivery_address_override,
        CASE
          WHEN o.order_type = 'transfer_order' THEN ${yardAddressSql("o.destination_location")}
          ELSE o.dispatch_address
        END AS drop_address,
        o.dispatch_address,
        o.dispatch_window_start,
        o.dispatch_window_end,
        o.dispatch_instructions,
        NULL::text AS dispatch_vendor_yard,
        o.dispatch_parse_source,
        co.co_ref AS transit_co_ref,
        co.from_location AS transit_co_from_yard,
        co.to_location AS transit_co_to_yard,
        co.status AS transit_co_status,
        COALESCE(ap.pickup_locations, '[]'::jsonb) AS allocation_pickup_locations,
        o.operator_status,
        o.local_yard_order_status,
        o.dispatch_planned,
        o.dispatch_plan_date,
        o.dispatch_truck_plate,
        o.dispatch_load_name,
        o.dispatch_parking_spot,
        o.fulfillment_status,
        o.status,
        o.status_text,
        o.netsuite_active,
        'MBT'::text AS scm_method,
        'Queued'::text AS scm_status,
        NULL::bigint AS scm_schedule_id,
        NULL::timestamptz AS scm_updated_at,
        NULL::text AS scm_concurrency_updated_at,
        false AS scm_is_special_order,
        NULL::text AS scm_group_ref,
        NULL::text AS scm_packing_slip_ref,
        NULL::text AS scm_dropoff_point,
        NULL::date AS scm_eta_date,
        NULL::text AS scm_eta_time,
        NULL::text AS scm_driver,
        NULL::text AS scm_notes,
        NULL::text AS scm_remark_override,
        COALESCE(SUM(l.pallet_qty), 0) AS total_pallet_qty,
        COALESCE(SUM(l.layer_qty), 0) AS total_layer_qty,
        COALESCE(SUM(l.quantity), 0) AS total_quantity,
        COALESCE(SUM(l.packed_pallet_qty), 0) AS total_packed_pallet_qty,
        COALESCE(SUM(l.packed_layer_qty), 0) AS total_packed_layer_qty,
        COALESCE(SUM(l.packed_section_qty), 0) AS total_packed_section_qty,
        COALESCE(SUM(l.packed_piece_qty), 0) AS total_packed_piece_qty,
        COALESCE(SUM(COALESCE(l.quantity, 0) * COALESCE(l.item_weight, 0)), 0) AS total_weight_lbs,
        jsonb_agg(jsonb_build_object(
          'lineRowId', l.id,
          'lineId', l.line_id,
          'itemId', l.item_id,
          'sku', COALESCE(l.sku, l.item_name),
          'itemName', l.item_name,
          'description', l.item_description,
          'itemType', l.item_type,
          'itemTypeText', l.item_type_text,
          'pallets', COALESCE(l.pallet_qty, 0),
          'layers', COALESCE(l.layer_qty, 0),
          'sections', COALESCE(l.section_qty, 0),
          'pieces', COALESCE(l.piece_qty, 0),
          'quantity', COALESCE(l.quantity, 0),
          'unit', l.unit,
          'itemWeight', COALESCE(l.item_weight, 0),
          'lineWeight', COALESCE(l.quantity, 0) * COALESCE(l.item_weight, 0),
          'netsuiteReceivedQty', 0,
          'poAllocatedPallets', COALESCE(sa.allocated_pallet_qty, 0),
          'poAllocatedLayers', COALESCE(sa.allocated_layer_qty, 0),
          'poAllocatedSections', COALESCE(sa.allocated_section_qty, 0),
          'poAllocatedPieces', COALESCE(sa.allocated_piece_qty, 0),
          'poAllocatedSalesQty', COALESCE(sa.allocated_sales_qty, 0),
          'toPlt', l.to_plt,
          'toLyr', l.to_lyr,
          'toSec', l.to_sec,
          'toPcs', l.to_pcs
        ) ORDER BY l.line_id NULLS LAST, l.id) FILTER (WHERE l.id IS NOT NULL) AS items
      FROM delivery_order_source o
      LEFT JOIN delivery_line_source l ON l.order_id = o.netsuite_id
        AND (l.netsuite_active = true OR ($11::boolean AND o.order_type = 'sales_order'))
      LEFT JOIN so_alloc sa ON sa.sales_line_id = l.id
      LEFT JOIN LATERAL (
        SELECT co_ref, from_location, to_location, status
          FROM co_orders
         WHERE source_order_ref = o.tranid
           AND status <> 'cancelled'
         ORDER BY updated_at DESC, id DESC
         LIMIT 1
      ) co ON true
      LEFT JOIN so_alloc_pickups ap ON ap.sales_order_id = o.netsuite_id
      WHERE (
        o.netsuite_active = true
        OR co.co_ref IS NOT NULL
        OR (($6::boolean OR $11::boolean) AND o.order_type = 'sales_order')
      )
        AND (
          o.dispatch_planned = true
          OR COALESCE(o.local_yard_order_status, 'Open') IN ('Loaded', 'loaded', 'Shipped', 'shipped', 'Packed', 'packed')
          OR o.fulfillment_status IN ('fulfilled', 'partial_fulfilled', 'partially_fulfilled', 'shipped')
          OR (o.order_type = 'sales_order' AND (
            o.status = 'B'
            OR o.status_text ILIKE '%Pending Fulfillment%'
            OR o.status_text ILIKE '%Partially Fulfilled%'
            OR o.status_text ILIKE '%Pending Billing%'
            OR o.status_text ILIKE '%Billed%'
            OR o.status_text ILIKE '%Fulfilled%'
          ))
          OR (o.order_type = 'transfer_order' AND (
            o.status_text ILIKE '%Pending Fulfillment%'
            OR o.status_text ILIKE '%Partially Fulfilled%'
            OR o.status_text ILIKE '%Pending Receipt%'
            OR o.status_text ILIKE '%Partially Received%'
            OR o.status_text ILIKE '%Received%'
          ))
        )
      GROUP BY o.netsuite_id, o.tranid, o.source_order_date, o.order_type, o.customer, o.destination_location, o.destination_location_id,
               o.expected_delivery_date, o.outbound_location, o.dispatch_address, o.dispatch_pickup_address,
               o.dispatch_window_start, o.dispatch_window_end, o.dispatch_instructions,
               o.dispatch_parse_source, o.operator_status, o.local_yard_order_status,
               o.dispatch_planned, o.dispatch_plan_date, o.dispatch_truck_plate,
               o.dispatch_load_name, o.dispatch_parking_spot, o.fulfillment_status, o.status, o.status_text,
               o.netsuite_active, co.co_ref, co.from_location, co.to_location, co.status, ap.pickup_locations
      HAVING o.dispatch_planned = true OR COUNT(l.id) > 0
    ),
    receiving AS (
      SELECT
        o.netsuite_id,
        o.tranid,
        o.dispatch_ref,
        o.source_order_date,
        CASE WHEN o.order_type = 'transfer_order' THEN 'TO' ELSE 'PO' END AS dispatch_type,
        CASE WHEN o.order_type = 'transfer_order' THEN 'transfer_orders' ELSE 'purchase_orders' END AS source_table,
        COALESCE(o.vendor, o.source_location, '') AS party,
        o.expected_delivery_date,
        COALESCE(NULLIF(scm.pickup_point, ''), NULLIF(o.dispatch_vendor_yard, ''), NULLIF(o.source_location, ''), NULLIF(o.vendor, '')) AS pickup_location,
        o.dispatch_pickup_address AS pickup_address_override,
        COALESCE(NULLIF(schedule_pickup_yard.address, ''), NULLIF(o.dispatch_address, '')) AS source_address,
        COALESCE(NULLIF(scm.dropoff_point, ''), o.destination_location) AS destination_location,
        COALESCE(
          ${scmScheduleDestinationLocationIdSql("scm.dropoff_point")},
          o.destination_location_id
        ) AS destination_location_id,
        ${yardAddressSql("COALESCE(NULLIF(scm.dropoff_point, ''), o.destination_location)")} AS default_drop_address,
        o.dispatch_delivery_address AS delivery_address_override,
        COALESCE(
          NULLIF(o.dispatch_delivery_address, ''),
          ${yardAddressSql("COALESCE(NULLIF(scm.dropoff_point, ''), o.destination_location)")}
        ) AS drop_address,
        o.dispatch_address,
        COALESCE(NULLIF(schedule_pickup_yard.window_start, ''), o.dispatch_window_start) AS dispatch_window_start,
        COALESCE(NULLIF(schedule_pickup_yard.window_end, ''), o.dispatch_window_end) AS dispatch_window_end,
        COALESCE(
          NULLIF(trim(concat_ws(' ', schedule_pickup_yard.day_label, NULLIF(schedule_pickup_yard.instructions, ''))), ''),
          o.dispatch_instructions
        ) AS dispatch_instructions,
        COALESCE(NULLIF(scm.pickup_point, ''), o.dispatch_vendor_yard) AS dispatch_vendor_yard,
        o.dispatch_parse_source,
        NULL::text AS transit_co_ref,
        NULL::text AS transit_co_from_yard,
        NULL::text AS transit_co_to_yard,
        NULL::text AS transit_co_status,
        '[]'::jsonb AS allocation_pickup_locations,
        NULL::text AS operator_status,
        'Open'::text AS local_yard_order_status,
        false AS dispatch_planned,
        o.dispatch_plan_date,
        o.dispatch_truck_plate,
        o.dispatch_load_name,
        o.dispatch_parking_spot,
        NULL::text AS fulfillment_status,
        NULL::text AS status,
        o.status_text,
        o.netsuite_active,
        COALESCE(scm.method, 'MBT') AS scm_method,
        COALESCE(scm.status, o.initial_scm_status, 'Hold') AS scm_status,
        scm.id AS scm_schedule_id,
        scm.updated_at AS scm_updated_at,
        to_char(scm.updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS scm_concurrency_updated_at,
        COALESCE(scm.is_special_order, false) AS scm_is_special_order,
        scm.group_ref AS scm_group_ref,
        scm.packing_slip_ref AS scm_packing_slip_ref,
        NULLIF(BTRIM(scm.dropoff_point), '') AS scm_dropoff_point,
        scm.eta_date AS scm_eta_date,
        scm.eta_time AS scm_eta_time,
        scm.driver AS scm_driver,
        scm.notes AS scm_notes,
        scm.remark_override AS scm_remark_override,
        -- Dispatch SO-to-PO links describe pickup routing. Only receipts and
        -- active SCM splits move quantity out of the source PO balance.
        COALESCE(SUM(GREATEST(COALESCE(l.pallet_qty, 0) - COALESCE(spa.split_pallet_qty, 0), 0)), 0) AS total_pallet_qty,
        COALESCE(SUM(GREATEST(COALESCE(l.layer_qty, 0) - COALESCE(spa.split_layer_qty, 0), 0)), 0) AS total_layer_qty,
        COALESCE(SUM(GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0) - COALESCE(spa.split_sales_qty, 0), 0)), 0) AS total_quantity,
        0::numeric AS total_packed_pallet_qty,
        0::numeric AS total_packed_layer_qty,
        0::numeric AS total_packed_section_qty,
        0::numeric AS total_packed_piece_qty,
        COALESCE(SUM(
          GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0) - COALESCE(spa.split_sales_qty, 0), 0)
          * COALESCE(l.item_weight, 0)
        ), 0) AS total_weight_lbs,
        jsonb_agg(jsonb_build_object(
          'lineRowId', l.id,
          'lineId', l.line_id,
          'netSuiteLineSequence', l.netsuite_line_sequence,
          'itemId', l.item_id,
          'destinationLocationId', COALESCE(
            ${scmScheduleDestinationLocationIdSql("scm.dropoff_point")},
            l.location_id,
            o.destination_location_id
          ),
          'destinationYard', COALESCE(
            ${scmScheduleDestinationLocationSql("scm.dropoff_point")},
            NULLIF(l.location, ''),
            o.destination_location
          ),
          'sku', COALESCE(l.sku, l.item_name),
          'itemName', l.item_name,
          'description', l.item_description,
          'pallets', GREATEST(COALESCE(l.pallet_qty, 0) - COALESCE(spa.split_pallet_qty, 0), 0),
          'layers', GREATEST(COALESCE(l.layer_qty, 0) - COALESCE(spa.split_layer_qty, 0), 0),
          'sections', GREATEST(COALESCE(l.section_qty, 0) - COALESCE(spa.split_section_qty, 0), 0),
          'pieces', GREATEST(COALESCE(l.piece_qty, 0) - COALESCE(spa.split_piece_qty, 0), 0),
          'quantity', GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0) - COALESCE(spa.split_sales_qty, 0), 0),
          'unit', l.unit,
          'itemWeight', COALESCE(l.item_weight, 0),
          'lineWeight', GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0) - COALESCE(spa.split_sales_qty, 0), 0) * COALESCE(l.item_weight, 0),
          'netsuiteReceivedQty', COALESCE(l.netsuite_received_qty, 0),
          'netsuiteReceivedBaselineQty', COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0),
          'poAllocatedPallets', COALESCE(pa.allocated_pallet_qty, 0),
          'poAllocatedLayers', COALESCE(pa.allocated_layer_qty, 0),
          'poAllocatedSections', COALESCE(pa.allocated_section_qty, 0),
          'poAllocatedPieces', COALESCE(pa.allocated_piece_qty, 0),
          'poAllocatedSalesQty', COALESCE(pa.allocated_sales_qty, 0),
          'scmSplitAllocatedPallets', COALESCE(spa.split_pallet_qty, 0),
          'scmSplitAllocatedLayers', COALESCE(spa.split_layer_qty, 0),
          'scmSplitAllocatedSections', COALESCE(spa.split_section_qty, 0),
          'scmSplitAllocatedPieces', COALESCE(spa.split_piece_qty, 0),
          'scmSplitAllocatedSalesQty', COALESCE(spa.split_sales_qty, 0),
          'toPlt', l.to_plt,
          'toLyr', l.to_lyr,
          'toSec', l.to_sec,
          'toPcs', l.to_pcs
        ) ORDER BY
          CASE
            WHEN l.netsuite_line_sequence ~ '^[0-9]+([.][0-9]+)?$'
              AND l.netsuite_line_sequence::numeric > 0
            THEN l.netsuite_line_sequence::numeric
            ELSE NULL
          END NULLS LAST,
          l.line_id NULLS LAST,
          l.id) FILTER (WHERE l.id IS NOT NULL) AS items
      FROM receiving_order_source o
      LEFT JOIN scm_transport_schedule scm
        ON scm.order_kind = CASE WHEN o.order_type = 'transfer_order' THEN 'TO' ELSE 'PO' END
       AND lower(scm.order_ref) = lower(COALESCE(NULLIF(o.dispatch_ref, ''), o.tranid))
      LEFT JOIN LATERAL (
        SELECT y.address, y.window_start, y.window_end, y.instructions, y.day_label
          FROM dispatch_vendor_yards y
         WHERE y.active = true
           AND lower(y.yard) = lower(COALESCE(NULLIF(scm.pickup_point, ''), NULLIF(o.dispatch_vendor_yard, '')))
         ORDER BY CASE WHEN y.day_label = 'Mon-Fri' THEN 0 ELSE 1 END, y.id
         LIMIT 1
      ) schedule_pickup_yard ON true
      LEFT JOIN receiving_line_source l ON l.order_id = o.netsuite_id AND l.netsuite_active = true
      LEFT JOIN po_alloc pa ON pa.po_line_id = l.id
      LEFT JOIN scm_po_split_alloc spa ON spa.source_line_id = l.id
      WHERE o.netsuite_active = true
        AND (
          $1::boolean
          OR NOT COALESCE(o.is_blanket_po, false)
        )
        AND (
          $1::boolean
          OR COALESCE(scm.method, 'MBT') = 'MBT'
        )
        AND (
          $1::boolean
          OR LOWER(BTRIM(COALESCE(scm.status, o.initial_scm_status, 'Hold'))) NOT IN (
            'hold', 'complete', 'completed', 'cancelled', 'canceled'
          )
          OR (
            $7::boolean
            AND o.order_type = 'purchase_order'
            AND LOWER(BTRIM(COALESCE(scm.status, o.initial_scm_status, 'Hold'))) = 'hold'
            AND EXISTS (
              SELECT 1
                FROM dispatch_scm_po_splits searchable_split
               WHERE searchable_split.status = 'active'
                 AND searchable_split.split_po_id = o.netsuite_id
                 AND (
                   searchable_split.source_po_ref ILIKE '%' || $3 || '%'
                   OR searchable_split.split_po_ref ILIKE '%' || $3 || '%'
                 )
            )
          )
        )
        AND (
          ($9::boolean AND o.order_type = 'purchase_order' AND NOT o.pending_approval)
          OR (
            (NOT $9::boolean OR o.order_type <> 'purchase_order')
            AND (
              o.status_text ILIKE '%Pending Receipt%'
              OR o.status_text ILIKE '%Partially Received%'
              OR o.status_text ILIKE '%Received%'
              -- NetSuite emits both "Pending Bill" and "Pending Billing". The
              -- remaining-quantity filters below still remove genuinely completed
              -- receipt lines while retaining locally corrected baselines.
              OR o.status_text ILIKE '%Pending Bill%'
              OR o.status_text ILIKE '%Billed%'
            )
          )
        )
        AND NOT EXISTS (
          SELECT 1
          FROM transfer_orders d
          WHERE d.netsuite_id = o.netsuite_id
            AND d.netsuite_active = true
            AND d.fulfillment_status <> 'fulfilled'
        )
      GROUP BY o.netsuite_id, o.tranid, o.source_order_date, o.order_type, o.vendor, o.source_location,
                o.dispatch_ref,
                o.destination_location, o.destination_location_id, o.expected_delivery_date, o.dispatch_vendor_yard,
               o.dispatch_address, o.dispatch_delivery_address, o.dispatch_pickup_address, o.dispatch_window_start, o.dispatch_window_end,
               o.dispatch_instructions, o.dispatch_parse_source, o.dispatch_plan_date,
               o.dispatch_truck_plate, o.dispatch_load_name, o.dispatch_parking_spot,
               o.status_text, o.initial_scm_status, o.is_blanket_po, o.netsuite_active,
               scm.id, scm.updated_at, scm.method, scm.status, scm.is_special_order,
               scm.group_ref, scm.packing_slip_ref, scm.pickup_point, scm.dropoff_point,
               scm.eta_date, scm.eta_time, scm.driver, scm.notes,
               schedule_pickup_yard.address, schedule_pickup_yard.window_start, schedule_pickup_yard.window_end,
               schedule_pickup_yard.instructions, schedule_pickup_yard.day_label
      HAVING $1::boolean
          OR o.dispatch_plan_date IS NOT NULL
          OR COALESCE(SUM(GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0) - COALESCE(spa.split_sales_qty, 0), 0)), 0) > 0.000001
    ),
    local_co AS (
      SELECT
        co.delivery_order_id AS netsuite_id,
        co.co_ref AS tranid,
        NULL::text AS dispatch_ref,
        co.created_at AS source_order_date,
        'CO' AS dispatch_type,
        'local_co_orders' AS source_table,
        COALESCE(co.details->>'customer', 'Transit Depot') AS party,
        co.dispatch_plan_date AS expected_delivery_date,
        co.from_location AS pickup_location,
        ''::text AS pickup_address_override,
        ${yardAddressSql("co.from_location")} AS source_address,
        co.to_location AS destination_location,
        co.to_location_id AS destination_location_id,
        ${yardAddressSql("co.to_location")} AS default_drop_address,
        ''::text AS delivery_address_override,
        ${yardAddressSql("co.to_location")} AS drop_address,
        ${yardAddressSql("co.to_location")} AS dispatch_address,
        ''::text AS dispatch_window_start,
        ''::text AS dispatch_window_end,
        COALESCE(co.details->>'notes', 'Local transit depot order') AS dispatch_instructions,
        NULL::text AS dispatch_vendor_yard,
        'local-co'::text AS dispatch_parse_source,
        NULL::text AS transit_co_ref,
        NULL::text AS transit_co_from_yard,
        NULL::text AS transit_co_to_yard,
        NULL::text AS transit_co_status,
        '[]'::jsonb AS allocation_pickup_locations,
        NULL::text AS operator_status,
        COALESCE(co.status, 'planned') AS local_yard_order_status,
        (co.dispatch_plan_id IS NOT NULL OR co.dispatch_plan_date IS NOT NULL) AS dispatch_planned,
        co.dispatch_plan_date,
        co.dispatch_truck_plate,
        co.dispatch_load_name,
        co.dispatch_parking_spot,
        NULL::text AS fulfillment_status,
        co.status AS status,
        co.status AS status_text,
        true AS netsuite_active,
        'MBT'::text AS scm_method,
        'Queued'::text AS scm_status,
        NULL::bigint AS scm_schedule_id,
        NULL::timestamptz AS scm_updated_at,
        NULL::text AS scm_concurrency_updated_at,
        false AS scm_is_special_order,
        NULL::text AS scm_group_ref,
        NULL::text AS scm_packing_slip_ref,
        NULL::text AS scm_dropoff_point,
        NULL::date AS scm_eta_date,
        NULL::text AS scm_eta_time,
        NULL::text AS scm_driver,
        NULL::text AS scm_notes,
        NULL::text AS scm_remark_override,
        COALESCE(SUM(l.pallet_qty), 0) AS total_pallet_qty,
        COALESCE(SUM(l.layer_qty), 0) AS total_layer_qty,
        COALESCE(SUM(l.quantity), 0) AS total_quantity,
        0::numeric AS total_packed_pallet_qty,
        0::numeric AS total_packed_layer_qty,
        0::numeric AS total_packed_section_qty,
        0::numeric AS total_packed_piece_qty,
        COALESCE(SUM(COALESCE(l.quantity, 0) * COALESCE(l.item_weight, 0)), 0) AS total_weight_lbs,
        jsonb_agg(jsonb_build_object(
          'sku', COALESCE(l.sku, l.item_name),
          'itemName', l.item_name,
          'description', l.item_description,
          'pallets', COALESCE(l.pallet_qty, 0),
          'layers', COALESCE(l.layer_qty, 0),
          'sections', COALESCE(l.section_qty, 0),
          'pieces', COALESCE(l.piece_qty, 0),
          'quantity', COALESCE(l.quantity, 0),
          'unit', l.unit,
          'itemWeight', COALESCE(l.item_weight, 0),
          'lineWeight', COALESCE(l.quantity, 0) * COALESCE(l.item_weight, 0)
        ) ORDER BY l.line_id NULLS LAST, l.id) FILTER (WHERE l.id IS NOT NULL) AS items
      FROM co_orders co
      LEFT JOIN co_order_lines l ON l.co_id = co.id
      WHERE co.status IN ('pending_load', 'planned')
        AND (
          cardinality($8::text[]) = 0
          OR UPPER(BTRIM(co.co_ref)) = ANY($8::text[])
          OR UPPER(BTRIM(co.source_order_ref)) = ANY($8::text[])
          OR co.delivery_order_id::text = ANY($8::text[])
        )
      GROUP BY co.id
    ),
    local_vrma AS (
      SELECT
        -v.id AS netsuite_id,
        v.vrma_ref AS tranid,
        NULL::text AS dispatch_ref,
        v.created_at::date AS source_order_date,
        'PO' AS dispatch_type,
        'scm_vrma_orders' AS source_table,
        COALESCE(v.local_vendor, v.vendor, 'Vendor Return') AS party,
        scm.eta_date AS expected_delivery_date,
        v.pickup_location AS pickup_location,
        ''::text AS pickup_address_override,
        ${yardAddressSql("v.pickup_location")} AS source_address,
        v.dropoff_location AS destination_location,
        NULL::bigint AS destination_location_id,
        COALESCE(vrma_yard.address, '') AS default_drop_address,
        ''::text AS delivery_address_override,
        COALESCE(vrma_yard.address, '') AS drop_address,
        COALESCE(vrma_yard.address, '') AS dispatch_address,
        COALESCE(vrma_yard.window_start, '') AS dispatch_window_start,
        COALESCE(vrma_yard.window_end, '') AS dispatch_window_end,
        COALESCE(NULLIF(trim(concat_ws(' | ', NULLIF(v.notes, ''), NULLIF(vrma_yard.instructions, ''))), ''), 'Vendor return') AS dispatch_instructions,
        COALESCE(v.local_vendor, v.vendor, scm.brand) AS dispatch_vendor_yard,
        'scm-vrma'::text AS dispatch_parse_source,
        active_co.co_ref AS transit_co_ref,
        active_co.from_location AS transit_co_from_yard,
        active_co.to_location AS transit_co_to_yard,
        active_co.status AS transit_co_status,
        '[]'::jsonb AS allocation_pickup_locations,
        NULL::text AS operator_status,
        'Open'::text AS local_yard_order_status,
        false AS dispatch_planned,
        NULL::date AS dispatch_plan_date,
        NULL::text AS dispatch_truck_plate,
        NULL::text AS dispatch_load_name,
        NULL::text AS dispatch_parking_spot,
        NULL::text AS fulfillment_status,
        v.status AS status,
        v.status AS status_text,
        true AS netsuite_active,
        COALESCE(scm.method, v.method, 'MBT') AS scm_method,
        COALESCE(scm.status, v.status, 'Queued') AS scm_status,
        scm.id AS scm_schedule_id,
        scm.updated_at AS scm_updated_at,
        to_char(scm.updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS scm_concurrency_updated_at,
        false AS scm_is_special_order,
        scm.group_ref AS scm_group_ref,
        scm.packing_slip_ref AS scm_packing_slip_ref,
        NULLIF(BTRIM(scm.dropoff_point), '') AS scm_dropoff_point,
        scm.eta_date AS scm_eta_date,
        scm.eta_time AS scm_eta_time,
        scm.driver AS scm_driver,
        scm.notes AS scm_notes,
        scm.remark_override AS scm_remark_override,
        COALESCE(SUM(l.pallet_qty), 0) AS total_pallet_qty,
        COALESCE(SUM(l.layer_qty), 0) AS total_layer_qty,
        COALESCE(SUM(l.quantity), 0) AS total_quantity,
        0::numeric AS total_packed_pallet_qty,
        0::numeric AS total_packed_layer_qty,
        0::numeric AS total_packed_section_qty,
        0::numeric AS total_packed_piece_qty,
        COALESCE(SUM(COALESCE(l.weight_lbs, 0)), COALESCE(scm.weight_lbs, 0), 0) AS total_weight_lbs,
        jsonb_agg(jsonb_build_object(
          'lineRowId', l.id,
          'lineId', l.id,
          'itemId', l.item_id,
          'sku', COALESCE(l.sku, l.item_name),
          'itemName', l.item_name,
          'description', COALESCE(l.item_description, ''),
          'pallets', COALESCE(l.pallet_qty, 0),
          'layers', COALESCE(l.layer_qty, 0),
          'sections', COALESCE(l.section_qty, 0),
          'pieces', COALESCE(l.piece_qty, 0),
          'quantity', COALESCE(l.quantity, 0),
          'unit', l.unit,
          'itemWeight', CASE WHEN COALESCE(l.quantity, 0) = 0 THEN 0 ELSE COALESCE(l.weight_lbs, 0) / NULLIF(l.quantity, 0) END,
          'lineWeight', COALESCE(l.weight_lbs, 0),
          'netsuiteReceivedQty', 0,
          'toPlt', COALESCE(l.to_plt, 0),
          'toLyr', COALESCE(l.to_lyr, 0),
          'toSec', COALESCE(l.to_sec, 0),
          'toPcs', COALESCE(l.to_pcs, 0)
        ) ORDER BY l.id) FILTER (WHERE l.id IS NOT NULL) AS items
      FROM scm_vrma_orders v
      LEFT JOIN scm_transport_schedule scm ON scm.order_kind = 'VRMA' AND lower(scm.order_ref) = lower(v.vrma_ref)
      LEFT JOIN LATERAL (
        SELECT co.co_ref, co.from_location, co.to_location, co.status
          FROM local_co_orders co
         WHERE co.source_order_ref = v.vrma_ref
           AND co.status <> 'cancelled'
         ORDER BY co.updated_at DESC, co.id DESC
         LIMIT 1
      ) active_co ON true
      LEFT JOIN LATERAL (
        SELECT y.id, y.address, y.window_start, y.window_end, y.instructions
          FROM dispatch_vendor_yards y
         WHERE y.active = true
           AND LOWER(y.vendor) = LOWER(COALESCE(v.local_vendor, v.vendor, ''))
           AND LOWER(y.yard) = LOWER(COALESCE(v.dropoff_location, ''))
         ORDER BY y.id
         LIMIT 1
      ) vrma_yard ON true
      LEFT JOIN scm_vrma_order_lines l ON l.vrma_order_id = v.id
      WHERE v.pickup_location IN ('3445', '2967', '12441', '150')
        AND vrma_yard.id IS NOT NULL
        AND (
          cardinality($8::text[]) = 0
          OR UPPER(BTRIM(v.vrma_ref)) = ANY($8::text[])
          OR v.id::text = ANY($8::text[])
          OR (-v.id)::text = ANY($8::text[])
        )
        AND (
          $1::boolean
          OR COALESCE(scm.method, v.method, 'MBT') = 'MBT'
        )
        AND (
          $1::boolean
          OR LOWER(BTRIM(COALESCE(scm.status, v.status, 'Queued'))) NOT IN (
            'hold', 'complete', 'completed', 'cancelled', 'canceled'
          )
        )
      GROUP BY v.id, scm.id,
               active_co.co_ref, active_co.from_location, active_co.to_location, active_co.status,
               vrma_yard.address, vrma_yard.window_start, vrma_yard.window_end, vrma_yard.instructions
    ),
    eligible_orders AS (
      SELECT * FROM delivery
      UNION ALL
      SELECT * FROM receiving
      UNION ALL
      SELECT * FROM local_co
      UNION ALL
      SELECT * FROM local_vrma
    ),
    ranked_orders AS (
      SELECT eligible_orders.*,
             ROW_NUMBER() OVER (
               PARTITION BY dispatch_type
               ORDER BY CASE WHEN $2::boolean AND tranid LIKE 'TSTDEP-SO-%' THEN 0 ELSE 1 END,
                        source_order_date DESC NULLS LAST, netsuite_id DESC, tranid DESC
             ) AS dispatch_type_rank
        FROM eligible_orders
       WHERE ($5::text = '' OR dispatch_type = $5)
         AND (
           cardinality($8::text[]) > 0
           OR $3::text = ''
           OR tranid ILIKE '%' || $3 || '%'
           OR netsuite_id::text = $3
           OR COALESCE(dispatch_ref, '') ILIKE '%' || $3 || '%'
           OR COALESCE(party, '') ILIKE '%' || $3 || '%'
           OR COALESCE(drop_address, '') ILIKE '%' || $3 || '%'
           OR COALESCE(pickup_location, '') ILIKE '%' || $3 || '%'
           OR COALESCE(destination_location, '') ILIKE '%' || $3 || '%'
           OR COALESCE(dispatch_instructions, '') ILIKE '%' || $3 || '%'
           OR COALESCE(items, '[]'::jsonb)::text ILIKE '%' || $3 || '%'
           OR (
             $7::boolean
             AND dispatch_type = 'PO'
             AND EXISTS (
               SELECT 1
                 FROM dispatch_scm_po_splits linked_split
                WHERE linked_split.status = 'active'
                  AND linked_split.split_po_id = eligible_orders.netsuite_id
                  AND (
                    linked_split.source_po_ref ILIKE '%' || $3 || '%'
                    OR linked_split.split_po_ref ILIKE '%' || $3 || '%'
                  )
             )
           )
           OR (
             $7::boolean
             AND dispatch_type = 'PO'
             AND EXISTS (
               SELECT 1
                 FROM scm_schedule_groups linked_group
                 JOIN scm_schedule_group_members linked_member
                   ON linked_member.group_id = linked_group.id
                WHERE linked_group.status = 'active'
                  AND lower(linked_group.group_ref) = lower(COALESCE(NULLIF(eligible_orders.dispatch_ref, ''), eligible_orders.tranid))
                  AND (
                    linked_member.order_ref ILIKE '%' || $3 || '%'
                    OR EXISTS (
                      SELECT 1
                        FROM purchase_orders member_po
                       WHERE lower(COALESCE(NULLIF(member_po.dispatch_ref, ''), member_po.tranid)) = lower(linked_member.order_ref)
                         AND member_po.tranid ILIKE '%' || $3 || '%'
                    )
                    OR EXISTS (
                      SELECT 1
                        FROM dispatch_scm_po_splits member_split
                       WHERE member_split.status = 'active'
                         AND lower(member_split.split_po_ref) = lower(linked_member.order_ref)
                         AND member_split.source_po_ref ILIKE '%' || $3 || '%'
                    )
                  )
             )
           )
         )
    )
    SELECT orders.*,
           pool_co.created_at AS local_order_created_at,
           pool_co.updated_at AS local_order_updated_at,
           COALESCE(split_lookup.is_split, false) AS scm_is_split,
           COALESCE(split_lookup.source_po_refs, '[]'::jsonb)
             || COALESCE(group_ref_lookup.source_po_refs, '[]'::jsonb) AS scm_source_po_refs,
           COALESCE(split_lookup.corresponding_po_refs, '[]'::jsonb)
             || COALESCE(group_ref_lookup.corresponding_po_refs, '[]'::jsonb) AS scm_corresponding_po_refs,
           COALESCE((
             SELECT jsonb_agg(m.order_ref ORDER BY m.order_ref)
               FROM scm_schedule_groups g
               JOIN scm_schedule_group_members m ON m.group_id = g.id
              WHERE g.status = 'active'
                AND orders.dispatch_type = 'PO'
                AND lower(g.group_ref) = lower(COALESCE(NULLIF(orders.dispatch_ref, ''), orders.tranid))
           ), '[]'::jsonb) AS scm_child_orders,
           CASE
             WHEN orders.source_table = 'local_co_orders' THEN COALESCE((
               SELECT co.details
                 FROM local_co_orders co
                WHERE lower(co.co_ref) = lower(orders.tranid)
                ORDER BY co.updated_at DESC, co.id DESC
                LIMIT 1
             ), '{}'::jsonb)
             ELSE '{}'::jsonb
           END AS local_order_details
    FROM ranked_orders orders
    LEFT JOIN co_orders pool_co
      ON orders.dispatch_type = 'CO'
     AND pool_co.co_ref = orders.tranid
    LEFT JOIN active_po_split_lookup split_lookup
      ON orders.dispatch_type = 'PO'
     AND split_lookup.po_id = orders.netsuite_id
    LEFT JOIN active_group_po_ref_lookup group_ref_lookup
      ON orders.dispatch_type = 'PO'
     AND group_ref_lookup.group_ref_key = lower(COALESCE(NULLIF(orders.dispatch_ref, ''), orders.tranid))
    WHERE $3::text <> ''
       OR $10::boolean
       OR orders.dispatch_type_rank <= $4
       OR orders.dispatch_planned = true
    ORDER BY CASE WHEN $2::boolean AND tranid LIKE 'TSTDEP-SO-%' THEN 0 ELSE 1 END,
             source_order_date DESC NULLS LAST, netsuite_id DESC, tranid DESC
    LIMIT CASE WHEN $3::text <> '' THEN 200 ELSE NULL END
    `,
    params
  );
  return result.rows.map(rowToDispatchOrder);
}

export async function searchSalesOrderMethodOverrides({ search = "", limit = 30 } = {}) {
  const term = String(search || "").trim();
  const cleanLimit = Math.min(Math.max(Number(limit) || 30, 1), 100);
  const result = await query(
    `SELECT o.netsuite_id, o.tranid, o.customer, o.status, o.status_text,
            o.delivery_method_id,
            o.sales_order_type AS local_method,
            COALESCE(o.netsuite_sales_order_type, o.sales_order_type) AS netsuite_method,
            o.sales_order_type_override AS override_active,
            o.outbound_location_id, o.outbound_location,
            o.trandate, o.expected_delivery_date, o.synced_at,
            COUNT(l.id) FILTER (WHERE l.netsuite_active = true) AS active_line_count,
            COALESCE(SUM(l.quantity) FILTER (WHERE l.netsuite_active = true), 0) AS total_sales_qty
       FROM sales_orders o
       LEFT JOIN sales_order_lines l ON l.sales_order_id = o.netsuite_id
      WHERE ($1 = ''
             OR lower(o.tranid) LIKE '%' || lower($1) || '%'
             OR lower(COALESCE(o.customer, '')) LIKE '%' || lower($1) || '%')
      GROUP BY o.netsuite_id
      ORDER BY
        CASE WHEN lower(o.tranid) = lower($1) THEN 0 ELSE 1 END,
        o.trandate DESC NULLS LAST,
        o.tranid DESC
      LIMIT $2`,
    [term, cleanLimit]
  );
  return result.rows.map((row) => ({
    netsuiteId: row.netsuite_id,
    tranid: row.tranid,
    customer: row.customer || "",
    status: row.status || "",
    statusText: row.status_text || "",
    deliveryMethodId: row.delivery_method_id,
    localMethod: row.local_method || "",
    netsuiteMethod: row.netsuite_method || "",
    overrideActive: Boolean(row.override_active),
    outboundLocationId: row.outbound_location_id,
    outboundLocation: row.outbound_location || "",
    trandate: row.trandate,
    expectedDeliveryDate: row.expected_delivery_date,
    syncedAt: row.synced_at,
    activeLineCount: Number(row.active_line_count || 0),
    totalSalesQty: Number(row.total_sales_qty || 0),
    dispatchVisible: String(row.local_method || "") !== CUSTOMER_PICKUP_DELIVERY_METHOD
  }));
}

export async function updateSalesOrderLocalMethod(tranid, { method = "", updatedBy = "" } = {}) {
  const orderRef = String(tranid || "").trim();
  if (!orderRef) throw new Error("Sales order number is required.");
  await assertNoClosedNetSuiteOrders([orderRef], "change delivery method in Dispatch");
  const normalizedMethod = String(method || "").trim();
  const allowed = new Set(["Delivery", CUSTOMER_PICKUP_DELIVERY_METHOD]);
  if (!allowed.has(normalizedMethod)) throw new Error("Local method must be Delivery or Pick-Up.");

  const result = await query(
    `UPDATE sales_orders
        SET netsuite_sales_order_type = COALESCE(netsuite_sales_order_type, sales_order_type),
            sales_order_type = $2,
            sales_order_type_override = (COALESCE(netsuite_sales_order_type, sales_order_type) IS DISTINCT FROM $2),
            sales_order_type_updated_by = $3,
            sales_order_type_updated_at = now(),
            synced_at = now()
      WHERE lower(tranid) = lower($1)
      RETURNING netsuite_id, tranid, customer, status, status_text,
                sales_order_type AS local_method,
                COALESCE(netsuite_sales_order_type, sales_order_type) AS netsuite_method,
                sales_order_type_override AS override_active,
                outbound_location_id, outbound_location, synced_at`,
    [orderRef, normalizedMethod, updatedBy || null]
  );
  const row = result.rows[0];
  if (!row) return null;
  return {
    netsuiteId: row.netsuite_id,
    tranid: row.tranid,
    customer: row.customer || "",
    status: row.status || "",
    statusText: row.status_text || "",
    localMethod: row.local_method || "",
    netsuiteMethod: row.netsuite_method || "",
    overrideActive: Boolean(row.override_active),
    outboundLocationId: row.outbound_location_id,
    outboundLocation: row.outbound_location || "",
    syncedAt: row.synced_at,
    dispatchVisible: String(row.local_method || "") !== CUSTOMER_PICKUP_DELIVERY_METHOD
  };
}

async function executeDispatchEnrichment({ force, delivery: includeDelivery, receiving: includeReceiving }) {
  let deliveryCount = 0;
  if (includeDelivery) {
    const delivery = await query(
      `SELECT netsuite_id, 'sales_order'::text AS order_type, memo,
              expected_delivery_date,
              outbound_location_id, outbound_location,
              NULL::bigint AS destination_location_id, NULL::text AS destination_location,
              NULL::bigint AS source_location_id, NULL::text AS source_location
        FROM sales_orders
        WHERE netsuite_active = true
          AND ($1::boolean OR dispatch_note_hash IS NULL OR dispatch_parse_source IS NULL
               OR dispatch_instruction_parse_version < 2)
       UNION ALL
       SELECT netsuite_id, 'transfer_order'::text AS order_type, memo,
              expected_delivery_date,
              from_location_id AS outbound_location_id, from_location AS outbound_location,
              to_location_id AS destination_location_id, to_location AS destination_location,
              from_location_id AS source_location_id, from_location AS source_location
         FROM transfer_orders
        WHERE netsuite_active = true
          AND from_location_id IS NOT NULL
          AND ($1::boolean OR dispatch_note_hash IS NULL OR dispatch_parse_source IS NULL)`,
      [force]
    );
    for (const row of delivery.rows) {
      const isTransferOrder = row.order_type === "transfer_order";
      const dispatch = isTransferOrder
        ? enrichTransferDispatch(row)
        : await enrichSalesOrderDispatch(row);
      await query(
        `UPDATE ${isTransferOrder ? "transfer_orders" : "sales_orders"}
            SET dispatch_address = $2,
                dispatch_window_start = $3,
                dispatch_window_end = $4,
                dispatch_instructions = $5,
                dispatch_parse_source = $6,
                dispatch_note_hash = $7,
                expected_delivery_date = CASE
                  WHEN expected_delivery_date IS NOT NULL THEN expected_delivery_date
                  WHEN $8::date IS NULL THEN expected_delivery_date
                  ELSE $8::date
                END,
                dispatch_parsed_at = now()
                ${isTransferOrder ? "" : `,
                dispatch_instruction_details = $9::jsonb,
                dispatch_instruction_parse_version = $10,
                dispatch_instruction_parsed_at = $11::timestamptz`}
          WHERE netsuite_id = $1`,
        [
          row.netsuite_id,
          dispatch.dispatch_address,
          dispatch.dispatch_window_start,
          dispatch.dispatch_window_end,
          dispatch.dispatch_instructions,
          dispatch.dispatch_parse_source,
          dispatch.dispatch_note_hash,
          dispatch.expected_delivery_date || null,
          ...(isTransferOrder ? [] : [
            JSON.stringify(dispatch.dispatch_instruction_details || {}),
            dispatch.dispatch_instruction_parse_version || 0,
            dispatch.dispatch_instruction_parsed_at || null
          ])
        ]
      );
      deliveryCount += 1;
    }
  }

  let receivingCount = 0;
  if (includeReceiving) {
    const receiving = await query(
      `SELECT netsuite_id, 'purchase_order'::text AS order_type, memo, vendor_id::text AS vendor_id, vendor, vendor_address,
               source_location_id, source_location, destination_location_id, destination_location, tranid
          FROM purchase_orders
         WHERE netsuite_active = true
           AND ($1::boolean OR dispatch_note_hash IS NULL OR dispatch_parse_source IS NULL)
        UNION ALL
        SELECT netsuite_id, 'transfer_order'::text AS order_type, memo, NULL::text AS vendor_id, NULL::text AS vendor, NULL::text AS vendor_address,
               from_location_id AS source_location_id, from_location AS source_location,
               to_location_id AS destination_location_id, to_location AS destination_location, tranid
         FROM transfer_orders
        WHERE netsuite_active = true
          AND to_location_id IS NOT NULL
          AND ($1::boolean OR dispatch_note_hash IS NULL OR dispatch_parse_source IS NULL)`,
      [force]
    );
    for (const row of receiving.rows) {
      const dispatch = row.order_type === "transfer_order"
        ? enrichTransferDispatch(row)
        : await enrichPurchaseOrderDispatch(row);
      if (row.order_type === "transfer_order") {
        await query(
          `UPDATE transfer_orders
              SET dispatch_address = $2,
                  dispatch_window_start = $3,
                  dispatch_window_end = $4,
                  dispatch_instructions = $5,
                  dispatch_parse_source = $6,
                  dispatch_note_hash = $7,
                  dispatch_parsed_at = now()
            WHERE netsuite_id = $1`,
          [
            row.netsuite_id,
            dispatch.dispatch_address,
            dispatch.dispatch_window_start,
            dispatch.dispatch_window_end,
            dispatch.dispatch_instructions,
            dispatch.dispatch_parse_source,
            dispatch.dispatch_note_hash
          ]
        );
      } else {
        await query(
          `UPDATE purchase_orders
              SET dispatch_address = $2,
                  dispatch_window_start = $3,
                  dispatch_window_end = $4,
                  dispatch_instructions = $5,
                  dispatch_vendor_yard = $6,
                  dispatch_parse_source = $7,
                  dispatch_note_hash = $8,
                  dispatch_parsed_at = now()
            WHERE netsuite_id = $1`,
          [
            row.netsuite_id,
            dispatch.dispatch_address,
            dispatch.dispatch_window_start,
            dispatch.dispatch_window_end,
            dispatch.dispatch_instructions,
            dispatch.dispatch_vendor_yard,
            dispatch.dispatch_parse_source,
            dispatch.dispatch_note_hash
          ]
        );
      }
      receivingCount += 1;
    }
  }
  return { delivery: deliveryCount, receiving: receivingCount };
}

const dispatchEnrichmentQueue = createCoalescingWorkQueue({
  merge(current, incoming) {
    return {
      force: current.force || incoming.force,
      delivery: current.delivery || incoming.delivery,
      receiving: current.receiving || incoming.receiving
    };
  },
  worker: executeDispatchEnrichment
});

export function refreshDispatchEnrichment({ force = false, delivery = true, receiving = true } = {}) {
  return dispatchEnrichmentQueue.enqueue({
    force: force === true,
    delivery: delivery !== false,
    receiving: receiving !== false
  });
}

export function dispatchEnrichmentQueueStatus() {
  return dispatchEnrichmentQueue.status();
}

export async function reparseMissingSalesOrderDispatch({ limit = 200, dryRun = false, scope = "missing" } = {}) {
  const cleanLimit = Math.min(Math.max(Number(limit) || 200, 1), 1000);
  const allNonShipped = scope === "non_shipped";
  const result = await query(
    `SELECT netsuite_id, tranid, memo, sales_order_type AS delivery_method, delivery_method_id,
            outbound_location_id, outbound_location,
            dispatch_address, dispatch_window_start, dispatch_window_end,
            dispatch_instructions, dispatch_parse_source, expected_delivery_date
       FROM sales_orders
      WHERE netsuite_active = true
        AND COALESCE(status_text, '') NOT ILIKE '%pending approval%'
        AND (
          delivery_method_id::text = '2'
          OR LOWER(COALESCE(sales_order_type, '')) = 'delivery'
          OR LOWER(COALESCE(sales_order_type, '')) LIKE '%delivery%'
        )
        AND LOWER(COALESCE(sales_order_type, '')) NOT LIKE '%pick%'
        AND COALESCE(local_yard_order_status, '') NOT IN ('loaded', 'shipped')
        AND COALESCE(status_text, '') NOT ILIKE '%pending billing%'
        AND COALESCE(status_text, '') NOT ILIKE '%closed%'
        AND COALESCE(status_text, '') NOT ILIKE '%cancel%'
        AND ($2::boolean OR (
          NULLIF(dispatch_address, '') IS NULL
          OR NULLIF(dispatch_window_start, '') IS NULL
          OR NULLIF(dispatch_window_end, '') IS NULL
          OR expected_delivery_date IS NULL
        ))
      ORDER BY expected_delivery_date NULLS LAST, tranid DESC
      LIMIT $1`,
    [cleanLimit, allNonShipped]
  );

  const details = [];
  let updated = 0;
  let resolvedTime = 0;
  let resolvedAddress = 0;
  let failed = 0;

  for (const row of result.rows) {
    try {
      const before = {
        address: row.dispatch_address || "",
        expectedDeliveryDate: dateOnly(row.expected_delivery_date),
        windowStart: row.dispatch_window_start || "",
        windowEnd: row.dispatch_window_end || "",
        parseSource: row.dispatch_parse_source || ""
      };
      const dispatch = await enrichSalesOrderDispatch(row);
      const after = {
        address: dispatch.dispatch_address || "",
        expectedDeliveryDate: dispatch.expected_delivery_date || before.expectedDeliveryDate,
        windowStart: dispatch.dispatch_window_start || "",
        windowEnd: dispatch.dispatch_window_end || "",
        parseSource: dispatch.dispatch_parse_source || ""
      };
      const hasTime = Boolean(after.windowStart && after.windowEnd);
      const hasAddress = Boolean(after.address);

      if (!dryRun) {
        await query(
          `UPDATE sales_orders
              SET dispatch_address = $2,
                  dispatch_window_start = $3,
                  dispatch_window_end = $4,
                  dispatch_instructions = $5,
                  dispatch_parse_source = $6,
                  dispatch_note_hash = $7,
                  expected_delivery_date = CASE
                    WHEN expected_delivery_date IS NOT NULL THEN expected_delivery_date
                    WHEN $8::date IS NULL THEN expected_delivery_date
                    ELSE $8::date
                  END,
                  dispatch_parsed_at = now(),
                  dispatch_instruction_details = $9::jsonb,
                  dispatch_instruction_parse_version = $10,
                  dispatch_instruction_parsed_at = $11::timestamptz
            WHERE netsuite_id = $1`,
          [
            row.netsuite_id,
            dispatch.dispatch_address,
            dispatch.dispatch_window_start,
            dispatch.dispatch_window_end,
            dispatch.dispatch_instructions,
            dispatch.dispatch_parse_source,
            dispatch.dispatch_note_hash,
            dispatch.expected_delivery_date || null,
            JSON.stringify(dispatch.dispatch_instruction_details || {}),
            dispatch.dispatch_instruction_parse_version || 0,
            dispatch.dispatch_instruction_parsed_at || null
          ]
        );
        updated += 1;
      }

      if (!before.windowStart && after.windowStart && after.windowEnd) resolvedTime += 1;
      if (!before.address && hasAddress) resolvedAddress += 1;
      details.push({
        tranid: row.tranid,
        netsuiteId: row.netsuite_id,
        before,
        after,
        resolvedTime: hasTime,
        resolvedAddress: hasAddress
      });
    } catch (error) {
      failed += 1;
      details.push({
        tranid: row.tranid,
        netsuiteId: row.netsuite_id,
        error: error.message
      });
    }
  }

  return {
    matched: result.rowCount,
    updated,
    failed,
    resolvedTime,
    resolvedAddress,
    dryRun,
    scope: allNonShipped ? "non_shipped" : "missing",
    limit: cleanLimit,
    details
  };
}

async function loadGroupActionChildren(refs, type) {
  const splits = (await query(`SELECT split_ref,full_order FROM dispatch_global_order_splits
    WHERE split_ref=ANY($1::text[]) AND active=true`, [refs])).rows;
  const splitRefs = new Set(splits.map(row => row.split_ref));
  const sourceRefs = refs.filter(ref => !splitRefs.has(ref));
  const sourceOrders = sourceRefs.length
    ? await listDispatchOrders({ type, exactOrderRefs: sourceRefs, includeHiddenScm: true }) : [];
  return [...splits.map(row => row.full_order), ...sourceOrders.filter(order => sourceRefs.includes(order.id))];
}

async function projectGroupActionRoute(order) {
  if (order.type !== "PO") return order;
  const next = { ...order, dropoffs: purchaseOrderDropoffs(order.items, {
    destinationLocationId: order.destinationLocationId,
    destinationYard: order.destinationYard,
    destinationAddress: order.defaultDestinationAddress,
    destinationAddressOverride: order.deliveryAddressOverride
  }) };
  const lineIds = (order.items || []).map(item => item.lineRowId).filter(Boolean);
  const allocations = await query(`SELECT * FROM dispatch_so_po_allocations
    WHERE status='active' AND po_line_id=ANY($1::bigint[]) ORDER BY id`, [lineIds]);
  return projectPurchaseOrderRouteResidual(next, allocations.rows, { force: true });
}

export async function setPurchaseOrderVendorYard(orderRef, vendorYardId) {
  const grouped = await applyDispatchGroupAction(orderRef, { types: ["PO"],
    updateChild: ref => setPurchaseOrderVendorYard(ref, vendorYardId), loadChildren: loadGroupActionChildren,
    projectGroup: projectGroupActionRoute });
  if (grouped) return grouped;
  await assertNoClosedNetSuiteOrders([orderRef], "change vendor yard in Dispatch");
  const yard = await query(
    `SELECT id, vendor, yard, day_label, window_start, window_end, instructions, address
       FROM dispatch_vendor_yards
      WHERE id = $1 AND active = true`,
    [vendorYardId]
  );
  const selected = yard.rows[0];
  if (!selected) throw new Error("Vendor yard not found.");
  const result = await query(
    `UPDATE purchase_orders
        SET dispatch_address = $2,
            dispatch_window_start = $3,
            dispatch_window_end = $4,
            dispatch_instructions = $5,
            dispatch_vendor_yard = $6,
            dispatch_parse_source = 'manual-po-yard',
            dispatch_parsed_at = now()
      WHERE tranid = $1 OR netsuite_id::text = $1 OR dispatch_ref = $1
      RETURNING netsuite_id, tranid`,
    [
      orderRef,
      selected.address || "",
      selected.window_start || "",
      selected.window_end || "",
      `${selected.day_label || ""}${selected.instructions ? ` | ${selected.instructions}` : ""}`.trim(),
      selected.yard
    ]
  );
  if (!result.rows[0]) throw new Error("Purchase order not found.");
  return result.rows[0];
}

export async function updateDispatchOrderDetails(orderRef, patch = {}) {
  const grouped = await applyDispatchGroupAction(orderRef, { types: ["SO", "PO", "TO"],
    updateChild: (ref, type) => updateDispatchOrderDetails(ref, { ...patch, type, sourceTable: "", source_table: "" }),
    loadChildren: loadGroupActionChildren, projectGroup: projectGroupActionRoute });
  if (grouped) return grouped;
  await assertNoClosedNetSuiteOrders([orderRef], "change Dispatch details");
  const split = await updateDispatchSalesSplitDetails(orderRef, patch);
  if (split) return split;
  const address = String(patch.address || "").trim();
  const pickupAddressProvided = patch.pickupAddress !== undefined
    || patch.pickup_address !== undefined;
  const pickupAddress = String(patch.pickupAddress ?? patch.pickup_address ?? "").trim();
  const windowStart = String(patch.windowStart || patch.window_start || "").trim();
  const windowEnd = String(patch.windowEnd || patch.window_end || "").trim();
  const expectedDate = String(patch.expectedDeliveryDate || patch.expected_delivery_date || "").trim() || null;
  const type = String(patch.type || "").toUpperCase();
  const sourceTable = String(patch.sourceTable || patch.source_table || "");
  const preferReceiving = sourceTable === "purchase_orders" || type === "PO";
  const preferDelivery = sourceTable === "sales_orders" || type === "SO";
  const preferTransfer = sourceTable === "transfer_orders" || type === "TO";
  const attempts = preferReceiving
    ? [{ table: "purchase_orders", orderType: "purchase_order" }, { table: "transfer_orders", orderType: "transfer_order" }]
    : preferTransfer
      ? [{ table: "transfer_orders", orderType: "transfer_order" }]
      : preferDelivery
        ? [{ table: "sales_orders", orderType: "sales_order" }, { table: "transfer_orders", orderType: "transfer_order" }]
        : [
            { table: "sales_orders", orderType: "sales_order" },
            { table: "purchase_orders", orderType: "purchase_order" },
            { table: "transfer_orders", orderType: "transfer_order" }
          ];

  for (const { table, orderType } of attempts) {
    const deliveryAddressColumn = table === "purchase_orders"
      ? "dispatch_delivery_address"
      : "dispatch_address";
    const returnedDeliveryAddress = table === "purchase_orders"
      ? "dispatch_delivery_address"
      : "NULL::text";
    const result = await query(
      `UPDATE ${table}
          SET ${deliveryAddressColumn} = $2,
              dispatch_window_start = $3,
              dispatch_window_end = $4,
              expected_delivery_date = $5::date,
              dispatch_pickup_address = CASE WHEN $6::boolean THEN $7 ELSE dispatch_pickup_address END,
              dispatch_parse_source = 'manual-dispatch-details',
              dispatch_parsed_at = now()
        WHERE (tranid = $1 OR netsuite_id::text = $1${table === "purchase_orders" ? " OR dispatch_ref = $1" : ""})
        RETURNING netsuite_id, tranid, ${deliveryAddressColumn} AS dispatch_address,
                  ${returnedDeliveryAddress} AS dispatch_delivery_address, dispatch_window_start,
                  dispatch_window_end, expected_delivery_date, dispatch_pickup_address,
                  '${table}'::text AS source_table`,
      [orderRef, address, windowStart, windowEnd, expectedDate, pickupAddressProvided, pickupAddress]
    );
    if (result.rows[0]) return { ...result.rows[0], order_type: orderType };
  }

  throw new Error("Dispatch order not found.");
}

function positiveQuantity(value) {
  return Math.max(Number(value || 0) || 0, 0);
}

function purchaseOrderNetSuiteLineSequence(row = {}) {
  const raw = row?.raw && typeof row.raw === "object" && !Array.isArray(row.raw)
    ? row.raw
    : {};
  const value = Number(
    row.netSuiteLineSequence
    ?? row.netsuiteLineSequence
    ?? row.lineSequenceNumber
    ?? row.line_sequence_number
    ?? raw.lineSequenceNumber
    ?? raw.line_sequence_number
    ?? raw.netSuiteLineSequence
  );
  return Number.isFinite(value) && value > 0 ? value : null;
}

function purchaseOrderNetSuiteOrderLine(row = {}) {
  const raw = row?.raw && typeof row.raw === "object" && !Array.isArray(row.raw)
    ? row.raw
    : {};
  const value = raw.orderLine ?? raw.order_line ?? raw.order_line_number;
  const normalized = String(value ?? "").trim();
  return normalized || null;
}

function comparePurchaseOrderNetSuiteLines(left = {}, right = {}) {
  const leftSequence = purchaseOrderNetSuiteLineSequence(left);
  const rightSequence = purchaseOrderNetSuiteLineSequence(right);
  if (leftSequence !== null || rightSequence !== null) {
    if (leftSequence === null) return 1;
    if (rightSequence === null) return -1;
    if (leftSequence !== rightSequence) return leftSequence - rightSequence;
  }
  return String(left.line_id ?? left.sourceLineId ?? left.id ?? "").localeCompare(
    String(right.line_id ?? right.sourceLineId ?? right.id ?? ""),
    undefined,
    { numeric: true, sensitivity: "base" }
  );
}

function hasConversion(row) {
  return positiveQuantity(row.to_plt) > 0
    || positiveQuantity(row.to_lyr) > 0
    || positiveQuantity(row.to_sec) > 0
    || positiveQuantity(row.to_pcs) > 0;
}

function hasCustomQuantity(row) {
  return positiveQuantity(row.pallet_qty) > 0
    || positiveQuantity(row.layer_qty) > 0
    || positiveQuantity(row.section_qty) > 0
    || positiveQuantity(row.piece_qty) > 0;
}

function purchaseOrderReceivedBaseline(row) {
  return positiveQuantity(row?.netsuite_received_baseline_qty ?? row?.netsuite_received_qty);
}

function lineSalesQty(row, qtys = {}) {
  const pallets = positiveQuantity(qtys.pallets);
  const layers = positiveQuantity(qtys.layers);
  const sections = positiveQuantity(qtys.sections);
  const pieces = positiveQuantity(qtys.pieces);
  const directSales = positiveQuantity(qtys.salesQty);
  const converted = (pallets * positiveQuantity(row.to_plt))
    + (layers * positiveQuantity(row.to_lyr))
    + (sections * positiveQuantity(row.to_sec))
    + (pieces * positiveQuantity(row.to_pcs));
  if (converted > 0) return converted;
  if (!hasConversion(row) && hasCustomQuantity(row)) return directSales;
  if (!hasConversion(row)) return directSales || pieces || sections || layers || pallets;
  return directSales;
}

function availableUnitQty(row, unit) {
  const required = positiveQuantity(row[`${unit}_qty`]);
  const allocated = positiveQuantity(row[`allocated_${unit}_qty`]);
  const byUnit = Math.max(required - allocated, 0);
  const conversion = unit === "pallet" ? positiveQuantity(row.to_plt)
    : unit === "layer" ? positiveQuantity(row.to_lyr)
      : unit === "section" ? positiveQuantity(row.to_sec)
        : unit === "piece" ? positiveQuantity(row.to_pcs)
          : 0;
  const remainingSales = Math.max(
    positiveQuantity(row.quantity) - purchaseOrderReceivedBaseline(row) - positiveQuantity(row.allocated_sales_qty),
    0
  );
  if (!conversion) return byUnit || (!hasCustomQuantity(row) && unit === "piece" ? remainingSales : byUnit);
  if (!hasCustomQuantity(row)) return Math.floor((remainingSales / conversion) + 0.000001);
  return Math.min(byUnit, Math.floor((remainingSales / conversion) + 0.000001));
}

function availableUnitSelection(row) {
  const remainingSales = Math.max(
    positiveQuantity(row.quantity) - purchaseOrderReceivedBaseline(row) - positiveQuantity(row.allocated_sales_qty),
    0
  );
  if (hasCustomQuantity(row)) {
    return {
      pallets: availableUnitQty(row, "pallet"),
      layers: availableUnitQty(row, "layer"),
      sections: availableUnitQty(row, "section"),
      pieces: availableUnitQty(row, "piece"),
      salesQty: remainingSales
    };
  }
  if (!hasConversion(row)) return { pallets: 0, layers: 0, sections: 0, pieces: 0, salesQty: remainingSales };
  let remainder = remainingSales;
  const result = { pallets: 0, layers: 0, sections: 0, pieces: 0, salesQty: 0 };
  for (const [field, conversionField] of [["pallets", "to_plt"], ["layers", "to_lyr"], ["sections", "to_sec"], ["pieces", "to_pcs"]]) {
    const conversion = positiveQuantity(row[conversionField]);
    if (!conversion || remainder <= 0.000001) continue;
    result[field] = Math.floor((remainder / conversion) + 0.000001);
    remainder = Math.max(0, Number((remainder - (result[field] * conversion)).toFixed(6)));
  }
  // Keep the sales-unit ceiling alongside the operator-facing converted units.
  // Split mutations validate both representations, so a converted-only source
  // line must not expose an artificial zero sales-unit maximum.
  result.salesQty = remainingSales;
  return result;
}

function syntheticPurchaseOrderId(value) {
  const hex = crypto.createHash("sha1").update(String(value || "")).digest("hex").slice(0, 12);
  return -Number.parseInt(hex, 16);
}

function syntheticPurchaseOrderIdForGroup(groupRef = "") {
  return syntheticPurchaseOrderId(`scm-schedule-group:${groupRef}`);
}

function repositoryHashText(value = "") {
  return crypto.createHash("sha1").update(String(value || "")).digest("hex");
}

function roundDispatchQuantity(value) {
  return Number(Number(value || 0).toFixed(6));
}

function splitLineQuantityPayload(line = {}) {
  return {
    pallets: positiveQuantity(line.pallets ?? line.pallet_qty),
    layers: positiveQuantity(line.layers ?? line.layer_qty),
    sections: positiveQuantity(line.sections ?? line.section_qty),
    pieces: positiveQuantity(line.pieces ?? line.piece_qty),
    salesQty: positiveQuantity(line.salesQty ?? line.quantity)
  };
}

function hasRequestedSplitQuantity(qtys = {}) {
  return positiveQuantity(qtys.pallets)
    + positiveQuantity(qtys.layers)
    + positiveQuantity(qtys.sections)
    + positiveQuantity(qtys.pieces)
    + positiveQuantity(qtys.salesQty) > 0;
}

function visibleScmSplitItem(item = {}) {
  return positiveQuantity(item.pallets)
    + positiveQuantity(item.layers)
    + positiveQuantity(item.sections)
    + positiveQuantity(item.pieces)
    + positiveQuantity(item.quantity) > 0;
}

function scmPurchaseOrderRefValues(order = {}) {
  return [...new Set([
    order.id,
    order.originalPoRef,
    order.dispatchRef,
    order.sourcePoRef
  ].map((value) => String(value || "").trim()).filter(Boolean))];
}

function scmPurchaseOrderSearchRefs(orders = [], splitRows = []) {
  const refsByLookup = new Map();
  const connectRefs = (values = []) => {
    const refs = [...new Set(values.map((value) => String(value || "").trim()).filter(Boolean))];
    for (const ref of refs) {
      const key = ref.toLowerCase();
      const connected = refsByLookup.get(key) || new Set();
      refs.forEach((value) => connected.add(value));
      refsByLookup.set(key, connected);
    }
  };
  for (const order of orders) connectRefs(scmPurchaseOrderRefValues(order));
  for (const split of splitRows) connectRefs([split.split_po_ref, split.source_po_ref]);

  return new Map((orders || []).map((order) => {
    const refs = new Set(scmPurchaseOrderRefValues(order));
    for (const childRef of order.childOrders || []) {
      const child = String(childRef || "").trim();
      if (!child) continue;
      refs.add(child);
      for (const connected of refsByLookup.get(child.toLowerCase()) || []) refs.add(connected);
    }
    return [String(order.id || ""), [...refs]];
  }));
}

export function applyScmPurchaseOrderCompletionStatus(order = {}, completionByRef = new Map()) {
  const ownRef = String(order.id || "").trim().toLowerCase();
  const completion = ownRef ? completionByRef.get(ownRef) : null;
  if (!completion || String(completion.dispatch_completion_status || "").toLowerCase() !== "completed") {
    return order;
  }
  return {
    ...order,
    dispatchCompleted: true,
    dispatchCompletedAt: completion.dispatch_completed_at || null,
    dispatchCompletionEvidenceType: completion.completion_evidence_type || "",
    dispatchCompletionEvidenceId: completion.completion_evidence_id || "",
    scm: {
      ...(order.scm || {}),
      status: "Completed"
    }
  };
}

async function scmPurchaseOrderCompletionMap(orders = []) {
  const refs = [...new Set(orders
    .map((order) => String(order?.id || "").trim().toLowerCase())
    .filter(Boolean))];
  if (!refs.length) return new Map();
  const result = await query(
    `SELECT DISTINCT ON (lower(btrim(completion.order_ref)))
            lower(btrim(completion.order_ref)) AS normalized_ref,
            completion.dispatch_completion_status,
            completion.dispatch_completed_at,
            completion.completion_evidence_type,
            completion.completion_evidence_id
       FROM dispatch_order_completion_status completion
      WHERE completion.order_kind = 'PO'
        AND completion.dispatch_completion_status = 'completed'
        AND lower(btrim(completion.order_ref)) = ANY($1::text[])
      ORDER BY lower(btrim(completion.order_ref)), completion.dispatch_completed_at DESC`,
    [refs]
  );
  return new Map(result.rows.map((row) => [row.normalized_ref, row]));
}

function compareScmPurchaseOrders(left = {}, right = {}) {
  return String(left.id || "").localeCompare(String(right.id || ""), undefined, {
    numeric: true,
    sensitivity: "base"
  });
}

function replaceRefDeep(value, oldRef, newRef) {
  if (typeof value === "string") return value === oldRef ? newRef : value;
  if (Array.isArray(value)) return value.map((item) => replaceRefDeep(item, oldRef, newRef));
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, replaceRefDeep(item, oldRef, newRef)]));
  }
  return value;
}

function removeRefFromPlanArrays({ orders = [], trucks = [] } = {}, orderRef = "") {
  const ref = String(orderRef || "");
  const nextOrders = (orders || []).filter((order) => String(order?.id || "") !== ref);
  const nextTrucks = (trucks || []).map((truck) => ({
    ...truck,
    loads: (truck.loads || []).map((load) => ({
      ...load,
      stops: (load.stops || []).filter((stop) => String(stop?.orderId || "") !== ref)
    }))
  }));
  return { orders: nextOrders, trucks: nextTrucks };
}

export function rewriteDispatchSnapshotReference(plan, { oldRef, newRef, remove = false }) {
  const arrays = remove ? removeRefFromPlanArrays(plan, oldRef) : {
    orders: replaceRefDeep(plan.orders || [], oldRef, newRef),
    trucks: replaceRefDeep(plan.trucks || [], oldRef, newRef)
  };
  return { ...plan, ...arrays };
}

async function updateDispatchSnapshotsForRef(executor, { oldRef = "", newRef = "", remove = false } = {}) {
  const ref = String(oldRef || "").trim();
  if (!ref) return { planIds: [] };
  const runQuery = typeof executor === "function" ? executor : executor.query.bind(executor);
  await runQuery("SELECT pg_advisory_xact_lock(hashtext($1))", [DISPATCH_FLEET_PLANNING_LOCK]);
  const snapshots = await runQuery(
    `SELECT snapshot.plan_id, plan.plan_date::text AS plan_date,
            plan.status, plan.note, plan.revision,
            snapshot.orders, snapshot.trucks, snapshot.summary, maintenance.requests AS pending_requests
       FROM dispatch_plan_snapshots snapshot
       JOIN dispatch_plans plan ON plan.id = snapshot.plan_id
       LEFT JOIN dispatch_plan_maintenance maintenance ON maintenance.plan_id=plan.id
      WHERE snapshot.orders::text LIKE $1 OR snapshot.trucks::text LIKE $1
         OR EXISTS (SELECT 1 FROM jsonb_each(COALESCE(maintenance.requests,'{}'::jsonb)) request
           WHERE request.value->>'kind'='po_reference' AND request.value->>'newRef'=$2)
      ORDER BY plan.plan_date, snapshot.plan_id`,
    [`%"${ref.replaceAll('"', '\\"')}"%`, ref]
  );
  const changedPlans = [];
  for (const row of snapshots.rows) {
    // A prior rename may still be queued, so this snapshot can contain the
    // original identity rather than the source's latest reference.
    if (Object.values(row.pending_requests || {}).some(request => request.kind === "po_reference" && request.newRef === ref)) {
      await enqueueDispatchPlanMaintenance(row.plan_id, { kind: "po_reference", oldRef: ref, newRef: String(newRef || "").trim(), remove }, runQuery);
      continue;
    }
    const next = rewriteDispatchSnapshotReference({ orders: row.orders || [], trucks: row.trucks || [] }, {
      oldRef: ref, newRef: String(newRef || "").trim(), remove
    });
    const previousPlan = {
      id: String(row.plan_id),
      planDate: String(row.plan_date || "").slice(0, 10),
      status: row.status || "draft",
      note: row.note || "",
      revision: Number(row.revision || 0),
      orders: row.orders || [],
      trucks: row.trucks || [],
      summary: row.summary || {}
    };
    const nextPlan = {
      ...previousPlan,
      revision: previousPlan.revision + 1,
      orders: next.orders,
      trucks: next.trucks
    };
    if (JSON.stringify([previousPlan.orders, previousPlan.trucks]) === JSON.stringify([next.orders, next.trucks])) {continue;}
    if (await deferDispatchPlanMaintenance(previousPlan, {
      kind: "po_reference", oldRef: ref, newRef: String(newRef || "").trim(), remove
    }, runQuery)) {continue;}
    await runQuery(`SELECT plan.id FROM dispatch_plans plan
      JOIN dispatch_plan_snapshots snapshot ON snapshot.plan_id=plan.id
      WHERE plan.id=$1 FOR UPDATE OF plan, snapshot`, [row.plan_id]);
    await assertDispatchExecutedPrefixPreserved({
      previousPlan,
      nextPlan,
      execute: runQuery
    });
    await runQuery(
      `UPDATE dispatch_plan_snapshots
          SET orders = $2::jsonb,
              trucks = $3::jsonb,
              plan_digest = $4,
              saved_at = now()
        WHERE plan_id = $1`,
      [row.plan_id, JSON.stringify(next.orders), JSON.stringify(next.trucks), digestDispatchPlan(nextPlan)]
    );
    changedPlans.push(nextPlan);
  }
  if (changedPlans.length) {
    const revisions = await runQuery(
      `UPDATE dispatch_plans
          SET revision = COALESCE(revision, 0) + 1,
              updated_at = now()
        WHERE id = ANY($1::bigint[])`,
      [changedPlans.map((plan) => plan.id)]
    );
    if (revisions.rowCount !== changedPlans.length) {
      throw new Error("A Dispatch plan disappeared during the PO reference rewrite.");
    }
    for (const plan of changedPlans) {
      await syncDispatchPlanOrderAssignments(plan, { execute: runQuery });
      await syncDispatchPlanRelationEdges(plan, { execute: runQuery });
    }
  }
  if (executor === query) {for (const plan of changedPlans) {notifyDispatchPlanMaintenance(plan, [ref, newRef].filter(Boolean));}}
  return { planIds: changedPlans.map((plan) => plan.id), plans: changedPlans };
}

export function scmPurchaseOrderListKind(order = {}) {
  const sourceTable = String(order.sourceTable || "").trim().toLowerCase();
  const parseSource = String(order.parseSource || "").trim().toLowerCase();
  if (sourceTable === "scm_vrma_orders" || parseSource === "scm-vrma") return "vrma";
  return order.isScmSplit === true ? "split" : "po";
}

export function scmPurchaseOrderMatchesListFilters(order = {}, {
  search = "",
  poType = "",
  dropoff = "",
  vendor = "",
  pickupPoint = ""
} = {}) {
  const kind = scmPurchaseOrderListKind(order);
  if (kind === "vrma") return false;
  if (String(search || "").trim()) return true;
  const typeFilter = ["po", "split"].includes(String(poType || "").trim().toLowerCase())
    ? String(poType || "").trim().toLowerCase()
    : "";
  if (typeFilter && kind !== typeFilter) return false;
  const dropoffFilter = String(dropoff || "").trim().toLowerCase();
  if (dropoffFilter && ![
    order.destinationYard,
    ...(order.dropoffs || []).map((drop) => drop.destinationYard)
  ].some((yard) => String(yard || "").trim().toLowerCase() === dropoffFilter)) return false;
  const vendorFilter = String(vendor || "").trim().toLowerCase();
  if (vendorFilter && scmOrderVendorLabel(order).toLowerCase() !== vendorFilter) return false;
  const pickupFilter = String(pickupPoint || "").trim().toLowerCase();
  if (pickupFilter && scmEffectivePickupPoint(order).toLowerCase() !== pickupFilter) return false;
  return true;
}

export async function listScmPurchaseOrders({
  search = "", poType = "", dropoff = "", vendor = "", pickupPoint = "",
  includeAllDiscoverable = false, unbounded = false
} = {}) {
  const needle = String(search || "").trim().toLowerCase();
  const listedOrders = await listDispatchOrders({
    type: "PO",
    includeHiddenScm: true,
    includeAllDiscoverableScmPurchaseOrders: includeAllDiscoverable,
    unboundedPerType: unbounded,
    includeScmLinkedSearchRefs: Boolean(needle),
    search: needle
  });
  const splitRows = await query(
    `SELECT s.id, s.source_po_id, s.source_po_ref, s.split_po_id, s.split_po_ref,
            s.created_at, s.created_by, s.revision, s.updated_at,
            COUNT(l.id) AS line_count,
            COALESCE(SUM(l.sales_qty), 0) AS sales_qty,
            (
              EXISTS (
                SELECT 1 FROM dispatch_plan_order_assignments assignment
                JOIN dispatch_plans plan ON plan.id = assignment.plan_id
                WHERE plan.status <> 'cancelled'
                  AND (lower(assignment.order_ref) = lower(s.split_po_ref)
                    OR lower(NULLIF(assignment.planned_order_ref, '')) = lower(s.split_po_ref))
              )
              OR EXISTS (
                SELECT 1 FROM scm_transport_schedule schedule
                JOIN dispatch_plans schedule_plan
                  ON schedule_plan.id = schedule.dispatch_plan_id
                 AND schedule_plan.status <> 'cancelled'
                WHERE schedule.order_kind = 'PO'
                  AND lower(schedule.order_ref) = lower(s.split_po_ref)
              )
              OR EXISTS (
                SELECT 1 FROM purchase_order_lines child_line
                WHERE child_line.purchase_order_id = s.split_po_id
                  AND (COALESCE(child_line.received_pallet_qty, 0) > 0
                    OR COALESCE(child_line.received_layer_qty, 0) > 0
                    OR COALESCE(child_line.received_section_qty, 0) > 0
                    OR COALESCE(child_line.received_piece_qty, 0) > 0
                    OR COALESCE(child_line.netsuite_received_qty, 0) > 0
                    OR child_line.confirmed_at IS NOT NULL)
              )
              OR EXISTS (
                SELECT 1 FROM driver_job_records job
                WHERE job.status IN ('in_progress', 'complete') AND job.order_refs ? s.split_po_ref
              )
              OR EXISTS (
                SELECT 1 FROM dispatch_so_po_allocations allocation
                WHERE allocation.po_order_id = s.split_po_id AND allocation.status = 'active'
              )
              OR EXISTS (
                SELECT 1 FROM scm_schedule_group_members member
                JOIN scm_schedule_groups group_header ON group_header.id = member.group_id
                WHERE group_header.status = 'active' AND lower(member.order_ref) = lower(s.split_po_ref)
              )
            ) AS operationally_locked
       FROM dispatch_scm_po_splits s
       LEFT JOIN dispatch_scm_po_split_lines l ON l.split_id = s.id
      WHERE s.status = 'active'
      GROUP BY s.id
      ORDER BY s.created_at DESC`
  );
  let orders = listedOrders.filter((order) => scmPurchaseOrderListKind(order) !== "vrma");
  const splitByRef = new Map(splitRows.rows.map((row) => [String(row.split_po_ref || ""), row]));
  orders = orders.map((order) => {
    const split = splitByRef.get(String(order.id || ""));
    if (!split) return order;
    return {
      ...order,
      isScmSplit: true,
      scmSplitId: split.id,
      sourcePoRef: split.source_po_ref || "",
      scmSplitCreatedAt: split.created_at,
      scmSplitCreatedBy: split.created_by || "",
      scmSplitRevision: Number(split.revision || 1),
      scmSplitUpdatedAt: split.updated_at || null,
      scmSplitLocked: split.operationally_locked === true,
      scmSplitLineCount: Number(split.line_count || 0),
      scmSplitSalesQty: positiveQuantity(split.sales_qty)
    };
  });
  const completionByRef = await scmPurchaseOrderCompletionMap(orders);
  orders = orders.map((order) => applyScmPurchaseOrderCompletionStatus(order, completionByRef));
  const searchRefsByOrderId = scmPurchaseOrderSearchRefs(orders, splitRows.rows);
  orders = orders.map((order) => ({
    ...order,
    scmSearchRefs: searchRefsByOrderId.get(String(order.id || "")) || scmPurchaseOrderRefValues(order)
  }));
  if (needle) {
    orders = orders.filter((order) => {
      const haystack = [
        order.id,
        order.originalPoRef,
        order.dispatchRef,
        order.customer,
        order.vendorYard,
        order.sourceYard,
        order.address,
        order.sourcePoRef,
        ...(order.scmSearchRefs || []),
        ...(order.childOrders || []),
        ...(order.items || []).flatMap((item) => [item.sku, item.itemName, item.description])
      ].join(" ").toLowerCase();
      return haystack.includes(needle);
    });
  }
  const vendorYardOptionsByRef = await listScmVendorYardOptionsForRefs(orders.flatMap((order) => [
    order.id,
    order.originalPoRef,
    order.dispatchRef,
    order.netsuiteId
  ]));
  return orders
    .map((order) => ({
      ...order,
      vendorYardOptions: vendorYardOptionsByRef.get(String(order.id || "").toLowerCase())
        || vendorYardOptionsByRef.get(String(order.originalPoRef || "").toLowerCase())
        || vendorYardOptionsByRef.get(String(order.dispatchRef || "").toLowerCase())
        || vendorYardOptionsByRef.get(String(order.netsuiteId || "").toLowerCase())
        || [],
      items: (order.items || []).filter(visibleScmSplitItem)
    }))
    .filter((order) => {
      const groupRef = String(order.scm?.groupRef || "").trim();
      if (!groupRef) return true;
      return String(order.id || "").trim().toLowerCase() === groupRef.toLowerCase();
    })
    .filter((order) => scmPurchaseOrderMatchesListFilters(order, {
      search: needle,
      poType,
      dropoff,
      vendor,
      pickupPoint
    }))
    .filter((order) => includeAllDiscoverable || (order.items || []).length || needle)
    .sort(compareScmPurchaseOrders);
}

export async function setPurchaseOrderBlanketFlag(orderRef, {
  isBlanket = false,
  updatedBy = ""
} = {}) {
  const ref = String(orderRef || "").trim();
  if (!ref) throw Object.assign(new Error("Purchase order reference is required."), { status: 400 });
  const flagged = isBlanket === true;
  return withTransaction(async () => {
    await assertNoClosedNetSuiteOrders([ref], "change Blanket status in SCM");
    const sourceResult = await query(
      `SELECT *
         FROM purchase_orders
        WHERE lower(COALESCE(tranid, '')) = lower($1)
           OR lower(COALESCE(dispatch_ref, '')) = lower($1)
           OR netsuite_id::text = $1
        ORDER BY CASE
          WHEN lower(COALESCE(tranid, '')) = lower($1) THEN 0
          WHEN lower(COALESCE(dispatch_ref, '')) = lower($1) THEN 1
          ELSE 2
        END
        LIMIT 1
        FOR UPDATE`,
      [ref]
    );
    const source = sourceResult.rows[0];
    if (!source) throw Object.assign(new Error(`Purchase order ${ref} was not found.`), { status: 404 });
    const conflicts = await query(
      `SELECT
         EXISTS (
           SELECT 1 FROM dispatch_scm_po_splits split
            WHERE split.split_po_id = $1
         ) AS is_split_child,
         EXISTS (
           SELECT 1 FROM dispatch_scm_po_splits split
            WHERE split.source_po_id = $1 AND split.status = 'active'
         ) AS has_active_splits,
         EXISTS (
           SELECT 1 FROM scm_smart_blanket_releases release
            WHERE release.source_po_id = $1
              AND release.status IN ('reserved', 'partially_released', 'held')
         ) AS has_pending_releases`,
      [source.netsuite_id]
    );
    const conflict = conflicts.rows[0] || {};
    if (flagged && conflict.is_split_child) {
      throw Object.assign(
        new Error("Only a source purchase order can be flagged as Blanket; a local split child cannot become a Blanket parent."),
        { status: 409, code: "SCM_BLANKET_SOURCE_REQUIRED" }
      );
    }
    const openForReceipt = source.netsuite_active === true
      && (/Pending Receipt/i.test(String(source.status_text || ""))
        || /Partially Received/i.test(String(source.status_text || "")));
    if (flagged && !openForReceipt) {
      throw Object.assign(
        new Error("Only an active Pending Receipt or Partially Received source PO can be flagged as Blanket."),
        { status: 409, code: "SCM_BLANKET_SOURCE_NOT_OPEN" }
      );
    }
    if (!flagged && (conflict.has_active_splits || conflict.has_pending_releases)) {
      throw Object.assign(
        new Error("This Blanket PO has an active split or reserved release and cannot be unflagged."),
        {
          status: 409,
          code: "SCM_BLANKET_UNFLAG_UNSAFE",
          conflicts: {
            activeSplits: conflict.has_active_splits === true,
            pendingReleases: conflict.has_pending_releases === true
          }
        }
      );
    }
    const result = await query(
      `UPDATE purchase_orders
          SET is_blanket_po = $2,
              blanket_flagged_at = CASE WHEN $2 THEN now() ELSE NULL END,
              blanket_flagged_by = CASE WHEN $2 THEN NULLIF($3, '') ELSE NULL END
        WHERE netsuite_id = $1
        RETURNING netsuite_id, tranid, dispatch_ref, is_blanket_po,
                  blanket_flagged_at, blanket_flagged_by`,
      [source.netsuite_id, flagged, String(updatedBy || "").trim()]
    );
    const row = result.rows[0];
    if (flagged) {
      await resumeSmartScmBlanketCoveredPlanningExclusions({ sourcePoId: row.netsuite_id });
    }
    return {
      netsuiteId: row.netsuite_id,
      orderRef: row.tranid || ref,
      dispatchRef: row.dispatch_ref || "",
      isBlanket: row.is_blanket_po === true,
      flaggedAt: row.blanket_flagged_at,
      flaggedBy: row.blanket_flagged_by || ""
    };
  });
}

function scmOrderVendorLabel(order = {}) {
  const localVendor = (Array.isArray(order.vendorYardOptions) ? order.vendorYardOptions : [])
    .map((option) => String(option.vendor || "").trim())
    .find(Boolean);
  return String(localVendor || order.customer || order.vendorYard || order.sourceYard || "").trim();
}

function scmEffectivePickupPoint(order = {}) {
  const options = Array.isArray(order.vendorYardOptions) ? order.vendorYardOptions : [];
  const current = String(order.scm?.pickupPoint || order.sourceYard || order.vendorYard || "").trim();
  if (!options.length) return current;
  const matched = options.find((option) => String(option.yard || "").trim().toLowerCase() === current.toLowerCase());
  return String(matched?.yard || options[0]?.yard || current).trim();
}

async function listScmVendorYardOptionsForRefs(refs = [], executor = query) {
  const cleanRefs = [...new Set((Array.isArray(refs) ? refs : [])
    .map((ref) => String(ref || "").trim())
    .filter(Boolean))];
  if (!cleanRefs.length) return new Map();
  const runQuery = typeof executor === "function" ? executor : executor.query.bind(executor);
  const result = await runQuery(
    `WITH requested AS MATERIALIZED (
       SELECT ref,
              upper(btrim(ref)) AS ref_key,
              CASE
                WHEN ref ~ '^[0-9]{1,19}$'
                 AND ref::numeric <= 9223372036854775807::numeric
                THEN ref::bigint
                ELSE NULL
              END AS numeric_id
         FROM unnest($1::text[]) input(ref)
     ),
     matched_po AS (
       SELECT r.ref AS requested_ref,
              po.netsuite_id,
              po.tranid,
              po.dispatch_ref,
              po.vendor_id::text AS vendor_id,
              po.vendor
         FROM requested r
         JOIN purchase_orders po
           ON upper(btrim(po.tranid)) = r.ref_key
        WHERE po.netsuite_active = true
       UNION
       SELECT r.ref, po.netsuite_id, po.tranid, po.dispatch_ref,
              po.vendor_id::text, po.vendor
         FROM requested r
         JOIN purchase_orders po
           ON upper(btrim(po.dispatch_ref)) = r.ref_key
        WHERE po.netsuite_active = true
       UNION
       SELECT r.ref, po.netsuite_id, po.tranid, po.dispatch_ref,
              po.vendor_id::text, po.vendor
         FROM requested r
         JOIN purchase_orders po ON po.netsuite_id = r.numeric_id
        WHERE r.numeric_id IS NOT NULL
          AND po.netsuite_active = true
     ),
     vendor_id_mapping AS MATERIALIZED (
       SELECT DISTINCT ON (netsuite_vendor_id)
              netsuite_vendor_id, local_vendor
         FROM dispatch_vendor_mappings
        WHERE active = true
          AND COALESCE(netsuite_vendor_id, '') <> ''
          AND COALESCE(local_vendor, '') <> ''
        ORDER BY netsuite_vendor_id, last_seen_at DESC, id DESC
     ),
     vendor_name_mapping AS MATERIALIZED (
       SELECT DISTINCT ON (lower(netsuite_vendor_name))
              lower(netsuite_vendor_name) AS vendor_name_key, local_vendor
         FROM dispatch_vendor_mappings
        WHERE active = true
          AND COALESCE(netsuite_vendor_name, '') <> ''
          AND COALESCE(local_vendor, '') <> ''
        ORDER BY lower(netsuite_vendor_name), last_seen_at DESC, id DESC
     ),
     mapped_po AS (
       SELECT p.*,
              COALESCE(
                NULLIF(id_mapping.local_vendor, ''),
                NULLIF(name_mapping.local_vendor, ''),
                ''
              ) AS local_vendor
         FROM matched_po p
         LEFT JOIN vendor_id_mapping id_mapping
           ON id_mapping.netsuite_vendor_id = p.vendor_id
         LEFT JOIN vendor_name_mapping name_mapping
           ON name_mapping.vendor_name_key = lower(p.vendor)
     )
     SELECT DISTINCT ON (requested_ref, lower(y.yard))
            requested_ref,
            tranid,
            COALESCE(NULLIF(dispatch_ref, ''), tranid) AS display_ref,
            netsuite_id,
            local_vendor,
            y.id,
            y.vendor,
            y.yard,
            y.day_label,
            y.window_start,
            y.window_end,
            y.instructions,
            y.address
       FROM mapped_po p
       JOIN dispatch_vendor_yards y
         ON y.active = true
        AND lower(y.vendor) = lower(p.local_vendor)
      WHERE p.local_vendor <> ''
        AND p.local_vendor <> $2
      ORDER BY requested_ref, lower(y.yard),
        CASE y.day_label
          WHEN 'Mon-Fri' THEN 0
          WHEN 'Monday' THEN 1
          ELSE 2
        END,
        y.id`,
    [cleanRefs, useNetSuiteAddressMappingValue()]
  );
  const map = new Map();
  const add = (key, option) => {
    const cleanKey = String(key || "").trim().toLowerCase();
    if (!cleanKey) return;
    const list = map.get(cleanKey) || [];
    if (!list.some((existing) => String(existing.yard || "").toLowerCase() === String(option.yard || "").toLowerCase())) {
      list.push(option);
    }
    map.set(cleanKey, list);
  };
  for (const row of result.rows) {
    const option = {
      id: row.id,
      vendor: row.vendor || row.local_vendor || "",
      yard: row.yard || "",
      dayLabel: row.day_label || "",
      windowStart: row.window_start || "",
      windowEnd: row.window_end || "",
      instructions: row.instructions || "",
      address: row.address || ""
    };
    add(row.requested_ref, option);
    add(row.tranid, option);
    add(row.display_ref, option);
    add(row.netsuite_id, option);
  }
  return map;
}

async function listScmScheduleGroupMembersByRef(groupRefs = [], executor = query) {
  const refs = [...new Set((Array.isArray(groupRefs) ? groupRefs : [])
    .map((ref) => String(ref || "").trim().toLowerCase())
    .filter(Boolean))];
  if (!refs.length) return new Map();
  const runQuery = typeof executor === "function" ? executor : executor.query.bind(executor);
  const result = await runQuery(
    `SELECT lower(group_header.group_ref) AS group_ref, member.order_ref
       FROM scm_schedule_groups group_header
       JOIN scm_schedule_group_members member ON member.group_id = group_header.id
      WHERE group_header.status = 'active'
        AND lower(group_header.group_ref) = ANY($1::text[])
      ORDER BY lower(group_header.group_ref), lower(member.order_ref)`,
    [refs]
  );
  const membersByRef = new Map();
  for (const row of result.rows) {
    const members = membersByRef.get(row.group_ref) || [];
    if (!members.some((ref) => ref.toLowerCase() === String(row.order_ref || "").toLowerCase())) {
      members.push(String(row.order_ref || "").trim());
    }
    membersByRef.set(row.group_ref, members);
  }
  return membersByRef;
}

async function attachScmScheduleRouteOptions(rows = [], executor = query) {
  const groupRefs = rows
    .filter((row) => String(row.orderKind || "").toUpperCase() === "PO")
    .map((row) => String(row.groupRef || "").trim()
      || (String(row.orderRef || "").toUpperCase().startsWith("PGOB-") ? row.orderRef : ""))
    .filter(Boolean);
  const groupMembersByRef = await listScmScheduleGroupMembersByRef(groupRefs, executor);
  const refs = rows.flatMap((row) => [row.orderRef, row.dispatchRef, row.sourceRef, row.displayRef]);
  for (const members of groupMembersByRef.values()) refs.push(...members);
  const vendorOptionsByRef = await listScmVendorYardOptionsForRefs(refs, executor);
  const runQuery = typeof executor === "function" ? executor : executor.query.bind(executor);
  const poRefs = [...new Set(rows
    .filter((row) => String(row.orderKind || "").toUpperCase() === "PO")
    .map((row) => String(row.orderRef || "").trim().toLowerCase())
    .filter(Boolean))];
  const splitStatesResult = poRefs.length ? await runQuery(
    `SELECT lower(split.split_po_ref) AS split_ref, split.revision,
            (EXISTS (
               SELECT 1 FROM dispatch_plan_order_assignments assignment
               JOIN dispatch_plans plan ON plan.id = assignment.plan_id
               WHERE plan.status <> 'cancelled'
                 AND (lower(assignment.order_ref) = lower(split.split_po_ref)
                   OR lower(NULLIF(assignment.planned_order_ref, '')) = lower(split.split_po_ref))
             ) OR EXISTS (
               SELECT 1 FROM scm_transport_schedule schedule
               JOIN dispatch_plans schedule_plan
                 ON schedule_plan.id = schedule.dispatch_plan_id
                AND schedule_plan.status <> 'cancelled'
               WHERE schedule.order_kind = 'PO'
                 AND lower(schedule.order_ref) = lower(split.split_po_ref)
             ) OR EXISTS (
               SELECT 1 FROM purchase_order_lines child_line
               WHERE child_line.purchase_order_id = split.split_po_id
                 AND (COALESCE(child_line.received_pallet_qty, 0) > 0
                   OR COALESCE(child_line.received_layer_qty, 0) > 0
                   OR COALESCE(child_line.received_section_qty, 0) > 0
                   OR COALESCE(child_line.received_piece_qty, 0) > 0
                   OR COALESCE(child_line.netsuite_received_qty, 0) > 0
                   OR child_line.confirmed_at IS NOT NULL)
             ) OR EXISTS (
               SELECT 1 FROM driver_job_records job
               WHERE job.status IN ('in_progress', 'complete') AND job.order_refs ? split.split_po_ref
             ) OR EXISTS (
               SELECT 1 FROM dispatch_so_po_allocations allocation
               WHERE allocation.po_order_id = split.split_po_id AND allocation.status = 'active'
             ) OR EXISTS (
               SELECT 1 FROM scm_schedule_group_members member
               JOIN scm_schedule_groups group_header ON group_header.id = member.group_id
               WHERE group_header.status = 'active' AND lower(member.order_ref) = lower(split.split_po_ref)
             )) AS locked
       FROM dispatch_scm_po_splits split
      WHERE split.status = 'active' AND lower(split.split_po_ref) = ANY($1::text[])`,
    [poRefs]
  ) : { rows: [] };
  const splitStates = new Map(splitStatesResult.rows.map((row) => [row.split_ref, row]));
  const ownYards = SCM_VRMA_OWN_YARDS.map((yard) => yard.code);
  return rows.map((row) => {
    const splitState = splitStates.get(String(row.orderRef || "").trim().toLowerCase());
    return {
      ...row,
      ...scmScheduleRouteOptions(row, { vendorOptionsByRef, groupMembersByRef, ownYards }),
      isScmSplit: Boolean(splitState),
      scmSplitRevision: splitState ? Number(splitState.revision || 1) : null,
      scmSplitLocked: splitState?.locked === true
    };
  });
}

async function isUnchangedScmPurchaseOrderPickup({
  ref = "",
  requestedPickup = "",
  currentPickup = "",
  groupRef = ""
} = {}) {
  const unchanged = isUnchangedScmPoPickup({ requestedPickup, currentPickup, groupRef });
  if (unchanged || !scmPoPickupNeedsNetSuiteAddressLookup({ requestedPickup, currentPickup, groupRef })) {
    return unchanged;
  }

  const result = await query(
    `WITH matched_po AS MATERIALIZED (
       SELECT po.netsuite_id,
              po.vendor_id::text AS vendor_id,
              po.vendor,
              CASE
                WHEN lower(COALESCE(po.tranid, '')) = lower($1) THEN 0
                WHEN lower(COALESCE(po.dispatch_ref, '')) = lower($1) THEN 1
                ELSE 2
              END AS ref_rank
         FROM purchase_orders po
        WHERE po.netsuite_active = true
          AND (
            lower(COALESCE(po.tranid, '')) = lower($1)
            OR lower(COALESCE(po.dispatch_ref, '')) = lower($1)
            OR po.netsuite_id::text = $1
          )
        ORDER BY ref_rank, po.netsuite_id DESC
        LIMIT 1
     ),
     canonical_mapping AS (
       SELECT po.vendor,
              COALESCE(
                (SELECT NULLIF(mapping.local_vendor, '')
                   FROM dispatch_vendor_mappings mapping
                  WHERE mapping.active = true
                    AND COALESCE(mapping.netsuite_vendor_id, '') <> ''
                    AND COALESCE(mapping.local_vendor, '') <> ''
                    AND mapping.netsuite_vendor_id = po.vendor_id
                  ORDER BY mapping.last_seen_at DESC, mapping.id DESC
                  LIMIT 1),
                (SELECT NULLIF(mapping.local_vendor, '')
                   FROM dispatch_vendor_mappings mapping
                  WHERE mapping.active = true
                    AND COALESCE(mapping.netsuite_vendor_name, '') <> ''
                    AND COALESCE(mapping.local_vendor, '') <> ''
                    AND lower(mapping.netsuite_vendor_name) = lower(po.vendor)
                  ORDER BY mapping.last_seen_at DESC, mapping.id DESC
                  LIMIT 1),
                ''
              ) AS local_vendor
         FROM matched_po po
     )
     SELECT vendor
       FROM canonical_mapping
      WHERE local_vendor = $2`,
    [String(ref || "").trim(), useNetSuiteAddressMappingValue()]
  );
  return isUnchangedScmPoPickup({
    requestedPickup,
    currentPickup,
    groupRef,
    netSuiteAddressVendor: result.rows[0]?.vendor
  });
}

async function resolveScmPurchaseOrderPickupYard(client, source = {}, pickupPoint = "") {
  const requested = String(pickupPoint || "").trim();
  if (!requested) return null;
  const optionsByRef = await listScmVendorYardOptionsForRefs([
    source.tranid,
    source.dispatch_ref,
    source.netsuite_id
  ], client);
  const options = optionsByRef.get(String(source.tranid || "").toLowerCase())
    || optionsByRef.get(String(source.dispatch_ref || "").toLowerCase())
    || optionsByRef.get(String(source.netsuite_id || "").toLowerCase())
    || [];
  const selected = options.find((option) =>
    String(option.yard || "").trim().toLowerCase() === requested.toLowerCase()
    || String(option.id || "") === requested
  );
  if (!selected) {
    throw new Error(`Pickup yard ${requested} is not available for ${source.tranid || source.dispatch_ref || "this PO"} vendor mapping.`);
  }
  return selected;
}

function vendorYardInstructions(yard = {}) {
  return `${yard.dayLabel || ""}${yard.instructions ? ` | ${yard.instructions}` : ""}`.trim();
}

function normalizeScmStatus(value) {
  const allowed = new Set(["Queued", "Planned", "Completed", "Urgent", "Cancelled", "Hold", "Priority", "Surplus Only", "Book Appt"]);
  const text = String(value || "").trim();
  return allowed.has(text) ? text : "Queued";
}

function normalizeManualScmStatus(value) {
  const allowed = new Set(["Queued", "Urgent", "Cancelled", "Hold", "Priority", "Surplus Only", "Book Appt"]);
  const text = String(value || "").trim();
  if (!text) return "Queued";
  if (!allowed.has(text)) {
    throw new Error(`${text} is controlled by dispatch or driver status and cannot be set manually.`);
  }
  return text;
}

function normalizeScmMethod(value) {
  const text = String(value || "").trim();
  if (text === "Vendor" || text === "Customer Pickup") return text;
  return "MBT";
}

function normalizeScmOrderKind(value) {
  const text = String(value || "").trim().toUpperCase();
  if (text === "TO" || text === "VRMA") return text;
  return "PO";
}

function normalizeScmScheduleFilterValues(value, { lowercase = false } = {}) {
  const source = Array.isArray(value) ? value : String(value || "").split(",");
  const values = source.map((item) => String(item || "").trim()).filter(Boolean);
  return [...new Set(values.map((item) => lowercase ? item.toLowerCase() : item))];
}

function normalizeScmScheduleOptionalNumber(value) {
  if (value === null || value === undefined || String(value).trim() === "") return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function scmDisplayRef(row = {}) {
  return row.dispatch_ref || row.display_ref || row.order_ref || row.tranid || row.vrma_ref || "";
}

// Retained as a compatibility export for callers outside this repository.
// listScmSchedule intentionally no longer uses this legacy projection.
export async function listScmVrmaSchedule({
  search = "",
  status = "",
  method = "",
  yard = "",
  brand = "",
  from = "",
  to = "",
  view = "",
  audience = "scm"
} = {}) {
  const params = [
    String(search || "").trim().toLowerCase(),
    normalizeScmScheduleFilterValues(status),
    String(method || "").trim(),
    String(yard || "").trim(),
    normalizeScmScheduleFilterValues(brand, { lowercase: true }),
    String(from || "").trim() || null,
    String(to || "").trim() || null,
    String(view || "").trim(),
    String(audience || "").trim().toLowerCase() !== "operations"
  ];
  const result = await query(
    `WITH line_summary AS (
       SELECT l.vrma_order_id,
              string_agg(
                trim(concat_ws(' ',
                  COALESCE(NULLIF(l.sku, ''), NULLIF(l.item_name, ''), 'Item'),
                  CASE
                    WHEN COALESCE(l.pallet_qty, 0) + COALESCE(l.layer_qty, 0) + COALESCE(l.section_qty, 0) + COALESCE(l.piece_qty, 0) > 0
                      THEN trim(concat_ws(' ',
                        CASE WHEN COALESCE(l.pallet_qty, 0) > 0 THEN trim(to_char(l.pallet_qty, 'FM999999999990.##')) || ' PLT' END,
                        CASE WHEN COALESCE(l.layer_qty, 0) > 0 THEN trim(to_char(l.layer_qty, 'FM999999999990.##')) || ' LYR' END,
                        CASE WHEN COALESCE(l.section_qty, 0) > 0 THEN trim(to_char(l.section_qty, 'FM999999999990.##')) || ' SEC' END,
                        CASE WHEN COALESCE(l.piece_qty, 0) > 0 THEN trim(to_char(l.piece_qty, 'FM999999999990.##')) || ' PCS' END
                      ))
                    ELSE trim(concat_ws(' ',
                      trim(to_char(COALESCE(l.quantity, 0), 'FM999999999990.######')),
                      NULLIF(l.unit, '')
                    ))
                  END
                )),
                '; ' ORDER BY l.id
              ) AS content,
              COALESCE(SUM(l.pallet_qty), 0) AS total_pallet_qty,
              COALESCE(SUM(l.weight_lbs), 0) AS weight_lbs
         FROM scm_vrma_order_lines l
        GROUP BY l.vrma_order_id
     ),
     planned AS (
       SELECT DISTINCT ON (LOWER(a.order_ref))
              a.order_ref,
              a.plan_date AS eta_date,
              COALESCE(a.eta_time, '') AS eta_time,
              COALESCE(a.driver, '') AS driver,
              trim(concat_ws(' ', NULLIF(a.truck_plate, ''), NULLIF(a.load_name, ''))) AS notes
         FROM dispatch_vrma_plan_assignments a
         JOIN dispatch_plans p ON p.id = a.plan_id AND p.status <> 'cancelled'
        ORDER BY LOWER(a.order_ref), a.plan_date DESC, a.updated_at DESC
     ),
     vrma_rows AS (
       SELECT
         COALESCE(s.id, 0) AS schedule_id,
         'VRMA'::text AS order_kind,
         'scm_vrma_orders'::text AS source_table,
         v.id AS source_id,
         v.vrma_ref AS source_ref,
         v.vrma_ref AS order_ref,
         ''::text AS dispatch_ref,
         COALESCE(v.local_vendor, v.vendor, 'Vendor Return') AS party,
         COALESCE(NULLIF(s.display_ref, ''), v.vrma_ref) AS display_ref,
         COALESCE(s.is_special_order, false) AS is_special_order,
         'MBT'::text AS method,
         v.pickup_location AS pickup_point,
         v.dropoff_location AS dropoff_point,
         COALESCE(v.local_vendor, v.vendor, '') AS brand,
         COALESCE(NULLIF(s.content, ''), summary.content, '') AS content,
         COALESCE(summary.total_pallet_qty, 0) AS total_pallet_qty,
         COALESCE(NULLIF(s.weight_lbs, 0), summary.weight_lbs, 0) AS weight_lbs,
         COALESCE(NULLIF(s.packing_slip_ref, ''), '') AS packing_slip_ref,
         COALESCE(s.group_ref, '') AS group_ref,
         CASE
           WHEN COALESCE(s.status, '') IN ('Completed', 'Cancelled', 'Hold') THEN s.status
           WHEN planned.order_ref IS NOT NULL THEN 'Planned'
           WHEN COALESCE(s.status, '') = 'Planned' THEN COALESCE(v.status, 'Queued')
           ELSE COALESCE(s.status, v.status, 'Queued')
         END AS status,
         COALESCE(s.created_at, v.created_at) AS queued_at,
         COALESCE(s.eta_date, planned.eta_date) AS eta_date,
         COALESCE(NULLIF(s.eta_time, ''), planned.eta_time, '') AS eta_time,
         COALESCE(NULLIF(s.driver, ''), planned.driver, '') AS driver,
         COALESCE(NULLIF(s.notes, ''), planned.notes, '') AS notes,
         s.updated_at,
         s.updated_by
       FROM scm_vrma_orders v
       LEFT JOIN line_summary summary ON summary.vrma_order_id = v.id
       LEFT JOIN scm_transport_schedule s
         ON s.order_kind = 'VRMA'
        AND LOWER(s.order_ref) = LOWER(v.vrma_ref)
       LEFT JOIN planned ON LOWER(planned.order_ref) = LOWER(v.vrma_ref)
     )
     SELECT *,
            CASE
              WHEN eta_date IS NULL OR queued_at IS NULL THEN NULL
              ELSE eta_date - queued_at::date
            END AS sla_days
       FROM vrma_rows
      WHERE ($1 = '' OR LOWER(CONCAT_WS(' ', order_ref, party, pickup_point, dropoff_point, brand, content, packing_slip_ref, group_ref)) LIKE '%' || $1 || '%')
        AND (cardinality($2::text[]) = 0 OR status = ANY($2::text[]))
        AND ($3 = '' OR method = $3)
        AND ($4 = '' OR dropoff_point = $4)
        AND (cardinality($5::text[]) = 0 OR LOWER(brand) = ANY($5::text[]))
        AND ($6::date IS NULL OR eta_date >= $6::date)
        AND ($7::date IS NULL OR eta_date <= $7::date)
        AND ($8 <> 'dispatch' OR (method = 'MBT' AND status NOT IN ('Cancelled', 'Hold')))
        AND ($8 <> 'completed' OR status = 'Completed')
        AND (
          $9::boolean
          OR LOWER(BTRIM(COALESCE(status, 'Queued'))) NOT IN (
            'hold', 'complete', 'completed', 'cancelled', 'canceled'
          )
        )
      ORDER BY
        CASE status
          WHEN 'Urgent' THEN 0
          WHEN 'Priority' THEN 1
          WHEN 'Queued' THEN 2
          WHEN 'Book Appt' THEN 3
          WHEN 'Surplus Only' THEN 4
          WHEN 'Planned' THEN 5
          WHEN 'Completed' THEN 6
          WHEN 'Hold' THEN 7
          ELSE 9
        END,
        eta_date NULLS LAST,
        order_ref
      LIMIT 1000`,
    params
  );
  return result.rows.map((row) => ({
    scheduleId: Number(row.schedule_id || 0),
    orderKind: "VRMA",
    sourceTable: row.source_table,
    sourceId: row.source_id,
    sourceRef: row.source_ref,
    orderRef: row.order_ref,
    dispatchRef: "",
    party: row.party || "",
    displayRef: row.display_ref || row.order_ref,
    isSpecialOrder: row.is_special_order === true,
    method: "MBT",
    pickupPoint: row.pickup_point || "",
    dropoffPoint: row.dropoff_point || "",
    brand: row.brand || "",
    content: row.content || "",
    totalPalletQty: Number(row.total_pallet_qty || 0),
    weightLbs: Number(row.weight_lbs || 0),
    packingSlipRef: row.packing_slip_ref || "",
    groupRef: row.group_ref || "",
    status: row.status || "Queued",
    queuedDate: dateOnly(row.queued_at),
    etaDate: dateOnly(row.eta_date),
    etaTime: row.eta_time || "",
    driver: row.driver || "",
    sla: row.sla_days === null || row.sla_days === undefined ? "" : `${Number(row.sla_days)} day${Number(row.sla_days) === 1 ? "" : "s"}`,
    slaDays: row.sla_days === null || row.sla_days === undefined ? null : Number(row.sla_days),
    notes: row.notes || "",
    updatedAt: row.updated_at,
    updatedBy: row.updated_by || ""
  }));
}

export async function listScmSchedule({
  search = "",
  status = "",
  method = "",
  kind = "",
  yard = "",
  brand = "",
  from = "",
  to = "",
  queuedFrom = "",
  queuedTo = "",
  pickup = "",
  contentSearch = "",
  remarkSearch = "",
  orderSearch = "",
  weightMin = "",
  weightMax = "",
  packingSearch = "",
  driverSearch = "",
  slaMin = "",
  slaMax = "",
  view = "",
  exactRef = "",
  audience = "scm"
} = {}) {
  const globalSearch = String(search || "").trim().toLowerCase();
  const rawKind = String(kind || "").trim().toUpperCase();
  const cleanKind = rawKind === "SP.O" ? "Sp.O" : rawKind;
  const cleanExactRef = String(exactRef || "").trim();
  const searchAllStatuses = Boolean(globalSearch) && String(audience).trim().toLowerCase() !== "operations";
  const statusFilters = searchAllStatuses ? [] : normalizeScmScheduleFilterValues(status);
  const cleanView = String(view || "").trim().toLowerCase();
  const includeCompleted = searchAllStatuses || cleanView === "completed"
    || statusFilters.some((value) => value.toLowerCase() === "completed");
  const params = [
    globalSearch,
    statusFilters,
    String(method || "").trim(),
    cleanKind,
    String(yard || "").trim(),
    normalizeScmScheduleFilterValues(brand, { lowercase: true }),
    String(from || "").trim() || null,
    String(to || "").trim() || null,
    cleanView,
    cleanExactRef,
    String(audience || "").trim().toLowerCase() !== "operations",
    String(queuedFrom || "").trim() || null,
    String(queuedTo || "").trim() || null,
    String(pickup || "").trim().toLowerCase(),
    String(contentSearch || "").trim().toLowerCase(),
    String(remarkSearch || "").trim().toLowerCase(),
    String(orderSearch || "").trim().toLowerCase(),
    normalizeScmScheduleOptionalNumber(weightMin),
    normalizeScmScheduleOptionalNumber(weightMax),
    String(packingSearch || "").trim().toLowerCase(),
    String(driverSearch || "").trim().toLowerCase(),
    normalizeScmScheduleOptionalNumber(slaMin),
    normalizeScmScheduleOptionalNumber(slaMax),
    includeCompleted
  ];
  const result = await query(
    `
    WITH active_po_split_alloc AS MATERIALIZED (
      SELECT split_line.source_line_id,
             SUM(COALESCE(split_line.pallet_qty, 0)) AS pallet_qty,
             SUM(COALESCE(split_line.layer_qty, 0)) AS layer_qty,
             SUM(COALESCE(split_line.section_qty, 0)) AS section_qty,
             SUM(COALESCE(split_line.piece_qty, 0)) AS piece_qty,
             SUM(COALESCE(split_line.sales_qty, 0)) AS sales_qty
        FROM dispatch_scm_po_split_lines split_line
        JOIN dispatch_scm_po_splits split_header
          ON split_header.id = split_line.split_id
         AND split_header.status = 'active'
       GROUP BY split_line.source_line_id
    ),
    closed_po_source_ids AS MATERIALIZED (
      SELECT po.netsuite_id AS source_id
        FROM purchase_orders po
       WHERE ${exactNetSuiteClosedSql("po")}
      UNION
      SELECT family.source_po_id
        FROM dispatch_scm_po_splits family
        JOIN purchase_orders closed_member
          ON closed_member.netsuite_id = family.split_po_id
       WHERE ${exactNetSuiteClosedSql("closed_member")}
    ),
    closed_po_family_ids AS MATERIALIZED (
      SELECT source_id AS netsuite_id
        FROM closed_po_source_ids
      UNION
      SELECT family.split_po_id
        FROM dispatch_scm_po_splits family
        JOIN closed_po_source_ids closed_family
          ON closed_family.source_id = family.source_po_id
    ),
    closed_to_source_ids AS MATERIALIZED (
      SELECT transfer_header.netsuite_id AS source_id
        FROM transfer_orders transfer_header
       WHERE ${exactNetSuiteClosedSql("transfer_header")}
      UNION
      SELECT family.source_to_id
        FROM dispatch_scm_to_splits family
        JOIN transfer_orders closed_member
          ON closed_member.netsuite_id = family.split_to_id
       WHERE ${exactNetSuiteClosedSql("closed_member")}
    ),
    closed_to_family_ids AS MATERIALIZED (
      SELECT source_id AS netsuite_id
        FROM closed_to_source_ids
      UNION
      SELECT family.split_to_id
        FROM dispatch_scm_to_splits family
        JOIN closed_to_source_ids closed_family
          ON closed_family.source_id = family.source_to_id
    ),
    base_po AS (
      SELECT
        'PO'::text AS order_kind,
        'purchase_orders'::text AS source_table,
        po.netsuite_id AS source_id,
        COALESCE(active_split.source_po_ref, po.tranid) AS source_ref,
        COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid) AS order_ref,
        po.dispatch_ref,
        active_split.split_po_ref AS split_ref,
        po.vendor AS party,
        COALESCE(NULLIF(po.dispatch_vendor_yard, ''), NULLIF(po.source_location, ''), po.vendor) AS pickup_point,
        po.destination_location AS dropoff_point,
        COALESCE(NULLIF(po.dispatch_vendor_yard, ''), po.vendor) AS brand,
        NULL::text AS source_memo,
        string_agg(
          CASE
            WHEN COALESCE(l.to_plt, 0) <> 0 OR COALESCE(l.to_lyr, 0) <> 0 OR COALESCE(l.to_sec, 0) <> 0 OR COALESCE(l.to_pcs, 0) <> 0 THEN
              trim(concat_ws(' ',
                COALESCE(NULLIF(l.sku, ''), NULLIF(l.item_name, ''), 'Item'),
                NULLIF(trim(concat_ws(' ',
                  CASE WHEN GREATEST(COALESCE(l.pallet_qty, 0) - COALESCE(l.received_pallet_qty, 0) - COALESCE(split_alloc.pallet_qty, 0), 0) > 0 THEN trim(to_char(GREATEST(COALESCE(l.pallet_qty, 0) - COALESCE(l.received_pallet_qty, 0) - COALESCE(split_alloc.pallet_qty, 0), 0), 'FM999999999990.##')) || ' PLT' END,
                  CASE WHEN GREATEST(COALESCE(l.layer_qty, 0) - COALESCE(l.received_layer_qty, 0) - COALESCE(split_alloc.layer_qty, 0), 0) > 0 THEN trim(to_char(GREATEST(COALESCE(l.layer_qty, 0) - COALESCE(l.received_layer_qty, 0) - COALESCE(split_alloc.layer_qty, 0), 0), 'FM999999999990.##')) || ' LYR' END,
                  CASE WHEN GREATEST(COALESCE(l.section_qty, 0) - COALESCE(l.received_section_qty, 0) - COALESCE(split_alloc.section_qty, 0), 0) > 0 THEN trim(to_char(GREATEST(COALESCE(l.section_qty, 0) - COALESCE(l.received_section_qty, 0) - COALESCE(split_alloc.section_qty, 0), 0), 'FM999999999990.##')) || ' SEC' END,
                  CASE WHEN GREATEST(COALESCE(l.piece_qty, 0) - COALESCE(l.received_piece_qty, 0) - COALESCE(split_alloc.piece_qty, 0), 0) > 0 THEN trim(to_char(GREATEST(COALESCE(l.piece_qty, 0) - COALESCE(l.received_piece_qty, 0) - COALESCE(split_alloc.piece_qty, 0), 0), 'FM999999999990.##')) || ' PCS' END
                )), '')
              ))
            ELSE
              trim(concat_ws(' ',
                COALESCE(NULLIF(l.sku, ''), NULLIF(l.item_name, ''), 'Item'),
                trim(to_char(GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0) - COALESCE(split_alloc.sales_qty, 0), 0), 'FM999999999990.######')),
                NULLIF(l.unit, '')
              ))
          END,
          E'\n' ORDER BY l.line_id NULLS LAST, l.id
        ) FILTER (
          WHERE l.id IS NOT NULL
            AND (
              CASE
                WHEN COALESCE(l.to_plt, 0) <> 0 OR COALESCE(l.to_lyr, 0) <> 0 OR COALESCE(l.to_sec, 0) <> 0 OR COALESCE(l.to_pcs, 0) <> 0 THEN
                  GREATEST(COALESCE(l.pallet_qty, 0) - COALESCE(l.received_pallet_qty, 0) - COALESCE(split_alloc.pallet_qty, 0), 0)
                  + GREATEST(COALESCE(l.layer_qty, 0) - COALESCE(l.received_layer_qty, 0) - COALESCE(split_alloc.layer_qty, 0), 0)
                  + GREATEST(COALESCE(l.section_qty, 0) - COALESCE(l.received_section_qty, 0) - COALESCE(split_alloc.section_qty, 0), 0)
                  + GREATEST(COALESCE(l.piece_qty, 0) - COALESCE(l.received_piece_qty, 0) - COALESCE(split_alloc.piece_qty, 0), 0)
                ELSE GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0) - COALESCE(split_alloc.sales_qty, 0), 0)
              END
            ) > 0
        ) AS content,
        po.expected_delivery_date,
        COALESCE(po.synced_at, po.status_updated_at, now()) AS queued_at,
        COALESCE(SUM(GREATEST(COALESCE(l.pallet_qty, 0) - COALESCE(l.received_pallet_qty, 0) - COALESCE(split_alloc.pallet_qty, 0), 0)), 0) AS total_pallet_qty,
        COALESCE(SUM(GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0) - COALESCE(split_alloc.sales_qty, 0), 0) * COALESCE(l.item_weight, 0)), 0) AS weight_lbs,
        po.initial_scm_status,
        po.is_blanket_po
      FROM purchase_orders po
      LEFT JOIN dispatch_scm_po_splits active_split
        ON active_split.split_po_id = po.netsuite_id
       AND active_split.status = 'active'
      LEFT JOIN scm_transport_schedule member_schedule
        ON member_schedule.order_kind = 'PO'
       AND lower(member_schedule.order_ref) = lower(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid))
      LEFT JOIN scm_schedule_groups active_group
        ON active_group.status = 'active'
       AND lower(active_group.group_ref) = lower(COALESCE(member_schedule.group_ref, ''))
      LEFT JOIN purchase_order_lines l ON l.purchase_order_id = po.netsuite_id AND l.netsuite_active = true
      LEFT JOIN active_po_split_alloc split_alloc ON split_alloc.source_line_id = l.id
      WHERE (po.netsuite_active = true OR $24::boolean)
        AND NOT EXISTS (
          SELECT 1
            FROM closed_po_family_ids closed_family
           WHERE closed_family.netsuite_id = po.netsuite_id
        )
        AND (
          $10 = ''
          OR lower(po.tranid) = lower($10)
          OR lower(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid)) = lower($10)
        )
        AND (
          active_group.id IS NULL
          OR lower(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid)) = lower(active_group.group_ref)
        )
      GROUP BY po.netsuite_id, active_split.source_po_ref, active_split.split_po_ref
      HAVING $24::boolean
          OR COUNT(l.id) = 0
          OR COALESCE(SUM(
            CASE
              WHEN l.id IS NULL THEN 0
              WHEN COALESCE(l.to_plt, 0) <> 0
                OR COALESCE(l.to_lyr, 0) <> 0
                OR COALESCE(l.to_sec, 0) <> 0
                OR COALESCE(l.to_pcs, 0) <> 0
              THEN
                GREATEST(COALESCE(l.pallet_qty, 0) - COALESCE(l.received_pallet_qty, 0) - COALESCE(split_alloc.pallet_qty, 0), 0)
                + GREATEST(COALESCE(l.layer_qty, 0) - COALESCE(l.received_layer_qty, 0) - COALESCE(split_alloc.layer_qty, 0), 0)
                + GREATEST(COALESCE(l.section_qty, 0) - COALESCE(l.received_section_qty, 0) - COALESCE(split_alloc.section_qty, 0), 0)
                + GREATEST(COALESCE(l.piece_qty, 0) - COALESCE(l.received_piece_qty, 0) - COALESCE(split_alloc.piece_qty, 0), 0)
              ELSE GREATEST(
                COALESCE(l.quantity, 0)
                - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0)
                - COALESCE(split_alloc.sales_qty, 0),
                0
              )
            END
          ), 0) > 0.000001
    ),
    unique_to_line_locations AS MATERIALIZED (
      SELECT line.transfer_order_id,
             line.line_stage,
             CASE
               WHEN COUNT(DISTINCT line.location_id) FILTER (WHERE line.location_id IS NOT NULL) = 1
               THEN MIN(line.location_id) FILTER (WHERE line.location_id IS NOT NULL)
               ELSE NULL
             END AS location_id,
             CASE
               WHEN COUNT(DISTINCT line.location_id) FILTER (WHERE line.location_id IS NOT NULL) = 1
               THEN MAX(NULLIF(BTRIM(line.location), '')) FILTER (WHERE line.location_id IS NOT NULL)
               ELSE NULL
             END AS location
        FROM transfer_order_lines line
       WHERE line.netsuite_active = true
         AND line.line_stage IN ('outbound', 'receiving')
       GROUP BY line.transfer_order_id, line.line_stage
    ),
    base_to AS (
      SELECT
        'TO'::text AS order_kind,
        'transfer_orders'::text AS source_table,
        t.netsuite_id AS source_id,
        t.tranid AS source_ref,
        t.tranid AS order_ref,
        NULL::text AS dispatch_ref,
        NULL::text AS split_ref,
        COALESCE(
          NULLIF(BTRIM(t.from_location), ''),
          NULLIF(BTRIM(outbound_location.location), ''),
          'Transfer Order'
        ) AS party,
        COALESCE(
          NULLIF(BTRIM(t.from_location), ''),
          NULLIF(BTRIM(outbound_location.location), '')
        ) AS pickup_point,
        COALESCE(
          NULLIF(BTRIM(t.to_location), ''),
          NULLIF(BTRIM(receiving_location.location), '')
        ) AS dropoff_point,
        'Transfer'::text AS brand,
        t.memo AS source_memo,
        string_agg(
          CASE
            WHEN COALESCE(l.to_plt, 0) <> 0 OR COALESCE(l.to_lyr, 0) <> 0 OR COALESCE(l.to_sec, 0) <> 0 OR COALESCE(l.to_pcs, 0) <> 0 THEN
              trim(concat_ws(' ',
                COALESCE(NULLIF(l.sku, ''), NULLIF(l.item_name, ''), 'Item'),
                NULLIF(trim(concat_ws(' ',
                  CASE WHEN GREATEST(COALESCE(l.pallet_qty, 0) - GREATEST(COALESCE(l.fulfilled_pallet_qty, 0), COALESCE(l.received_pallet_qty, 0)), 0) > 0 THEN trim(to_char(GREATEST(COALESCE(l.pallet_qty, 0) - GREATEST(COALESCE(l.fulfilled_pallet_qty, 0), COALESCE(l.received_pallet_qty, 0)), 0), 'FM999999999990.##')) || ' PLT' END,
                  CASE WHEN GREATEST(COALESCE(l.layer_qty, 0) - GREATEST(COALESCE(l.fulfilled_layer_qty, 0), COALESCE(l.received_layer_qty, 0)), 0) > 0 THEN trim(to_char(GREATEST(COALESCE(l.layer_qty, 0) - GREATEST(COALESCE(l.fulfilled_layer_qty, 0), COALESCE(l.received_layer_qty, 0)), 0), 'FM999999999990.##')) || ' LYR' END,
                  CASE WHEN GREATEST(COALESCE(l.section_qty, 0) - GREATEST(COALESCE(l.fulfilled_section_qty, 0), COALESCE(l.received_section_qty, 0)), 0) > 0 THEN trim(to_char(GREATEST(COALESCE(l.section_qty, 0) - GREATEST(COALESCE(l.fulfilled_section_qty, 0), COALESCE(l.received_section_qty, 0)), 0), 'FM999999999990.##')) || ' SEC' END,
                  CASE WHEN GREATEST(COALESCE(l.piece_qty, 0) - GREATEST(COALESCE(l.fulfilled_piece_qty, 0), COALESCE(l.received_piece_qty, 0)), 0) > 0 THEN trim(to_char(GREATEST(COALESCE(l.piece_qty, 0) - GREATEST(COALESCE(l.fulfilled_piece_qty, 0), COALESCE(l.received_piece_qty, 0)), 0), 'FM999999999990.##')) || ' PCS' END
                )), '')
              ))
            ELSE
              trim(concat_ws(' ',
                COALESCE(NULLIF(l.sku, ''), NULLIF(l.item_name, ''), 'Item'),
                trim(to_char(GREATEST(COALESCE(l.quantity, 0) - GREATEST(COALESCE(l.netsuite_received_qty, 0), COALESCE(l.loaded_qty, 0)), 0), 'FM999999999990.######')),
                NULLIF(l.unit, '')
              ))
          END,
          E'\n' ORDER BY l.line_id NULLS LAST, l.id
        ) FILTER (
          WHERE l.id IS NOT NULL
            AND (
              CASE
                WHEN COALESCE(l.to_plt, 0) <> 0 OR COALESCE(l.to_lyr, 0) <> 0 OR COALESCE(l.to_sec, 0) <> 0 OR COALESCE(l.to_pcs, 0) <> 0 THEN
                  GREATEST(COALESCE(l.pallet_qty, 0) - GREATEST(COALESCE(l.fulfilled_pallet_qty, 0), COALESCE(l.received_pallet_qty, 0)), 0)
                  + GREATEST(COALESCE(l.layer_qty, 0) - GREATEST(COALESCE(l.fulfilled_layer_qty, 0), COALESCE(l.received_layer_qty, 0)), 0)
                  + GREATEST(COALESCE(l.section_qty, 0) - GREATEST(COALESCE(l.fulfilled_section_qty, 0), COALESCE(l.received_section_qty, 0)), 0)
                  + GREATEST(COALESCE(l.piece_qty, 0) - GREATEST(COALESCE(l.fulfilled_piece_qty, 0), COALESCE(l.received_piece_qty, 0)), 0)
                ELSE GREATEST(COALESCE(l.quantity, 0) - GREATEST(COALESCE(l.netsuite_received_qty, 0), COALESCE(l.loaded_qty, 0)), 0)
              END
            ) > 0
        ) AS content,
        t.expected_delivery_date,
        COALESCE(t.synced_at, t.status_updated_at, now()) AS queued_at,
        COALESCE(SUM(GREATEST(COALESCE(l.pallet_qty, 0) - GREATEST(COALESCE(l.fulfilled_pallet_qty, 0), COALESCE(l.received_pallet_qty, 0)), 0)), 0) AS total_pallet_qty,
        COALESCE(SUM(GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_qty, 0), 0) * COALESCE(l.item_weight, 0)), 0) AS weight_lbs,
        'Queued'::text AS initial_scm_status,
        false AS is_blanket_po
      FROM transfer_orders t
      LEFT JOIN transfer_order_lines l
        ON l.transfer_order_id = t.netsuite_id
       AND l.line_stage = 'outbound'
       AND l.netsuite_active = true
      LEFT JOIN unique_to_line_locations outbound_location
        ON outbound_location.transfer_order_id = t.netsuite_id
       AND outbound_location.line_stage = 'outbound'
      LEFT JOIN unique_to_line_locations receiving_location
        ON receiving_location.transfer_order_id = t.netsuite_id
       AND receiving_location.line_stage = 'receiving'
	      WHERE (t.netsuite_active = true OR $24::boolean)
	        AND NOT EXISTS (
	          SELECT 1
	            FROM closed_to_family_ids closed_family
	           WHERE closed_family.netsuite_id = t.netsuite_id
	        )
        AND COALESCE(t.to_location_id, receiving_location.location_id) IS NOT NULL
        AND ($10 = '' OR lower(t.tranid) = lower($10))
      GROUP BY t.netsuite_id,
               outbound_location.location,
               receiving_location.location,
               receiving_location.location_id
    ),
    base_vrma AS (
      SELECT
        'VRMA'::text AS order_kind,
        'scm_vrma_orders'::text AS source_table,
        v.id AS source_id,
        v.vrma_ref AS source_ref,
        v.vrma_ref AS order_ref,
        NULL::text AS dispatch_ref,
        NULL::text AS split_ref,
        COALESCE(v.local_vendor, v.vendor, 'Vendor Return') AS party,
        v.pickup_location AS pickup_point,
        v.dropoff_location AS dropoff_point,
        COALESCE(v.local_vendor, v.vendor) AS brand,
        NULL::text AS source_memo,
        string_agg(
          trim(concat_ws(' ',
            COALESCE(NULLIF(l.sku, ''), NULLIF(l.item_name, ''), 'Item'),
            CASE
              WHEN COALESCE(l.pallet_qty, 0) + COALESCE(l.layer_qty, 0) + COALESCE(l.section_qty, 0) + COALESCE(l.piece_qty, 0) > 0
                THEN trim(concat_ws(' ',
                  CASE WHEN COALESCE(l.pallet_qty, 0) > 0 THEN trim(to_char(l.pallet_qty, 'FM999999999990.##')) || ' PLT' END,
                  CASE WHEN COALESCE(l.layer_qty, 0) > 0 THEN trim(to_char(l.layer_qty, 'FM999999999990.##')) || ' LYR' END,
                  CASE WHEN COALESCE(l.section_qty, 0) > 0 THEN trim(to_char(l.section_qty, 'FM999999999990.##')) || ' SEC' END,
                  CASE WHEN COALESCE(l.piece_qty, 0) > 0 THEN trim(to_char(l.piece_qty, 'FM999999999990.##')) || ' PCS' END
                ))
              ELSE trim(concat_ws(' ',
                trim(to_char(COALESCE(l.quantity, 0), 'FM999999999990.######')),
                NULLIF(l.unit, '')
              ))
            END
          )),
          '; ' ORDER BY l.id
        ) FILTER (WHERE l.id IS NOT NULL) AS content,
        NULL::date AS expected_delivery_date,
        v.created_at AS queued_at,
        COALESCE(SUM(l.pallet_qty), 0) AS total_pallet_qty,
        COALESCE(SUM(l.weight_lbs), 0) AS weight_lbs,
        'Queued'::text AS initial_scm_status,
        false AS is_blanket_po
      FROM scm_vrma_orders v
      LEFT JOIN scm_vrma_order_lines l ON l.vrma_order_id = v.id
      WHERE ($10 = '' OR lower(v.vrma_ref) = lower($10))
      GROUP BY v.id
    ),
    base AS (
      SELECT * FROM base_po
      UNION ALL SELECT * FROM base_to
      UNION ALL SELECT * FROM base_vrma
    ),
    direct_planned AS MATERIALIZED (
      SELECT DISTINCT ON (
               upper(assignment.assignment->>'dispatchOrderKind'),
               lower(assignment.order_ref)
             )
             upper(assignment.assignment->>'dispatchOrderKind') AS order_kind,
             assignment.order_ref,
             assignment.plan_date AS eta_date,
             COALESCE(assignment.assignment->>'dispatchEtaTime', '') AS eta_time,
             COALESCE(
               NULLIF(assignment.assignment->>'dispatchDriverName', ''),
               NULLIF(assignment.assignment->>'dispatchDriverLogin', ''),
               ''
             ) AS driver,
             trim(concat_ws(' ',
               NULLIF(assignment.assignment->>'dispatchTruckPlate', ''),
               NULLIF(assignment.assignment->>'dispatchLoadName', ''),
               CASE
                 WHEN NULLIF(assignment.assignment->>'dispatchParkingSpot', '') IS NOT NULL
                   THEN 'Parking ' || (assignment.assignment->>'dispatchParkingSpot')
               END
             )) AS notes
        FROM dispatch_plan_order_assignments assignment
        JOIN dispatch_plans p
          ON p.id = assignment.plan_id
         AND p.status <> 'cancelled'
       WHERE upper(assignment.assignment->>'dispatchOrderKind') IN ('PO', 'TO', 'VRMA')
       ORDER BY upper(assignment.assignment->>'dispatchOrderKind'),
                lower(assignment.order_ref), assignment.plan_date DESC,
                COALESCE(assignment.assignment->>'dispatchEtaTime', '') DESC,
                assignment.updated_at DESC
    ),
    fully_linked_po AS MATERIALIZED (
      SELECT DISTINCT allocation.po_order_id,
             btrim(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid)) AS po_order_ref
        FROM dispatch_so_po_allocations allocation
        JOIN purchase_orders po
          ON po.netsuite_id = allocation.po_order_id
       WHERE allocation.status = 'active'
         AND dispatch_po_link_fully_covers(allocation.po_order_id)
         AND NULLIF(btrim(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid)), '') IS NOT NULL
    ),
    linked_po_planned AS MATERIALIZED (
      SELECT DISTINCT ON (lower(fully_linked.po_order_ref))
             'PO'::text AS order_kind,
             fully_linked.po_order_ref AS order_ref,
             assignment.plan_date AS eta_date,
             COALESCE(assignment.assignment->>'dispatchEtaTime', '') AS eta_time,
             COALESCE(
               NULLIF(assignment.assignment->>'dispatchDriverName', ''),
               NULLIF(assignment.assignment->>'dispatchDriverLogin', ''),
               ''
             ) AS driver,
             trim(concat_ws(' ',
               NULLIF(assignment.assignment->>'dispatchTruckPlate', ''),
               NULLIF(assignment.assignment->>'dispatchLoadName', ''),
               CASE
                 WHEN NULLIF(assignment.assignment->>'dispatchParkingSpot', '') IS NOT NULL
                   THEN 'Parking ' || (assignment.assignment->>'dispatchParkingSpot')
               END
             )) AS notes
        FROM fully_linked_po fully_linked
        JOIN dispatch_so_po_allocations linked_allocation
          ON linked_allocation.po_order_id = fully_linked.po_order_id
         AND linked_allocation.status = 'active'
        JOIN dispatch_plan_order_assignments assignment
          ON lower(assignment.order_ref) = lower(linked_allocation.dispatch_target_ref)
          OR lower(NULLIF(assignment.planned_order_ref, '')) = lower(linked_allocation.dispatch_target_ref)
        JOIN dispatch_plans linked_plan
          ON linked_plan.id = assignment.plan_id
         AND linked_plan.status <> 'cancelled'
       WHERE NOT EXISTS (
         SELECT 1
           FROM dispatch_so_po_allocations required
          WHERE required.po_order_id = fully_linked.po_order_id
            AND required.status = 'active'
            AND NOT EXISTS (
              SELECT 1
                FROM dispatch_plan_order_assignments required_assignment
                JOIN dispatch_plans required_plan
                  ON required_plan.id = required_assignment.plan_id
                 AND required_plan.status <> 'cancelled'
               WHERE lower(required_assignment.order_ref) = lower(required.dispatch_target_ref)
                  OR lower(NULLIF(required_assignment.planned_order_ref, '')) = lower(required.dispatch_target_ref)
            )
       )
       ORDER BY lower(fully_linked.po_order_ref), assignment.plan_date DESC, assignment.updated_at DESC
    ),
    planned AS (
      SELECT DISTINCT ON (candidate.order_kind, lower(candidate.order_ref))
             candidate.order_kind,
             candidate.order_ref,
             candidate.eta_date,
             candidate.eta_time,
             candidate.driver,
             candidate.notes
        FROM (
          SELECT direct.*, 0 AS source_priority FROM direct_planned direct
          UNION ALL
          SELECT linked.*, 1 AS source_priority FROM linked_po_planned linked
        ) candidate
       ORDER BY candidate.order_kind, lower(candidate.order_ref),
                candidate.source_priority, candidate.eta_date DESC, candidate.eta_time DESC
    ),
    reconciliation_target_projection AS MATERIALIZED (
      SELECT state.id AS state_id,
             state.order_kind,
             target.order_ref,
             state.application_status AS family_application_status,
             state.reconciliation_status,
             state.reconciled_at,
             target.application_status AS target_application_status
        FROM scm_reconciliation_order_state state
       CROSS JOIN LATERAL (
         SELECT entry.key AS order_ref,
                entry.value->>'applicationStatus' AS application_status
           FROM jsonb_each(
             CASE
               WHEN jsonb_typeof(state.quantity_summary->'targets') = 'object'
                 THEN state.quantity_summary->'targets'
               ELSE '{}'::jsonb
             END
           ) entry
       ) target
      UNION ALL
      SELECT state.id,
             state.order_kind,
             state.source_order_ref,
             state.application_status,
             state.reconciliation_status,
             state.reconciled_at,
             NULL::text
        FROM scm_reconciliation_order_state state
       WHERE NOT EXISTS (
         SELECT 1
           FROM jsonb_each(
             CASE
               WHEN jsonb_typeof(state.quantity_summary->'targets') = 'object'
                 THEN state.quantity_summary->'targets'
               ELSE '{}'::jsonb
             END
           ) entry
          WHERE lower(entry.key) = lower(state.source_order_ref)
       )
    ),
    schedule_completion_status AS MATERIALIZED (
      SELECT completion.completion_event_id,
             completion.order_kind,
             lower(btrim(completion.order_ref)) AS order_key,
             completion.completion_evidence_type
        FROM dispatch_order_completion_status completion
       WHERE completion.dispatch_completion_status = 'completed'
    )
    SELECT
      COALESCE(s.id, 0) AS schedule_id,
      b.order_kind,
      b.source_table,
      b.source_id,
      b.source_ref,
      b.order_ref,
      b.dispatch_ref,
      b.party,
      COALESCE(NULLIF(s.display_ref, ''), b.order_ref) AS display_ref,
      COALESCE(s.is_special_order, false) AS is_special_order,
      b.is_blanket_po,
      CASE WHEN b.order_kind = 'VRMA' THEN 'MBT' ELSE COALESCE(s.method, 'MBT') END AS method,
      NULLIF(s.pickup_point, '') AS schedule_pickup_point,
      CASE WHEN b.order_kind = 'VRMA'
        THEN COALESCE(b.pickup_point, '')
        ELSE COALESCE(NULLIF(s.pickup_point, ''), b.pickup_point, '') END AS pickup_point,
      NULLIF(BTRIM(s.dropoff_point), '') AS schedule_dropoff_point,
      CASE WHEN b.order_kind = 'VRMA'
        THEN COALESCE(b.dropoff_point, '')
        ELSE COALESCE(NULLIF(s.dropoff_point, ''), b.dropoff_point, '') END AS dropoff_point,
      CASE WHEN b.order_kind = 'VRMA'
        THEN COALESCE(b.brand, '')
        ELSE COALESCE(NULLIF(s.brand, ''), b.brand, '') END AS brand,
      COALESCE(NULLIF(s.content, ''), b.content, '') AS content,
      NULLIF(BTRIM(s.remark_override), '') AS remark_override,
      COALESCE(NULLIF(BTRIM(b.source_memo), ''), '') AS netsuite_memo,
      COALESCE(b.total_pallet_qty, 0) AS total_pallet_qty,
      COALESCE(NULLIF(s.weight_lbs, 0), b.weight_lbs, 0) AS weight_lbs,
      COALESCE(
        NULLIF(s.packing_slip_ref, ''),
        NULLIF(b.dispatch_ref, ''),
        NULLIF(b.split_ref, ''),
        ''
      ) AS packing_slip_ref,
      COALESCE(s.group_ref, '') AS group_ref,
      operational_status.status AS status,
      COALESCE(s.created_at, b.queued_at) AS queued_at,
      COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) AS eta_date,
      COALESCE(NULLIF(s.eta_time, ''), planned.eta_time, '') AS eta_time,
      COALESCE(NULLIF(s.driver, ''), planned.driver, '') AS driver,
      CASE
        WHEN COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) IS NULL OR COALESCE(s.created_at, b.queued_at) IS NULL THEN NULL
        ELSE COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) - COALESCE(s.created_at, b.queued_at)::date
      END AS sla_days,
      COALESCE(NULLIF(s.notes, ''), NULLIF(s.dispatch_assignment_note, ''), planned.notes, '') AS notes,
      effective_status.status AS calculated_status,
      dispatch_completion.completion_evidence_type AS dispatch_completion_evidence_type,
      planned.order_ref IS NOT NULL AS dispatch_planned,
      COALESCE(s.reconciliation_blocked, false) AS reconciliation_blocked,
      s.updated_at,
      to_char(s.updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS concurrency_updated_at,
      s.updated_by
    FROM base b
    LEFT JOIN scm_transport_schedule s
      ON s.order_kind = b.order_kind
     AND lower(s.order_ref) = lower(b.order_ref)
    LEFT JOIN planned
      ON planned.order_kind = b.order_kind
     AND lower(planned.order_ref) = lower(b.order_ref)
    LEFT JOIN reconciliation_target_projection reconciliation_projection
      ON reconciliation_projection.state_id = s.reconciliation_order_state_id
     AND reconciliation_projection.order_kind = b.order_kind
     AND lower(reconciliation_projection.order_ref) = lower(b.order_ref)
    LEFT JOIN schedule_completion_status dispatch_completion
      ON dispatch_completion.order_kind = b.order_kind
     AND dispatch_completion.order_key = lower(btrim(b.order_ref))
    CROSS JOIN LATERAL (
      SELECT CASE
        WHEN COALESCE(s.status, b.initial_scm_status, '') IN (
          'Completed', 'Cancelled', 'Hold', 'In Transit',
          'Partially Done', 'Reconcile Review'
        ) THEN COALESCE(s.status, b.initial_scm_status)
        WHEN planned.order_ref IS NOT NULL THEN 'Planned'
        ELSE COALESCE(s.status, b.initial_scm_status, 'Queued')
      END AS status
    ) operational_status
    CROSS JOIN LATERAL (
      SELECT CASE
        WHEN dispatch_completion.completion_event_id IS NOT NULL
          THEN 'Completed'
        WHEN lower(COALESCE(operational_status.status, '')) IN ('complete', 'completed')
          THEN 'Completed'
        WHEN b.order_kind = 'PO'
          AND NULLIF(BTRIM(b.split_ref), '') IS NOT NULL
          AND lower(BTRIM(COALESCE(operational_status.status, ''))) IN (
            'queued', 'urgent', 'cancelled', 'canceled', 'hold',
            'priority', 'surplus only', 'book appt'
          )
          THEN operational_status.status
        WHEN b.order_kind = 'PO'
          AND NULLIF(BTRIM(b.split_ref), '') IS NOT NULL
          AND planned.order_ref IS NOT NULL
          AND lower(BTRIM(COALESCE(operational_status.status, ''))) = 'planned'
          AND lower(COALESCE(
            NULLIF(reconciliation_projection.target_application_status, ''),
            reconciliation_projection.family_application_status,
            ''
          )) NOT IN ('complete', 'completed', 'cancelled', 'canceled')
          THEN operational_status.status
        WHEN COALESCE(s.reconciliation_blocked, false)
          OR reconciliation_projection.reconciliation_status = 'review'
          THEN 'Reconcile Review'
        WHEN lower(COALESCE(
          NULLIF(
            CASE
              WHEN reconciliation_projection.target_application_status = 'Reconcile Review'
                THEN reconciliation_projection.family_application_status
              ELSE reconciliation_projection.target_application_status
            END,
            ''
          ),
          reconciliation_projection.family_application_status,
          ''
        )) IN ('complete', 'completed') THEN 'Completed'
        WHEN reconciliation_projection.reconciliation_status = 'pending'
          THEN operational_status.status
        WHEN b.order_kind = 'PO'
          AND NULLIF(BTRIM(b.split_ref), '') IS NOT NULL
          AND NULLIF(BTRIM(COALESCE(
            NULLIF(
              CASE
                WHEN reconciliation_projection.target_application_status = 'Reconcile Review'
                  THEN reconciliation_projection.family_application_status
                ELSE reconciliation_projection.target_application_status
              END,
              ''
            ),
            reconciliation_projection.family_application_status,
            ''
          )), '') IS NOT NULL
          THEN COALESCE(
            NULLIF(
              CASE
                WHEN reconciliation_projection.target_application_status = 'Reconcile Review'
                  THEN reconciliation_projection.family_application_status
                ELSE reconciliation_projection.target_application_status
              END,
              ''
            ),
            NULLIF(reconciliation_projection.family_application_status, ''),
            operational_status.status
          )
        WHEN s.id IS NOT NULL
          AND s.updated_at IS NOT NULL
          AND (
            reconciliation_projection.reconciled_at IS NULL
            OR s.updated_at > reconciliation_projection.reconciled_at
          )
          THEN operational_status.status
        ELSE COALESCE(
          NULLIF(
            CASE
              WHEN reconciliation_projection.target_application_status = 'Reconcile Review'
                THEN reconciliation_projection.family_application_status
              ELSE reconciliation_projection.target_application_status
            END,
            ''
          ),
          NULLIF(reconciliation_projection.family_application_status, ''),
          operational_status.status
        )
      END AS status
    ) effective_status
    WHERE ($1 = '' OR lower(concat_ws(' ', b.order_ref, b.source_ref, b.dispatch_ref, b.party, b.pickup_point, b.dropoff_point, b.brand, b.content, s.remark_override, CASE WHEN b.order_kind = 'TO' THEN b.source_memo ELSE NULL END, s.packing_slip_ref, s.group_ref)) LIKE '%' || $1 || '%')
      AND (
        $9 = 'blanket'
        OR NOT COALESCE(b.is_blanket_po, false)
        OR COALESCE(s.reconciliation_blocked, false)
        OR reconciliation_projection.reconciliation_status = 'review'
      )
      AND ($9 <> 'blanket' OR b.order_kind = 'PO')
      AND (
        $11::boolean
        OR (
          NOT COALESCE(b.is_blanket_po, false)
          AND LOWER(BTRIM(effective_status.status)) NOT IN (
            'hold', 'complete', 'completed', 'cancelled', 'canceled'
          )
        )
      )
      AND (
        $24::boolean
        OR LOWER(BTRIM(effective_status.status)) NOT IN ('complete', 'completed')
      )
      AND (cardinality($2::text[]) = 0 OR effective_status.status = ANY($2::text[]))
      AND ($3 = '' OR COALESCE(s.method, 'MBT') = $3)
      AND (
        $4 = ''
        OR ($4 = 'Sp.O' AND b.order_kind = 'PO' AND COALESCE(s.is_special_order, false))
        OR ($4 <> 'Sp.O' AND b.order_kind = $4)
      )
      AND (
        $5 = ''
        OR COALESCE(s.dropoff_point, b.dropoff_point, '') = $5
        OR regexp_split_to_array(regexp_replace(COALESCE(s.dropoff_point, b.dropoff_point, ''), '\\s+', '', 'g'), '\\+') @> ARRAY[$5]
      )
      AND (cardinality($6::text[]) = 0 OR lower(COALESCE(NULLIF(s.brand, ''), b.brand, '')) = ANY($6::text[]))
      AND ($7::date IS NULL OR COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) >= $7::date)
      AND ($8::date IS NULL OR COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) <= $8::date)
      AND ($12::date IS NULL OR COALESCE(s.created_at, b.queued_at)::date >= $12::date)
      AND ($13::date IS NULL OR COALESCE(s.created_at, b.queued_at)::date <= $13::date)
      AND (
        $14 = ''
        OR lower(CASE WHEN b.order_kind = 'VRMA'
          THEN COALESCE(b.pickup_point, '')
          ELSE COALESCE(NULLIF(s.pickup_point, ''), b.pickup_point, '') END) LIKE '%' || $14 || '%'
      )
      AND ($15 = '' OR lower(COALESCE(NULLIF(s.content, ''), b.content, '')) LIKE '%' || $15 || '%')
      AND (
        $16 = ''
        OR lower(COALESCE(
          NULLIF(BTRIM(s.remark_override), ''),
          CASE WHEN b.order_kind = 'TO' THEN NULLIF(BTRIM(b.source_memo), '') END,
          ''
        )) LIKE '%' || $16 || '%'
      )
      AND (
        $17 = ''
        OR lower(concat_ws(' ',
          b.order_ref,
          b.source_ref,
          b.dispatch_ref,
          COALESCE(NULLIF(s.display_ref, ''), b.order_ref),
          s.group_ref
        )) LIKE '%' || $17 || '%'
      )
      AND ($18::numeric IS NULL OR COALESCE(NULLIF(s.weight_lbs, 0), b.weight_lbs, 0) >= $18::numeric)
      AND ($19::numeric IS NULL OR COALESCE(NULLIF(s.weight_lbs, 0), b.weight_lbs, 0) <= $19::numeric)
      AND (
        $20 = ''
        OR lower(COALESCE(
          NULLIF(s.packing_slip_ref, ''),
          NULLIF(b.dispatch_ref, ''),
          NULLIF(b.split_ref, ''),
          ''
        )) LIKE '%' || $20 || '%'
      )
      AND ($21 = '' OR lower(COALESCE(NULLIF(s.driver, ''), planned.driver, '')) LIKE '%' || $21 || '%')
      AND (
        $22::numeric IS NULL
        OR (
          COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) IS NOT NULL
          AND COALESCE(s.created_at, b.queued_at) IS NOT NULL
          AND COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) - COALESCE(s.created_at, b.queued_at)::date >= $22::numeric
        )
      )
      AND (
        $23::numeric IS NULL
        OR (
          COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) IS NOT NULL
          AND COALESCE(s.created_at, b.queued_at) IS NOT NULL
          AND COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) - COALESCE(s.created_at, b.queued_at)::date <= $23::numeric
        )
      )
      AND (
        $9 = ''
        OR $9 <> 'dispatch'
        OR (COALESCE(s.method, 'MBT') = 'MBT'
          AND (($1 <> '' AND $11::boolean) OR effective_status.status NOT IN ('Cancelled', 'Hold')))
      )
      AND (
        $9 = ''
        OR $9 <> 'completed'
        OR ($1 <> '' AND $11::boolean)
        OR effective_status.status IN ('Completed', 'Cancelled')
      )
    ORDER BY
      CASE WHEN $9 = 'completed' THEN 0 ELSE
        CASE effective_status.status
          WHEN 'Urgent' THEN 0
          WHEN 'Priority' THEN 1
          WHEN 'Queued' THEN 2
          WHEN 'Book Appt' THEN 3
          WHEN 'Surplus Only' THEN 4
          WHEN 'Planned' THEN 5
          WHEN 'Partially Done' THEN 6
          WHEN 'In Transit' THEN 7
          WHEN 'Reconcile Review' THEN 8
          WHEN 'Completed' THEN 9
          WHEN 'Hold' THEN 10
          ELSE 11
        END
      END,
      CASE
        WHEN effective_status.status IN ('Completed', 'Cancelled')
        THEN COALESCE(s.last_reconciled_at, s.updated_at, b.queued_at)
      END DESC NULLS LAST,
      COALESCE(s.eta_date, planned.eta_date, b.expected_delivery_date) NULLS LAST,
      b.order_ref
    LIMIT 1000
    `,
    params
  );
  const poIds = Array.from(new Set(
    result.rows
      .filter((row) => row.order_kind === "PO" && row.source_id)
      .map((row) => String(row.source_id))
  ));
  const [poDetails, schedulePoEnricher] = poIds.length
    ? await Promise.all([
      query(
        `SELECT po.netsuite_id,
                po.tranid,
                po.dispatch_ref,
                po.vendor_id,
                po.vendor,
                po.memo,
                po.vendor_address,
                po.dispatch_vendor_yard,
                vendor_map.local_vendor
           FROM purchase_orders po
           LEFT JOIN dispatch_vendor_mappings vendor_map
             ON vendor_map.active = true
            AND COALESCE(vendor_map.local_vendor, '') <> ''
            AND (
              (COALESCE(po.vendor_id::text, '') <> '' AND vendor_map.netsuite_vendor_id::text = po.vendor_id::text)
              OR lower(vendor_map.netsuite_vendor_name) = lower(po.vendor)
            )
              WHERE po.netsuite_id = ANY($1::bigint[])`,
        [poIds]
      ),
      createPurchaseOrderDispatchEnricher({ allowOllama: false })
    ])
    : [{ rows: [] }, null];
  const poById = new Map(poDetails.rows.map((row) => [String(row.netsuite_id), row]));
  const enrichmentCache = new Map();
  const enrichPoForSchedule = async (po) => {
    const key = [
      po.vendor_id || "",
      po.vendor || "",
      po.memo || "",
      po.tranid || po.dispatch_ref || "",
      po.vendor_address || ""
    ].join("|");
    if (!enrichmentCache.has(key)) {
      enrichmentCache.set(key, schedulePoEnricher(po, { mappedLocalVendor: po.local_vendor || "" }));
    }
    return enrichmentCache.get(key);
  };
  const useNetSuiteAddressValue = useNetSuiteAddressMappingValue();
  const rows = await Promise.all(result.rows.map(async (row) => {
    let pickupPoint = row.pickup_point || "";
    let brand = row.brand || "";
    if (row.order_kind === "PO") {
      const po = poById.get(String(row.source_id));
      if (po) {
        const localVendor = String(po.local_vendor || "").trim();
        if (localVendor && localVendor !== useNetSuiteAddressValue) {
          brand = localVendor;
        } else if (localVendor === useNetSuiteAddressValue) {
          brand = po.vendor || brand;
        }
        if (!row.schedule_pickup_point) {
          const enriched = await enrichPoForSchedule(po);
          pickupPoint = enriched.dispatch_vendor_yard || pickupPoint;
        }
      }
    }
    const remark = resolveScmScheduleRemark({
      orderKind: row.order_kind,
      remarkOverride: row.remark_override,
      netSuiteMemo: row.netsuite_memo
    });
    return {
      scheduleId: Number(row.schedule_id || 0),
      orderKind: row.order_kind,
      sourceTable: row.source_table,
      sourceId: row.source_id,
      sourceRef: row.source_ref,
      orderRef: row.order_ref,
      dispatchRef: row.dispatch_ref || "",
      party: row.party || "",
      displayRef: row.display_ref || row.order_ref,
      isSpecialOrder: row.is_special_order === true,
      isBlanket: row.is_blanket_po === true,
      method: row.method || "MBT",
      pickupPoint,
      dropoffPoint: row.dropoff_point || "",
      scheduleDropoffPoint: row.schedule_dropoff_point || "",
      brand,
      content: row.content || "",
      ...remark,
      totalPalletQty: Number(row.total_pallet_qty || 0),
      weightLbs: Number(row.weight_lbs || 0),
      packingSlipRef: row.packing_slip_ref || "",
      groupRef: row.group_ref || "",
      status: row.status || "Queued",
      calculatedStatus: row.calculated_status || row.status || "Queued",
      dispatchCompletionEvidenceType: row.dispatch_completion_evidence_type || "",
      dispatchPlanned: row.dispatch_planned === true,
      reconciliationBlocked: row.reconciliation_blocked === true,
      queuedDate: dateOnly(row.queued_at),
      etaDate: dateOnly(row.eta_date),
      etaTime: row.eta_time || "",
      driver: row.driver || "",
      sla: row.sla_days === null || row.sla_days === undefined ? "" : `${Number(row.sla_days)} day${Number(row.sla_days) === 1 ? "" : "s"}`,
      slaDays: row.sla_days === null || row.sla_days === undefined ? null : Number(row.sla_days),
      notes: row.notes || "",
      updatedAt: row.concurrency_updated_at || row.updated_at,
      updatedBy: row.updated_by || ""
    };
  }));
  return attachScmScheduleRouteOptions(rows);
}

async function updateScmScheduleEntryTransaction({
  orderKind = "PO",
  orderRef = "",
  patch = {},
  updatedBy = "",
  expectedUpdatedAt = undefined,
  expectedSplitRevision = undefined
} = {}) {
  const kind = normalizeScmOrderKind(orderKind);
  const ref = String(orderRef || "").trim();
  if (!ref) throw new Error("SCM order ref is required.");
  const revisionSupplied = expectedUpdatedAt !== undefined;
  const expectedRevision = expectedUpdatedAt === null || expectedUpdatedAt === ""
    ? null
    : expectedUpdatedAt;
  const parsedRevision = expectedRevision === null ? null : new Date(expectedRevision);
  if (revisionSupplied && parsedRevision && Number.isNaN(parsedRevision.getTime())) {
    throw Object.assign(new Error("This schedule row changed after it was opened. Refresh and try again."), {
      status: 409,
      code: "SCM_SCHEDULE_STALE"
    });
  }
  const exactRevision = typeof expectedRevision === "string"
    && /\.\d{4,}(?:Z|[+-]\d{2}:?\d{2})$/i.test(expectedRevision);
  const existing = await query(
    `SELECT *
       FROM scm_transport_schedule
      WHERE order_kind = $1 AND lower(order_ref) = lower($2)
      LIMIT 1`,
    [kind, ref]
  );
  const current = existing.rows[0] || {};
  const has = (camel, snake = camel) => Object.prototype.hasOwnProperty.call(patch, camel)
    || Object.prototype.hasOwnProperty.call(patch, snake);
  const remarkOnly = isRemarkOnlyScmSchedulePatch(patch);
  if (kind === "PO") {
    const splitResult = await query(
      `SELECT *
         FROM dispatch_scm_po_splits
        WHERE status = 'active' AND lower(split_po_ref) = lower($1)
        LIMIT 1
        FOR UPDATE`,
      [ref]
    );
    if (splitResult.rows[0] && !remarkOnly) {
      await assertScmPurchaseOrderSplitMutable(query, splitResult.rows[0], {
        action: "change the schedule of",
        expectedRevision: expectedSplitRevision
      });
    }
  }
  const pickText = (camel, snake = camel, fallback = "") => {
    if (!has(camel, snake)) return fallback;
    return String(patch[camel] ?? patch[snake] ?? "").trim();
  };
  const next = {
    displayRef: pickText("displayRef", "display_ref", current.display_ref || ""),
    isSpecialOrder: has("isSpecialOrder", "is_special_order")
      ? patch.isSpecialOrder === true || patch.is_special_order === true
      : current.is_special_order === true,
    method: has("method") ? normalizeScmMethod(patch.method) : current.method || "MBT",
    pickupPoint: pickText("pickupPoint", "pickup_point", current.pickup_point || ""),
    dropoffPoint: pickText("dropoffPoint", "dropoff_point", current.dropoff_point || ""),
    brand: pickText("brand", "brand", current.brand || ""),
    content: pickText("content", "content", current.content || ""),
    weightLbs: has("weightLbs", "weight_lbs") ? positiveQuantity(patch.weightLbs ?? patch.weight_lbs) : positiveQuantity(current.weight_lbs),
    packingSlipRef: pickText("packingSlipRef", "packing_slip_ref", current.packing_slip_ref || ""),
    groupRef: pickText("groupRef", "group_ref", current.group_ref || ""),
    status: has("status") ? normalizeManualScmStatus(patch.status) : current.status || "Queued",
    etaDate: pickText("etaDate", "eta_date", dateOnly(current.eta_date)),
    etaTime: pickText("etaTime", "eta_time", current.eta_time || ""),
    driver: pickText("driver", "driver", current.driver || ""),
    sla: pickText("sla", "sla", current.sla || ""),
    notes: pickText("notes", "notes", current.notes || ""),
    remarkOverride: has("remarkOverride", "remark_override")
      ? normalizeScmScheduleRemarkOverride(patch.remarkOverride ?? patch.remark_override)
      : normalizeScmScheduleRemarkOverride(current.remark_override)
  };
  if (kind === "PO" && has("pickupPoint", "pickup_point") && next.pickupPoint) {
    const [route] = await attachScmScheduleRouteOptions([{
      orderKind: "PO",
      orderRef: ref,
      sourceRef: ref,
      groupRef: current.group_ref || (ref.toUpperCase().startsWith("PGOB-") ? ref : "")
    }]);
    const selected = (route?.pickupOptions || []).find((yard) =>
      String(yard || "").trim().toLowerCase() === next.pickupPoint.toLowerCase());
    if (!selected) {
      const unchanged = await isUnchangedScmPurchaseOrderPickup({
        ref,
        requestedPickup: next.pickupPoint,
        currentPickup: current.pickup_point,
        groupRef: route?.groupRef
      });
      if (!unchanged) {
        throw Object.assign(new Error(`Pickup yard ${next.pickupPoint} is not available for this PO vendor${route?.groupRef ? " group" : ""}.`), {
          status: 400,
          code: "SCM_PO_PICKUP_YARD_INVALID"
        });
      }
      next.pickupPoint = String(current.pickup_point || "").trim();
    } else {
      next.pickupPoint = selected;
    }
  }
  if (kind === "PO" && next.dropoffPoint) {
    const destinationLocationId = normalizeScmDestinationLocationId(next.dropoffPoint);
    if (!destinationLocationId) {
      throw Object.assign(new Error("Select a supported MBBS destination yard or use the NetSuite line destinations."), {
        status: 400,
        code: "SCM_PO_DESTINATION_INVALID"
      });
    }
    next.dropoffPoint = locationTextFromId(destinationLocationId);
  }
  if (kind === "TO") {
    for (const [field, value] of [["pickupPoint", next.pickupPoint], ["dropoffPoint", next.dropoffPoint]]) {
      if (!has(field, field === "pickupPoint" ? "pickup_point" : "dropoff_point") || !value) continue;
      const locationId = normalizeScmDestinationLocationId(value);
      if (!locationId) {
        throw Object.assign(new Error("Transfer Order pickup and drop-off must be supported MBBS yards."), {
          status: 400,
          code: "SCM_TO_YARD_INVALID"
        });
      }
      next[field] = locationTextFromId(locationId);
    }
  }
  if (kind === "VRMA") {
    const routeResult = await query(
      `SELECT v.pickup_location, v.dropoff_location, COALESCE(v.local_vendor, v.vendor, '') AS local_vendor
         FROM scm_vrma_orders v
         JOIN dispatch_local_vendors lv
           ON lv.active = true
          AND LOWER(lv.name) = LOWER(COALESCE(v.local_vendor, v.vendor, ''))
         JOIN dispatch_vendor_yards y
           ON y.active = true
          AND LOWER(y.vendor) = LOWER(lv.name)
          AND LOWER(y.yard) = LOWER(v.dropoff_location)
        WHERE LOWER(v.vrma_ref) = LOWER($1)
          AND v.pickup_location IN ('3445', '2967', '12441', '150')
        LIMIT 1`,
      [ref]
    );
    const route = routeResult.rows[0];
    if (!route) throw new Error("VRMA route must be one of our yards to an active local vendor yard.");
    next.method = "MBT";
    next.pickupPoint = route.pickup_location;
    next.dropoffPoint = route.dropoff_location;
    next.brand = route.local_vendor;
  }
  const result = await query(
    `INSERT INTO scm_transport_schedule (
       order_kind, order_ref, display_ref, is_special_order, method,
       pickup_point, dropoff_point, brand, content, weight_lbs,
       packing_slip_ref, group_ref, status, eta_date, eta_time,
       driver, sla, notes, remark_override, updated_by, created_by
     )
     VALUES (
       $1, $2, NULLIF($3, ''), $4, $5,
       NULLIF($6, ''), NULLIF($7, ''), NULLIF($8, ''), NULLIF($9, ''), COALESCE($10::numeric, 0),
       NULLIF($11, ''), NULLIF($12, ''), $13, $14::date, NULLIF($15, ''),
       NULLIF($16, ''), NULLIF($17, ''), NULLIF($18, ''), NULLIF($19, ''), $20, $20
     )
     ON CONFLICT (order_kind, order_ref) DO UPDATE SET
       display_ref = EXCLUDED.display_ref,
       is_special_order = EXCLUDED.is_special_order,
       method = EXCLUDED.method,
       pickup_point = EXCLUDED.pickup_point,
       dropoff_point = EXCLUDED.dropoff_point,
       brand = EXCLUDED.brand,
       content = EXCLUDED.content,
       weight_lbs = EXCLUDED.weight_lbs,
       packing_slip_ref = EXCLUDED.packing_slip_ref,
       group_ref = EXCLUDED.group_ref,
       status = EXCLUDED.status,
       eta_date = EXCLUDED.eta_date,
       eta_time = EXCLUDED.eta_time,
       driver = EXCLUDED.driver,
       sla = EXCLUDED.sla,
       notes = EXCLUDED.notes,
       remark_override = EXCLUDED.remark_override,
       updated_by = EXCLUDED.updated_by,
       updated_at = GREATEST(clock_timestamp(), scm_transport_schedule.updated_at + interval '1 microsecond')
     WHERE NOT $21::boolean
        OR (
          $22::timestamptz IS NOT NULL
          AND (
            ($23::boolean AND scm_transport_schedule.updated_at = $22::timestamptz)
            OR (
              NOT $23::boolean
              AND date_trunc('milliseconds', scm_transport_schedule.updated_at)
                = date_trunc('milliseconds', $22::timestamptz)
            )
          )
        )
     RETURNING *`,
    [
      kind,
      ref,
      next.displayRef,
      next.isSpecialOrder,
      next.method,
      next.pickupPoint,
      next.dropoffPoint,
      next.brand,
      next.content,
      next.weightLbs,
      next.packingSlipRef,
      next.groupRef,
      next.status,
      next.etaDate || null,
      next.etaTime,
      next.driver,
      next.sla,
      next.notes,
      next.remarkOverride,
      updatedBy || null,
      revisionSupplied,
      expectedRevision,
      exactRevision
    ]
  );
  if (!result.rowCount) {
    throw Object.assign(new Error("This schedule row changed after it was opened. Refresh and try again."), {
      status: 409,
      code: "SCM_SCHEDULE_STALE"
    });
  }
  if (kind === "PO" && has("packingSlipRef", "packing_slip_ref")) {
    const refUpdate = await updatePurchaseOrderDispatchRef({
      poRef: ref,
      newRef: next.packingSlipRef,
      updatedBy
    });
    const committed = await query(
      `SELECT *
         FROM scm_transport_schedule
        WHERE order_kind = 'PO' AND lower(order_ref) = lower($1)
        LIMIT 1`,
      [refUpdate.displayRef || ref]
    );
    return committed.rows[0] || result.rows[0];
  }
  return result.rows[0];
}

export async function updateScmScheduleEntry(values = {}) {
  // The split guard, schedule revision check, row write, PO reference update,
  // and snapshot rewrite must commit as one unit. Holding the split row lock
  // here serializes a schedule save against simultaneous split edits/planning.
  return withTransaction(() => updateScmScheduleEntryTransaction(values));
}

function buildScmGroupRef(refs = []) {
  const cleaned = [...new Set((refs || []).map((ref) => String(ref || "").trim()).filter(Boolean))];
  if (cleaned.length < 2) throw new Error("Select at least two refs to group.");
  return `PGOB-${cleaned.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" })).join("-")}`;
}

export async function createScmScheduleGroup({ refs = [], createdBy = "" } = {}) {
  const groupRef = buildScmGroupRef(refs);
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const members = [];
    for (const ref of refs) {
      const row = await client.query(
        `SELECT po.*,
                s.pickup_point AS schedule_pickup_point,
                s.dropoff_point AS schedule_dropoff_point,
                s.status AS schedule_status
           FROM purchase_orders po
           LEFT JOIN scm_transport_schedule s
             ON s.order_kind = 'PO'
            AND lower(s.order_ref) = lower(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid))
          WHERE lower(po.tranid) = lower($1)
             OR lower(COALESCE(po.dispatch_ref, '')) = lower($1)
          ORDER BY CASE WHEN lower(COALESCE(po.dispatch_ref, '')) = lower($1) THEN 0 ELSE 1 END,
                   po.netsuite_active DESC,
                   po.synced_at DESC NULLS LAST
          LIMIT 1`,
        [ref]
      );
      const po = row.rows[0];
      if (!po) throw new Error(`SCM PO ${ref} was not found.`);
      if (!po.netsuite_active) throw new Error(`${ref} is inactive and cannot be grouped.`);
      if (String(po.tranid || "").toLowerCase().startsWith("pgob-")) throw new Error(`${ref} is already a grouped PO.`);
      const existingGroup = await client.query(
        `SELECT group_ref
           FROM scm_transport_schedule
          WHERE order_kind = 'PO'
            AND lower(order_ref) = lower(COALESCE(NULLIF($1, ''), $2))
            AND COALESCE(group_ref, '') <> ''
          LIMIT 1`,
        [po.dispatch_ref || "", po.tranid]
      );
      if (existingGroup.rows[0]?.group_ref && existingGroup.rows[0].group_ref !== groupRef) {
        throw new Error(`${ref} is already grouped under ${existingGroup.rows[0].group_ref}.`);
      }
      const enriched = await enrichPurchaseOrderDispatch(po);
      const schedulePickupPoint = String(po.schedule_pickup_point || "").trim();
      const scheduleDropoffPoint = String(po.schedule_dropoff_point || "").trim();
      const schedulePickupYard = schedulePickupPoint
        ? await client.query(
          `SELECT yard, address, window_start, window_end, instructions, day_label
             FROM dispatch_vendor_yards
            WHERE active = true
              AND lower(yard) = lower($1)
            ORDER BY CASE WHEN day_label = 'Mon-Fri' THEN 0 ELSE 1 END, id
            LIMIT 1`,
          [schedulePickupPoint]
        )
        : { rows: [] };
      const pickupYard = schedulePickupYard.rows[0] || {};
      members.push({
        ...po,
        order_ref: po.dispatch_ref || po.tranid,
        scm_status: String(po.schedule_status || po.initial_scm_status || "Queued").trim() || "Queued",
        pickup_point: schedulePickupPoint || enriched.dispatch_vendor_yard || po.dispatch_vendor_yard || po.source_location || po.vendor || "",
        dropoff_point: scheduleDropoffPoint || po.destination_location || "",
        dropoff_location_id: normalizeScmDestinationLocationId(scheduleDropoffPoint) || po.destination_location_id || null,
        pickup_address: pickupYard.address || enriched.dispatch_address || po.dispatch_address || "",
        pickup_window_start: pickupYard.window_start || enriched.dispatch_window_start || po.dispatch_window_start || "",
        pickup_window_end: pickupYard.window_end || enriched.dispatch_window_end || po.dispatch_window_end || "",
        pickup_instructions: pickupYard.yard
          ? `${pickupYard.day_label || ""}${pickupYard.instructions ? ` | ${pickupYard.instructions}` : ""}`.trim()
          : enriched.dispatch_instructions || po.dispatch_instructions || ""
      });
    }
    const statusKeys = [...new Set(members.map((member) => String(member.scm_status || "Queued").trim().toLowerCase()))];
    if (statusKeys.length !== 1) {
      throw Object.assign(
        new Error(`Cannot group orders with different SCM statuses: ${members.map((member) => `${member.order_ref}=${member.scm_status || "Queued"}`).join(", ")}`),
        { status: 400, code: "SCM_GROUP_STATUS_MISMATCH" }
      );
    }
    const pickupKeys = [...new Set(members.map((member) => String(member.pickup_point || "").trim().toLowerCase()).filter(Boolean))];
    if (pickupKeys.length !== 1) {
      throw new Error(`Cannot group orders with different pickup points: ${members.map((member) => `${member.order_ref}=${member.pickup_point || "blank"}`).join(", ")}`);
    }
    const pickupPoint = members[0]?.pickup_point || "";
    const pickupAddress = members[0]?.pickup_address || "";
    const pickupWindowStart = members[0]?.pickup_window_start || "";
    const pickupWindowEnd = members[0]?.pickup_window_end || "";
    const pickupInstructions = members[0]?.pickup_instructions || "";
    const memberRefs = members.map((member) => member.order_ref);
    const destinationNames = [...new Set(members.map((member) => member.dropoff_point || "").filter(Boolean))];
    const destinationIds = [...new Set(members.map((member) => String(member.dropoff_location_id || "")).filter(Boolean))];
    const groupOrderId = syntheticPurchaseOrderId(`scm-schedule-group:${groupRef}`);
    const group = await client.query(
      `INSERT INTO scm_schedule_groups (group_ref, created_by, details)
       VALUES ($1, $2, '{}'::jsonb)
       ON CONFLICT (group_ref) DO UPDATE SET status = 'active', cancelled_at = NULL, details = EXCLUDED.details
       RETURNING *`,
      [groupRef, createdBy || null]
    );
    const groupId = group.rows[0].id;
    await client.query(
      `UPDATE scm_schedule_groups
          SET details = $2::jsonb
        WHERE id = $1`,
      [
        groupId,
        JSON.stringify({
          memberRefs,
          pickupPoint,
          dropoffPoints: destinationNames,
          syntheticPurchaseOrderId: groupOrderId
        })
      ]
    );
    await client.query(
      `INSERT INTO purchase_orders (
         netsuite_id, tranid, trandate, vendor_id, vendor, status, status_text, foreign_total,
         destination_location_id, destination_location, memo, dispatch_vendor_yard, dispatch_address,
         dispatch_window_start, dispatch_window_end, dispatch_instructions, receipt_status,
         netsuite_active, synced_at, source_location_id, source_location, expected_delivery_date,
         dispatch_parse_source, dispatch_note_hash, dispatch_parsed_at, netsuite_missing_at,
         last_item_receipt_id, last_item_receipt_tranid, received_at, status_updated_at,
         dispatch_ref, dispatch_ref_updated_at, dispatch_ref_updated_by, vendor_address
       ) VALUES (
         $1, $2, CURRENT_DATE, NULL, $3, 'B', 'Purchase Order : Pending Receipt', 0,
         $4::bigint, $5, $6, $7, $8,
         $9, $10, $11, 'pending',
         true, now(), NULL, $7, NULL,
         'scm-schedule-group', $12, now(), NULL,
         NULL, NULL, NULL, now(),
         $2, now(), $13, NULL
       )
       ON CONFLICT (netsuite_id) DO UPDATE SET
         tranid = EXCLUDED.tranid,
         vendor = EXCLUDED.vendor,
         status_text = EXCLUDED.status_text,
         destination_location_id = EXCLUDED.destination_location_id,
         destination_location = EXCLUDED.destination_location,
         memo = EXCLUDED.memo,
         dispatch_vendor_yard = EXCLUDED.dispatch_vendor_yard,
         dispatch_address = EXCLUDED.dispatch_address,
         dispatch_window_start = EXCLUDED.dispatch_window_start,
         dispatch_window_end = EXCLUDED.dispatch_window_end,
         dispatch_instructions = EXCLUDED.dispatch_instructions,
         netsuite_active = true,
         synced_at = now(),
         source_location = EXCLUDED.source_location,
         dispatch_parse_source = EXCLUDED.dispatch_parse_source,
         dispatch_note_hash = EXCLUDED.dispatch_note_hash,
         dispatch_parsed_at = now(),
         status_updated_at = now(),
         dispatch_ref = EXCLUDED.dispatch_ref,
         dispatch_ref_updated_at = now(),
         dispatch_ref_updated_by = EXCLUDED.dispatch_ref_updated_by`,
      [
        groupOrderId,
        groupRef,
        pickupPoint || "SCM Group",
        destinationIds.length === 1 ? Number(destinationIds[0]) : null,
        destinationNames.join(" + "),
        `SCM grouped PO: ${memberRefs.join(", ")}`,
        pickupPoint,
        pickupAddress,
        pickupWindowStart,
        pickupWindowEnd,
        pickupInstructions,
        repositoryHashText(`${groupRef}|${memberRefs.join("|")}|${pickupPoint}`),
        createdBy || null
      ]
    );
    await client.query(
      `UPDATE purchase_order_lines
          SET netsuite_active = false,
              synced_at = now()
        WHERE purchase_order_id = $1`,
      [groupOrderId]
    );
    const lineRows = await client.query(
      `SELECT l.*, po.tranid, COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid) AS source_ref
         FROM purchase_order_lines l
         JOIN purchase_orders po ON po.netsuite_id = l.purchase_order_id
        WHERE po.netsuite_id = ANY($1::bigint[])
          AND l.netsuite_active = true
          AND GREATEST(COALESCE(l.quantity, 0) - COALESCE(l.netsuite_received_baseline_qty, l.netsuite_received_qty, 0), 0) > 0`,
      [members.map((member) => member.netsuite_id)]
    );
    for (const line of lineRows.rows) {
      const groupLineId = syntheticPurchaseOrderId(`scm-schedule-group-line:${groupRef}:${line.purchase_order_id}:${line.id}`);
      await client.query(
        `INSERT INTO purchase_order_lines (
           id, purchase_order_id, line_id, item_id, item_name, sku, item_description, item_type,
           item_type_text, quantity, unit, location_id, location, pallet_qty, layer_qty,
           section_qty, piece_qty, to_plt, to_lyr, to_sec, to_pcs, received_pallet_qty,
           received_layer_qty, received_section_qty, received_piece_qty, netsuite_received_qty,
           netsuite_active, sync_exception, synced_at, item_weight, sync_exception_at, raw,
           confirmed_at, confirmed_by
         ) VALUES (
           $1, $2, $3, $4, $5, $6, $7, $8,
           $9, $10, $11, $12, $13, $14, $15,
           $16, $17, $18, $19, $20, $21, 0,
           0, 0, 0, 0,
           true, null, now(), $22, null, $23::jsonb,
           null, null
         )
         ON CONFLICT (id) DO UPDATE SET
           quantity = EXCLUDED.quantity,
           pallet_qty = EXCLUDED.pallet_qty,
           layer_qty = EXCLUDED.layer_qty,
           section_qty = EXCLUDED.section_qty,
           piece_qty = EXCLUDED.piece_qty,
           netsuite_active = true,
           synced_at = now(),
           raw = EXCLUDED.raw`,
        [
          groupLineId,
          groupOrderId,
          line.line_id,
          line.item_id,
          line.item_name,
          line.sku,
          line.item_description,
          line.item_type,
          line.item_type_text,
          Math.max(positiveQuantity(line.quantity) - purchaseOrderReceivedBaseline(line), 0),
          line.unit,
          line.location_id,
          line.location,
          Math.max(positiveQuantity(line.pallet_qty) - positiveQuantity(line.received_pallet_qty), 0),
          Math.max(positiveQuantity(line.layer_qty) - positiveQuantity(line.received_layer_qty), 0),
          Math.max(positiveQuantity(line.section_qty) - positiveQuantity(line.received_section_qty), 0),
          Math.max(positiveQuantity(line.piece_qty) - positiveQuantity(line.received_piece_qty), 0),
          line.to_plt,
          line.to_lyr,
          line.to_sec,
          line.to_pcs,
          line.item_weight,
          JSON.stringify({
            scmGroup: true,
            groupRef,
            sourcePoRef: line.source_ref,
            sourcePoId: line.purchase_order_id,
            sourceLineId: line.id
          })
        ]
      );
    }
    await client.query(
      `INSERT INTO scm_transport_schedule (
         order_kind, order_ref, display_ref, method, pickup_point, dropoff_point,
         brand, packing_slip_ref, group_ref, status, content, weight_lbs, updated_by, created_by
       ) VALUES (
         'PO', $1, $1, 'MBT', $2, $3,
         $4, $1, $1, 'Queued', $5, $6, $7, $7
       )
       ON CONFLICT (order_kind, order_ref) DO UPDATE SET
         display_ref = EXCLUDED.display_ref,
         method = EXCLUDED.method,
         pickup_point = EXCLUDED.pickup_point,
         dropoff_point = EXCLUDED.dropoff_point,
         brand = EXCLUDED.brand,
         packing_slip_ref = EXCLUDED.packing_slip_ref,
         group_ref = EXCLUDED.group_ref,
         status = CASE
           WHEN scm_transport_schedule.reconciliation_blocked = true THEN 'Reconcile Review'
           WHEN scm_transport_schedule.status IN (
             'Completed', 'Cancelled', 'Hold', 'In Transit',
             'Partially Done', 'Reconcile Review'
           ) THEN scm_transport_schedule.status
           ELSE EXCLUDED.status
         END,
         content = EXCLUDED.content,
         weight_lbs = EXCLUDED.weight_lbs,
         updated_by = EXCLUDED.updated_by,
         updated_at = now()`,
      [
        groupRef,
        pickupPoint,
        destinationNames.join(" + "),
        pickupPoint || "SCM Group",
        "",
        lineRows.rows.reduce((sum, line) => sum + (Math.max(positiveQuantity(line.quantity) - purchaseOrderReceivedBaseline(line), 0) * positiveQuantity(line.item_weight)), 0),
        createdBy || null
      ]
    );
    for (const found of members.map((member) => ({ order_kind: "PO", order_ref: member.order_ref }))) {
      await client.query(
        `INSERT INTO scm_transport_schedule (order_kind, order_ref, group_ref, updated_by, created_by)
         VALUES ($1, $2, $3, $4, $4)
         ON CONFLICT (order_kind, order_ref) DO UPDATE SET group_ref = EXCLUDED.group_ref, updated_by = EXCLUDED.updated_by, updated_at = now()
         RETURNING id`,
        [found.order_kind, found.order_ref, groupRef, createdBy || null]
      );
      await client.query(
        `INSERT INTO scm_schedule_group_members (group_id, order_kind, order_ref)
         VALUES ($1, $2, $3)
         ON CONFLICT DO NOTHING`,
        [groupId, found.order_kind, found.order_ref]
      );
    }
    await client.query("COMMIT");
    return { groupRef, count: refs.length, syntheticPurchaseOrderId: groupOrderId, pickupPoint, memberRefs };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => null);
    throw error;
  } finally {
    client.release();
  }
}

export async function cancelScmScheduleGroup({ groupRef = "", cancelledBy = "" } = {}) {
  const ref = String(groupRef || "").trim();
  if (!ref) throw new Error("Group ref is required.");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const groupResult = await client.query(
      `SELECT *
         FROM scm_schedule_groups
        WHERE lower(group_ref) = lower($1)
        LIMIT 1`,
      [ref]
    );
    const group = groupResult.rows[0];
    const syntheticPurchaseOrderId = group?.details?.syntheticPurchaseOrderId || syntheticPurchaseOrderIdForGroup(ref);
    await client.query(
      `UPDATE scm_schedule_groups
          SET status = 'cancelled', cancelled_at = now()
        WHERE lower(group_ref) = lower($1)`,
      [ref]
    );
    await client.query(
      `UPDATE scm_transport_schedule
          SET group_ref = NULL, updated_by = $2, updated_at = now()
        WHERE lower(group_ref) = lower($1)`,
      [ref, cancelledBy || null]
    );
    await client.query(
      `UPDATE purchase_order_lines
          SET netsuite_active = false,
              synced_at = now()
        WHERE purchase_order_id = $1`,
      [syntheticPurchaseOrderId]
    );
    await client.query(
      `UPDATE purchase_orders
          SET netsuite_active = false,
              status_text = COALESCE(status_text, '') || ' (SCM group cancelled)',
              status_updated_at = now(),
              synced_at = now()
        WHERE netsuite_id = $1 OR lower(tranid) = lower($2)`,
      [syntheticPurchaseOrderId, ref]
    );
    await client.query("COMMIT");
    return { groupRef: ref };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => null);
    throw error;
  } finally {
    client.release();
  }
}

export async function listScmViewPresets() {
  const result = await query(
    `SELECT id, name, description, config, active, updated_at
       FROM scm_view_presets
      WHERE active = true
      ORDER BY name`
  );
  return result.rows.map((row) => ({
    id: row.id,
    name: row.name,
    description: row.description || "",
    config: row.config || {},
    active: row.active,
    updatedAt: row.updated_at
  }));
}

export async function upsertScmViewPreset({ id = null, name = "", description = "", config = {}, updatedBy = "" } = {}) {
  const cleanName = String(name || "").trim();
  if (!cleanName) throw new Error("View name is required.");
  const result = await query(
    `INSERT INTO scm_view_presets (id, name, description, config, updated_by, created_by)
     VALUES (COALESCE($1::bigint, nextval('scm_view_presets_id_seq')), $2, $3, $4::jsonb, $5, $5)
     ON CONFLICT (id) DO UPDATE SET
       name = EXCLUDED.name,
       description = EXCLUDED.description,
       config = EXCLUDED.config,
       updated_by = EXCLUDED.updated_by,
       updated_at = now()
     RETURNING id, name, description, config, active, updated_at`,
    [id, cleanName, String(description || "").trim(), JSON.stringify(config || {}), updatedBy || null]
  );
  return result.rows[0];
}

export async function getScmVrmaOptions() {
  const result = await query(
    `SELECT y.id, y.vendor, y.yard, y.address, y.day_label, y.window_start, y.window_end, y.instructions
       FROM dispatch_local_vendors v
       JOIN dispatch_vendor_yards y ON LOWER(y.vendor) = LOWER(v.name)
      WHERE v.active = true
        AND y.active = true
      ORDER BY v.name, y.yard, y.day_label, y.id`
  );
  const byVendor = new Map();
  for (const row of result.rows) {
    const name = String(row.vendor || "").trim();
    if (!name) continue;
    if (!byVendor.has(name)) byVendor.set(name, { name, yards: [] });
    const vendor = byVendor.get(name);
    if (vendor.yards.some((yard) => yard.name.toLowerCase() === String(row.yard || "").trim().toLowerCase())) continue;
    vendor.yards.push({
      id: row.id,
      name: row.yard || "",
      address: row.address || "",
      dayLabel: row.day_label || "",
      windowStart: row.window_start || "",
      windowEnd: row.window_end || "",
      instructions: row.instructions || ""
    });
  }
  return {
    ownYards: SCM_VRMA_OWN_YARDS.map((yard) => ({ ...yard })),
    localVendors: [...byVendor.values()]
  };
}

export async function searchScmVrmaItems({ search = "", limit = 20 } = {}) {
  const term = String(search || "").trim();
  if (term.length < 2) return [];
  const result = await query(
    `SELECT item_id, item_name, display_name, item_description, stock_unit, item_weight,
            to_plt, to_lyr, to_sec, to_pcs
       FROM inventory_items
      WHERE item_name ILIKE $1
         OR COALESCE(display_name, '') ILIKE $1
         OR COALESCE(item_description, '') ILIKE $1
      ORDER BY
        CASE WHEN LOWER(item_name) = LOWER($2) THEN 0
             WHEN LOWER(item_name) LIKE LOWER($2) || '%' THEN 1
             ELSE 2 END,
        item_name
      LIMIT $3`,
    [`%${term}%`, term, Math.min(Math.max(Number(limit) || 20, 1), 40)]
  );
  return result.rows.map((row) => ({
    itemId: row.item_id,
    sku: row.item_name || "",
    itemName: row.display_name || row.item_name || "",
    description: row.item_description || "",
    stockUnit: row.stock_unit || "",
    itemWeight: positiveQuantity(row.item_weight),
    toPlt: positiveQuantity(row.to_plt),
    toLyr: positiveQuantity(row.to_lyr),
    toSec: positiveQuantity(row.to_sec),
    toPcs: positiveQuantity(row.to_pcs)
  }));
}

export async function getScmVrmaOrder(vrmaRef = "") {
  const ref = String(vrmaRef || "").trim();
  if (!ref) return null;
  const headerResult = await query(
    `SELECT v.id, v.vrma_ref, v.vendor, v.local_vendor, v.pickup_location, v.dropoff_location,
            v.status, v.method, v.notes, v.operator_status, v.local_yard_order_status,
            v.loaded_at, v.completed_at, v.completed_by, v.completion_note,
            v.completion_source, v.cancelled_at, v.cancelled_by, v.cancellation_note,
            v.cancellation_source, v.created_at, v.updated_at,
            schedule.updated_at AS schedule_updated_at,
            GREATEST(v.updated_at, schedule.updated_at) AS concurrency_updated_at
       FROM scm_vrma_orders v
       LEFT JOIN scm_transport_schedule schedule
         ON schedule.order_kind = 'VRMA'
        AND LOWER(schedule.order_ref) = LOWER(v.vrma_ref)
      WHERE LOWER(v.vrma_ref) = LOWER($1)
      LIMIT 1`,
    [ref]
  );
  const header = headerResult.rows[0];
  if (!header) return null;
  const lineResult = await query(
    `SELECT l.id, l.item_id, l.sku, l.item_name, l.item_description, l.quantity, l.unit,
            l.weight_lbs, l.pallet_qty, l.layer_qty, l.section_qty, l.piece_qty,
            l.to_plt, l.to_lyr, l.to_sec, l.to_pcs,
            i.stock_unit, i.item_weight
       FROM scm_vrma_order_lines l
       LEFT JOIN inventory_items i ON i.item_id = l.item_id
      WHERE l.vrma_order_id = $1
      ORDER BY l.id`,
    [header.id]
  );
  return {
    id: header.id,
    vrmaRef: header.vrma_ref,
    vendor: header.vendor || "",
    localVendor: header.local_vendor || header.vendor || "",
    pickupLocation: header.pickup_location || "",
    dropoffLocation: header.dropoff_location || "",
    status: header.status || "Queued",
    method: header.method || "MBT",
    notes: header.notes || "",
    operatorStatus: header.operator_status || "open",
    localYardOrderStatus: header.local_yard_order_status || "Open",
    loadedAt: header.loaded_at || null,
    completedAt: header.completed_at || null,
    completedBy: header.completed_by || "",
    completionNote: header.completion_note || "",
    completionSource: header.completion_source || "",
    cancelledAt: header.cancelled_at || null,
    cancelledBy: header.cancelled_by || "",
    cancellationNote: header.cancellation_note || "",
    cancellationSource: header.cancellation_source || "",
    createdAt: header.created_at,
    updatedAt: header.updated_at,
    scheduleUpdatedAt: header.schedule_updated_at || null,
    concurrencyUpdatedAt: header.concurrency_updated_at || header.updated_at,
    lines: lineResult.rows.map((line) => ({
      id: line.id,
      itemId: line.item_id,
      sku: line.sku || "",
      itemName: line.item_name || line.sku || "",
      description: line.item_description || "",
      quantity: positiveQuantity(line.quantity),
      unit: line.unit || "",
      weightLbs: positiveQuantity(line.weight_lbs),
      palletQty: positiveQuantity(line.pallet_qty),
      layerQty: positiveQuantity(line.layer_qty),
      sectionQty: positiveQuantity(line.section_qty),
      pieceQty: positiveQuantity(line.piece_qty),
      toPlt: positiveQuantity(line.to_plt),
      toLyr: positiveQuantity(line.to_lyr),
      toSec: positiveQuantity(line.to_sec),
      toPcs: positiveQuantity(line.to_pcs),
      stockUnit: line.stock_unit || line.unit || "",
      itemWeight: positiveQuantity(line.item_weight)
    }))
  };
}

export async function removeScmVrmaOrder({
  vrmaRef = "",
  note = "",
  actor = "",
  expectedUpdatedAt = "",
  confirm = false
} = {}) {
  const ref = String(vrmaRef || "").trim();
  const cleanNote = String(note || "").trim();
  const cleanActor = String(actor || "").trim();
  const expected = expectedUpdatedAt ? new Date(expectedUpdatedAt) : null;
  if (!ref) throw Object.assign(new Error("VRMA ref is required."), { status: 400 });
  if (!cleanActor) throw Object.assign(new Error("SCM or Admin identity is required."), { status: 401 });
  if (!cleanNote) throw Object.assign(new Error("An audit note is required to remove a VRMA."), { status: 400 });
  if (confirm !== true) {
    throw Object.assign(new Error("Confirm that this local VRMA should be removed."), { status: 400 });
  }
  if (!expected || Number.isNaN(expected.getTime())) {
    throw Object.assign(new Error("Refresh this VRMA before removing it."), {
      status: 409,
      code: "SCM_VRMA_REMOVE_STALE"
    });
  }

  return withTransaction(async () => {
    const selected = await query(
      `SELECT *
         FROM scm_vrma_orders
        WHERE LOWER(vrma_ref) = LOWER($1)
        LIMIT 1
        FOR UPDATE`,
      [ref]
    );
    const header = selected.rows[0];
    if (!header) throw Object.assign(new Error("VRMA order not found."), { status: 404 });

    const scheduleResult = await query(
      `SELECT *
         FROM scm_transport_schedule
        WHERE order_kind = 'VRMA'
          AND LOWER(order_ref) = LOWER($1)
        LIMIT 1
        FOR UPDATE`,
      [header.vrma_ref]
    );
    const schedule = scheduleResult.rows[0] || null;
    const before = { vrma: header, schedule };
    const activeCoResult = await query(
      `SELECT co_ref, status
         FROM local_co_orders
        WHERE lower(btrim(source_order_ref)) = lower(btrim($1))
          AND status <> 'cancelled'
        ORDER BY updated_at DESC, id DESC
        LIMIT 1
        FOR UPDATE`,
      [header.vrma_ref]
    );
    const activeCo = activeCoResult.rows[0] || null;
    const headerStatus = String(header.status || "").trim();
    const scheduleStatus = String(schedule?.status || "").trim();
    const normalizedHeaderStatus = headerStatus.toLowerCase();
    const normalizedScheduleStatus = scheduleStatus.toLowerCase();

    if (activeCo) {
      const message = `Cancel ${activeCo.co_ref} before removing this VRMA.`;
      throw Object.assign(new Error(message), {
        status: 409,
        code: "SCM_VRMA_REMOVE_BLOCKED",
        conflicts: [{ type: "active_co", message, coRef: activeCo.co_ref }]
      });
    }

    if (normalizedHeaderStatus === "cancelled" && (!schedule || normalizedScheduleStatus === "cancelled")) {
      return {
        removed: true,
        idempotent: true,
        before,
        after: before
      };
    }
    if (normalizedHeaderStatus === "completed" || normalizedScheduleStatus === "completed") {
      throw Object.assign(new Error("A Completed VRMA cannot be removed."), {
        status: 409,
        code: "SCM_VRMA_REMOVE_BLOCKED",
        conflicts: [{ type: "completed", message: "The VRMA is already Completed." }]
      });
    }

    const concurrencyTimestamp = [header.updated_at, schedule?.updated_at]
      .filter(Boolean)
      .reduce((latest, value) => (
        !latest || new Date(value).getTime() > new Date(latest).getTime() ? value : latest
      ), null);
    if (
      !concurrencyTimestamp
      || new Date(concurrencyTimestamp).getTime() !== expected.getTime()
    ) {
      throw Object.assign(new Error("This VRMA changed after it was opened. Refresh and try again."), {
        status: 409,
        code: "SCM_VRMA_REMOVE_STALE"
      });
    }

    const lineResult = await query(
      `SELECT *
         FROM scm_vrma_order_lines
        WHERE vrma_order_id = $1
        ORDER BY id
        FOR UPDATE`,
      [header.id]
    );
    const assignmentResult = await query(
      `SELECT assignment.*, plan.status AS plan_status
         FROM dispatch_vrma_plan_assignments assignment
         JOIN dispatch_plans plan ON plan.id = assignment.plan_id
        WHERE LOWER(assignment.order_ref) = LOWER($1)
        FOR UPDATE OF assignment, plan`,
      [header.vrma_ref]
    );
    const snapshotResult = await query(
      `SELECT snapshot.plan_id, plan.status AS plan_status
         FROM dispatch_plan_snapshots snapshot
         JOIN dispatch_plans plan ON plan.id = snapshot.plan_id
        WHERE (
          EXISTS (
            SELECT 1
              FROM jsonb_array_elements(COALESCE(snapshot.orders, '[]'::jsonb)) plan_order(value)
             WHERE LOWER(COALESCE(plan_order.value->>'id', '')) = LOWER($1)
               AND (
                 plan_order.value->>'sourceTable' = 'scm_vrma_orders'
                 OR UPPER(COALESCE(plan_order.value->>'type', '')) = 'VRMA'
               )
          )
          OR EXISTS (
            SELECT 1
              FROM jsonb_array_elements(COALESCE(snapshot.trucks, '[]'::jsonb)) truck(value)
              CROSS JOIN LATERAL jsonb_array_elements(COALESCE(truck.value->'loads', '[]'::jsonb)) load(value)
              CROSS JOIN LATERAL jsonb_array_elements(COALESCE(load.value->'stops', '[]'::jsonb)) stop(value)
             WHERE LOWER(COALESCE(stop.value->>'orderId', '')) = LOWER($1)
          )
        )
        FOR UPDATE OF snapshot, plan`,
      [header.vrma_ref]
    );
    const loadHistoryResult = await query(
      `SELECT id, load_type, order_family, order_id, order_ref, source_table, source_record_id, created_at
         FROM operator_load_records
        WHERE (
          order_family = 'vrma_order'
          AND (
            order_id = $1
            OR LOWER(COALESCE(order_ref, '')) = LOWER($2)
          )
        )
        OR (
          source_table = 'scm_vrma_orders'
          AND source_record_id = $1
        )
        FOR UPDATE`,
      [header.id, header.vrma_ref]
    );
    const groupResult = await query(
      `SELECT member.id, group_header.group_ref
         FROM scm_schedule_group_members member
         JOIN scm_schedule_groups group_header ON group_header.id = member.group_id
        WHERE LOWER(group_header.status) = 'active'
          AND LOWER(member.order_ref) = LOWER($1)
        FOR UPDATE OF member, group_header`,
      [header.vrma_ref]
    );

    const activeAssignments = assignmentResult.rows.filter(
      (row) => String(row.plan_status || "").trim().toLowerCase() !== "cancelled"
    );
    const activeSnapshots = snapshotResult.rows.filter(
      (row) => String(row.plan_status || "").trim().toLowerCase() !== "cancelled"
    );
    const hasHeaderActivity = String(header.operator_status || "open").trim().toLowerCase() !== "open"
      || Boolean(header.preparing_operator_id)
      || Boolean(header.preparing_started_at)
      || Boolean(header.loaded_at)
      || !["", "open"].includes(String(header.local_yard_order_status || "").trim().toLowerCase());
    const hasLineActivity = lineResult.rows.some((line) => (
      positiveQuantity(line.packed_pallet_qty) > 0
      || positiveQuantity(line.packed_layer_qty) > 0
      || positiveQuantity(line.packed_section_qty) > 0
      || positiveQuantity(line.packed_piece_qty) > 0
      || positiveQuantity(line.packed_sales_qty) > 0
      || positiveQuantity(line.loaded_qty) > 0
      || line.confirmed === true
      || Boolean(line.confirmed_at)
    ));
    const conflicts = [];
    if (activeAssignments.length || activeSnapshots.length) {
      conflicts.push({
        type: "dispatch_plan",
        message: "Remove this VRMA from every active Dispatch plan first.",
        planIds: [...new Set([
          ...activeAssignments.map((row) => Number(row.plan_id)),
          ...activeSnapshots.map((row) => Number(row.plan_id))
        ])]
      });
    }
    if (groupResult.rows.length) {
      conflicts.push({
        type: "active_group",
        message: "Ungroup this VRMA before removing it.",
        groupRefs: groupResult.rows.map((row) => row.group_ref)
      });
    }
    if (hasHeaderActivity || hasLineActivity) {
      conflicts.push({
        type: "operator_activity",
        message: "Operator packing or loading has already started."
      });
    }
    if (loadHistoryResult.rows.length) {
      conflicts.push({
        type: "operator_load_history",
        message: "This VRMA has retained Operator load history and cannot be removed.",
        recordIds: loadHistoryResult.rows.map((row) => Number(row.id))
      });
    }
    if (conflicts.length) {
      throw Object.assign(new Error(conflicts[0].message), {
        status: 409,
        code: "SCM_VRMA_REMOVE_BLOCKED",
        conflicts
      });
    }

    const cancelledHeaderResult = await query(
      `UPDATE scm_vrma_orders
          SET status = 'Cancelled',
              cancelled_at = now(),
              cancelled_by = $2,
              cancellation_note = $3,
              cancellation_source = 'scm_remove',
              updated_by = $2,
              status_updated_at = now(),
              updated_at = now()
        WHERE id = $1
        RETURNING *`,
      [header.id, cleanActor, cleanNote]
    );
    const cancelledScheduleResult = await query(
      `INSERT INTO scm_transport_schedule (
         order_kind, source_table, source_id, order_ref, method,
         pickup_point, dropoff_point, brand, content, weight_lbs,
         status, notes, created_by, updated_by, created_at, updated_at
       )
       SELECT 'VRMA', 'scm_vrma_orders', v.id, v.vrma_ref, COALESCE(v.method, 'MBT'),
              v.pickup_location, v.dropoff_location, COALESCE(v.local_vendor, v.vendor),
              COALESCE(string_agg(
                trim(concat_ws(' ', COALESCE(line.sku, line.item_name), line.quantity, line.unit)),
                '; ' ORDER BY line.id
              ), ''),
              COALESCE(SUM(line.weight_lbs), 0),
              'Cancelled', NULLIF(v.notes, ''), $2, $2, now(), now()
         FROM scm_vrma_orders v
         LEFT JOIN scm_vrma_order_lines line ON line.vrma_order_id = v.id
        WHERE v.id = $1
        GROUP BY v.id
       ON CONFLICT (order_kind, order_ref) DO UPDATE SET
         status = 'Cancelled',
         updated_by = EXCLUDED.updated_by,
         updated_at = now()
       RETURNING *`,
      [header.id, cleanActor]
    );
    return {
      removed: true,
      idempotent: false,
      before,
      after: {
        vrma: cancelledHeaderResult.rows[0],
        schedule: cancelledScheduleResult.rows[0]
      }
    };
  });
}

export async function completeScmVrmaOrderOverride({
  vrmaRef = "",
  note = "",
  actor = "",
  expectedUpdatedAt = "",
  confirm = false,
  force = false
} = {}) {
  const ref = String(vrmaRef || "").trim();
  const cleanNote = String(note || "").trim();
  const cleanActor = String(actor || "").trim();
  const expected = expectedUpdatedAt ? new Date(expectedUpdatedAt) : null;
  if (!ref) throw Object.assign(new Error("VRMA ref is required."), { status: 400 });
  if (!cleanActor) throw Object.assign(new Error("SCM or Admin identity is required."), { status: 401 });
  if (!cleanNote) throw Object.assign(new Error("An audit note is required to complete a VRMA."), { status: 400 });
  if (confirm !== true) {
    throw Object.assign(new Error("Confirm that this local VRMA should be marked Completed."), { status: 400 });
  }
  if (!expected || Number.isNaN(expected.getTime())) {
    throw Object.assign(new Error("Refresh this VRMA before marking it Completed."), {
      status: 409,
      code: "SCM_VRMA_STALE"
    });
  }

  return withTransaction(async () => {
    const selected = await query(
      `SELECT *
         FROM scm_vrma_orders
        WHERE lower(vrma_ref) = lower($1)
        LIMIT 1
        FOR UPDATE`,
      [ref]
    );
    const header = selected.rows[0];
    if (!header) throw Object.assign(new Error("VRMA order not found."), { status: 404 });
    const scheduleResult = await query(
      `SELECT *
         FROM scm_transport_schedule
        WHERE order_kind = 'VRMA'
          AND lower(order_ref) = lower($1)
        LIMIT 1
        FOR UPDATE`,
      [header.vrma_ref]
    );
    const schedule = scheduleResult.rows[0] || null;
    const current = {
      ...header,
      schedule_id: schedule?.id || null,
      schedule_status: schedule?.status || null,
      schedule_updated_at: schedule?.updated_at || null,
      schedule_driver: schedule?.driver || null,
      schedule_eta_date: schedule?.eta_date || null,
      schedule_eta_time: schedule?.eta_time || null
    };

    const concurrencyTimestamp = current.schedule_updated_at || current.updated_at;
    if (
      !concurrencyTimestamp
      || new Date(concurrencyTimestamp).getTime() !== expected.getTime()
    ) {
      throw Object.assign(new Error("This VRMA changed after it was opened. Refresh and try again."), {
        status: 409,
        code: "SCM_VRMA_STALE"
      });
    }
    const status = String(current.schedule_status || current.status || "Queued").trim();
    if (status === "Completed" || String(current.status || "").trim() === "Completed") {
      return {
        completed: true,
        idempotent: true,
        loadedComplete: String(current.operator_status || "").toLowerCase() === "loaded",
        before: current,
        after: current
      };
    }
    if (["Cancelled", "Hold"].includes(status) || ["Cancelled", "Hold"].includes(String(current.status || "").trim())) {
      throw Object.assign(new Error(`A ${status || current.status} VRMA cannot be marked Completed.`), { status: 409 });
    }

    const lineProgress = await query(
      `SELECT COUNT(*)::int AS line_count,
              COUNT(*) FILTER (
                WHERE COALESCE(loaded_qty, 0) + 0.000001 >= COALESCE(quantity, 0)
              )::int AS fully_loaded_count,
              COALESCE(SUM(quantity), 0) AS ordered_qty,
              COALESCE(SUM(loaded_qty), 0) AS loaded_qty
         FROM scm_vrma_order_lines
        WHERE vrma_order_id = $1`,
      [current.id]
    );
    const progress = lineProgress.rows[0] || {};
    const loadedComplete = Number(progress.line_count || 0) > 0
      && Number(progress.fully_loaded_count || 0) === Number(progress.line_count || 0);
    if (!loadedComplete && force !== true) {
      throw Object.assign(
        new Error("Operator loading is not complete. Confirm the forced completion after reviewing this VRMA."),
        {
          status: 409,
          code: "SCM_VRMA_FORCE_CONFIRMATION_REQUIRED",
          loadedComplete: false,
          progress: {
            lineCount: Number(progress.line_count || 0),
            fullyLoadedCount: Number(progress.fully_loaded_count || 0),
            orderedQty: Number(progress.ordered_qty || 0),
            loadedQty: Number(progress.loaded_qty || 0)
          }
        }
      );
    }

    const headerResult = await query(
      `UPDATE scm_vrma_orders
          SET status = 'Completed',
              completed_at = COALESCE(completed_at, now()),
              completed_by = $2,
              completion_note = $3,
              completion_source = 'scm_override',
              updated_by = $2,
              status_updated_at = now(),
              updated_at = now()
        WHERE id = $1
        RETURNING *`,
      [current.id, cleanActor, cleanNote]
    );
    const completedScheduleResult = await query(
      `INSERT INTO scm_transport_schedule (
         order_kind, source_table, source_id, order_ref, method,
         pickup_point, dropoff_point, brand, content, weight_lbs,
         status, notes, created_by, updated_by, created_at, updated_at
       )
       SELECT 'VRMA', 'scm_vrma_orders', v.id, v.vrma_ref, COALESCE(v.method, 'MBT'),
              v.pickup_location, v.dropoff_location, COALESCE(v.local_vendor, v.vendor),
              COALESCE(string_agg(
                trim(concat_ws(' ', COALESCE(line.sku, line.item_name), line.quantity, line.unit)),
                '; ' ORDER BY line.id
              ), ''),
              COALESCE(SUM(line.weight_lbs), 0),
              'Completed', NULLIF(v.notes, ''), $2, $2, now(), now()
         FROM scm_vrma_orders v
         LEFT JOIN scm_vrma_order_lines line ON line.vrma_order_id = v.id
        WHERE v.id = $1
        GROUP BY v.id
       ON CONFLICT (order_kind, order_ref) DO UPDATE SET
         status = 'Completed',
         updated_by = EXCLUDED.updated_by,
         updated_at = now()
       RETURNING *`,
      [current.id, cleanActor]
    );
    return {
      completed: true,
      idempotent: false,
      loadedComplete,
      forced: !loadedComplete,
      progress: {
        lineCount: Number(progress.line_count || 0),
        fullyLoadedCount: Number(progress.fully_loaded_count || 0),
        orderedQty: Number(progress.ordered_qty || 0),
        loadedQty: Number(progress.loaded_qty || 0)
      },
      before: {
        vrma: current,
        schedule: current.schedule_id ? {
          id: current.schedule_id,
          status: current.schedule_status,
          updatedAt: current.schedule_updated_at,
          driver: current.schedule_driver,
          etaDate: current.schedule_eta_date,
          etaTime: current.schedule_eta_time
        } : null
      },
      after: {
        vrma: headerResult.rows[0],
        schedule: completedScheduleResult.rows[0]
      }
    };
  });
}

function vrmaUnit(value) {
  const unit = String(value || "").trim().toUpperCase();
  return SCM_VRMA_FALLBACK_UNITS.has(unit) ? unit : "";
}

function vrmaLineContent(line = {}) {
  const units = [
    ["PLT", line.palletQty],
    ["LYR", line.layerQty],
    ["SEC", line.sectionQty],
    ["PCS", line.pieceQty]
  ].filter(([, quantity]) => positiveQuantity(quantity) > 0)
    .map(([unit, quantity]) => `${positiveQuantity(quantity)} ${unit}`);
  const quantityText = units.length ? units.join(" ") : `${positiveQuantity(line.quantity)} ${line.unit || ""}`.trim();
  return `${line.sku || line.itemName || "Item"} ${quantityText}`.trim();
}

export async function createScmVrmaOrder({
  vrmaRef = "",
  vendor = "",
  localVendor = "",
  pickupLocation = "",
  dropoffLocation = "",
  status = "Queued",
  method = "MBT",
  notes = "",
  lines = [],
  createdBy = ""
} = {}) {
  const ref = String(vrmaRef || "").trim();
  if (!ref) throw new Error("VRMA ref is required.");
  if (!Array.isArray(lines) || !lines.length) throw new Error("At least one VRMA line is required.");
  const pickup = String(pickupLocation || "").trim();
  const selectedVendor = String(localVendor || vendor || "").trim();
  const requestedDropoff = String(dropoffLocation || "").trim();
  const requestedStatus = normalizeManualScmStatus(status);
  if (requestedStatus === "Cancelled") {
    throw Object.assign(new Error("Use Delete VRMA so cancellation is validated and audited."), { status: 400 });
  }
  if (!SCM_VRMA_OWN_YARD_CODES.has(pickup)) throw new Error("VRMA pickup must be one of our local yards.");
  if (!selectedVendor) throw new Error("Local vendor is required.");
  if (!requestedDropoff) throw new Error("Vendor drop-off yard is required.");
  return withTransaction(async () => {
    const existingActivity = await query(
      `SELECT v.id, v.status, v.operator_status, v.preparing_operator_id, v.loaded_at,
              v.cancelled_at, v.cancellation_source,
              (
                SELECT co.co_ref
                  FROM local_co_orders co
                 WHERE lower(btrim(co.source_order_ref)) = lower(btrim(v.vrma_ref))
                   AND co.status <> 'cancelled'
                 ORDER BY co.updated_at DESC, co.id DESC
                 LIMIT 1
              ) AS active_co_ref,
              EXISTS (
                SELECT 1
                  FROM scm_vrma_order_lines line
                 WHERE line.vrma_order_id = v.id
                   AND (
                     COALESCE(line.packed_pallet_qty, 0) > 0
                     OR COALESCE(line.packed_layer_qty, 0) > 0
                     OR COALESCE(line.packed_section_qty, 0) > 0
                     OR COALESCE(line.packed_piece_qty, 0) > 0
                     OR COALESCE(line.packed_sales_qty, 0) > 0
                     OR COALESCE(line.loaded_qty, 0) > 0
                   )
              ) AS has_operator_activity
         FROM scm_vrma_orders v
        WHERE LOWER(v.vrma_ref) = LOWER($1)
        LIMIT 1`,
      [ref]
    );
    const activity = existingActivity.rows[0];
    if (activity?.active_co_ref) {
      throw Object.assign(
        new Error(`Cancel ${activity.active_co_ref} before editing this VRMA.`),
        { status: 409, code: "SCM_VRMA_ACTIVE_CO" }
      );
    }
    if (activity && (
      activity.status === "Completed"
      || activity.cancelled_at
      || activity.cancellation_source === "scm_remove"
      || activity.operator_status !== "open"
      || activity.preparing_operator_id
      || activity.loaded_at
      || activity.has_operator_activity
    )) {
      const error = new Error(
        activity.status === "Completed"
          ? "This VRMA can no longer be edited because SCM marked it Completed."
          : activity.cancelled_at || activity.cancellation_source === "scm_remove"
            ? "This VRMA was removed and can no longer be edited."
          : "This VRMA can no longer be edited because Operator packing or loading has started."
      );
      error.status = 409;
      throw error;
    }

    const vendorYardResult = await query(
      `SELECT y.yard, y.address, y.window_start, y.window_end, y.instructions, y.day_label
         FROM dispatch_local_vendors v
         JOIN dispatch_vendor_yards y ON LOWER(y.vendor) = LOWER(v.name)
        WHERE v.active = true
          AND y.active = true
          AND LOWER(v.name) = LOWER($1)
          AND LOWER(y.yard) = LOWER($2)
        ORDER BY y.id
        LIMIT 1`,
      [selectedVendor, requestedDropoff]
    );
    const vendorYard = vendorYardResult.rows[0];
    if (!vendorYard) throw new Error(`${requestedDropoff} is not an active yard for ${selectedVendor}.`);
    const normalizedLines = [];
    for (const [index, line] of lines.entries()) {
      const itemId = Number(line.itemId || line.item_id || 0);
      if (!Number.isFinite(itemId) || itemId <= 0) throw new Error(`Select an inventory item for VRMA line ${index + 1}.`);
      const itemResult = await query(
        `SELECT item_id, item_name, display_name, item_description, stock_unit, item_weight,
                to_plt, to_lyr, to_sec, to_pcs
           FROM inventory_items
          WHERE item_id = $1
          LIMIT 1`,
        [itemId]
      );
      const item = itemResult.rows[0];
      if (!item) throw new Error(`Inventory item ${itemId} is no longer available.`);
      const conversions = {
        toPlt: positiveQuantity(item.to_plt),
        toLyr: positiveQuantity(item.to_lyr),
        toSec: positiveQuantity(item.to_sec),
        toPcs: positiveQuantity(item.to_pcs)
      };
      const componentQuantities = {
        palletQty: conversions.toPlt ? positiveQuantity(line.palletQty ?? line.pallet_qty) : 0,
        layerQty: conversions.toLyr ? positiveQuantity(line.layerQty ?? line.layer_qty) : 0,
        sectionQty: conversions.toSec ? positiveQuantity(line.sectionQty ?? line.section_qty) : 0,
        pieceQty: conversions.toPcs ? positiveQuantity(line.pieceQty ?? line.piece_qty) : 0
      };
      const hasConversions = Object.values(conversions).some((value) => value > 0);
      let quantity = 0;
      let unit = "";
      if (hasConversions) {
        quantity = (componentQuantities.palletQty * conversions.toPlt)
          + (componentQuantities.layerQty * conversions.toLyr)
          + (componentQuantities.sectionQty * conversions.toSec)
          + (componentQuantities.pieceQty * conversions.toPcs);
        unit = String(item.stock_unit || "").trim();
        if (!Object.values(componentQuantities).some((value) => value > 0)) {
          throw new Error(`Enter at least one converted quantity for VRMA line ${index + 1}.`);
        }
      } else {
        quantity = positiveQuantity(line.quantity);
        unit = vrmaUnit(line.unit);
        if (!quantity) throw new Error(`Quantity is required for VRMA line ${index + 1}.`);
        if (!unit) throw new Error(`UOM for VRMA line ${index + 1} must be PLT, SQFT, or PC.`);
        if (unit === "PLT") componentQuantities.palletQty = quantity;
      }
      const itemWeight = positiveQuantity(item.item_weight);
      normalizedLines.push({
        itemId: item.item_id,
        sku: item.item_name || "",
        itemName: item.display_name || item.item_name || "",
        description: item.item_description || "",
        quantity,
        unit,
        weightLbs: quantity * itemWeight,
        ...componentQuantities,
        ...conversions
      });
    }
    if (!normalizedLines.length) throw new Error("At least one VRMA line is required.");

    const header = await query(
      `INSERT INTO scm_vrma_orders (vrma_ref, vendor, local_vendor, pickup_location, dropoff_location, status, method, notes, created_by, updated_by)
       VALUES ($1, NULLIF($2, ''), NULLIF($3, ''), NULLIF($4, ''), NULLIF($5, ''), $6, $7, NULLIF($8, ''), $9, $9)
       ON CONFLICT (vrma_ref) DO UPDATE SET
         vendor = EXCLUDED.vendor,
         local_vendor = EXCLUDED.local_vendor,
         pickup_location = EXCLUDED.pickup_location,
         dropoff_location = EXCLUDED.dropoff_location,
         status = EXCLUDED.status,
         method = EXCLUDED.method,
         notes = EXCLUDED.notes,
         updated_by = EXCLUDED.updated_by,
         updated_at = now()
       RETURNING *`,
      [
        ref,
        selectedVendor,
        selectedVendor,
        pickup,
        vendorYard.yard,
        requestedStatus,
        "MBT",
        String(notes || "").trim(),
        createdBy || null
      ]
    );
    await query("DELETE FROM scm_vrma_order_lines WHERE vrma_order_id = $1", [header.rows[0].id]);
    for (const line of normalizedLines) {
      await query(
        `INSERT INTO scm_vrma_order_lines (
           vrma_order_id, item_id, sku, item_name, item_description, quantity, unit, weight_lbs,
           pallet_qty, layer_qty, section_qty, piece_qty, to_plt, to_lyr, to_sec, to_pcs
         ) VALUES (
           $1, $2, NULLIF($3, ''), $4, NULLIF($5, ''), $6, NULLIF($7, ''), $8,
           $9, $10, $11, $12, NULLIF($13, 0), NULLIF($14, 0), NULLIF($15, 0), NULLIF($16, 0)
         )`,
        [
          header.rows[0].id,
          line.itemId,
          line.sku,
          line.itemName,
          line.description,
          line.quantity,
          line.unit,
          line.weightLbs,
          line.palletQty,
          line.layerQty,
          line.sectionQty,
          line.pieceQty,
          line.toPlt,
          line.toLyr,
          line.toSec,
          line.toPcs
        ]
      );
    }
    await query(
      `INSERT INTO scm_transport_schedule (
         order_kind, source_table, source_id, order_ref, method, pickup_point, dropoff_point,
         brand, content, weight_lbs, status, notes, created_by, updated_by
       )
       SELECT 'VRMA', 'scm_vrma_orders', $1, $2, $3, NULLIF($4, ''), NULLIF($5, ''),
              NULLIF($6, ''), NULLIF($7, ''), COALESCE(SUM(weight_lbs), 0), $8, NULLIF($9, ''), $10, $10
         FROM scm_vrma_order_lines
        WHERE vrma_order_id = $1
       ON CONFLICT (order_kind, order_ref) DO UPDATE SET
         source_table = EXCLUDED.source_table,
         source_id = EXCLUDED.source_id,
         method = EXCLUDED.method,
         pickup_point = EXCLUDED.pickup_point,
         dropoff_point = EXCLUDED.dropoff_point,
         brand = EXCLUDED.brand,
         content = EXCLUDED.content,
         weight_lbs = EXCLUDED.weight_lbs,
         status = EXCLUDED.status,
         notes = EXCLUDED.notes,
         updated_by = EXCLUDED.updated_by,
         updated_at = now()`,
      [
        header.rows[0].id,
        ref,
        "MBT",
        pickup,
        vendorYard.yard,
        selectedVendor,
        normalizedLines.map(vrmaLineContent).join("; "),
        requestedStatus,
        String(notes || "").trim(),
        createdBy || null
      ]
    );
    return { vrma: header.rows[0], vendorYard, lines: normalizedLines };
  });
}

function dispatchScheduleEtaTime(stop = {}) {
  const legacyTime = String(stop.arriveTime || stop.plannedArrive || "").trim();
  if (legacyTime) return legacyTime;
  const rawArrival = stop?.timing?.arrival;
  if (rawArrival === null || rawArrival === undefined || rawArrival === "") return "";
  const arrival = Number(rawArrival);
  if (!Number.isFinite(arrival) || arrival < 0) return "";
  const minute = Math.floor(arrival);
  return `${String(Math.floor(minute / 60)).padStart(2, "0")}:${String(minute % 60).padStart(2, "0")}`;
}

export async function syncScmScheduleFromDispatchPlan(plan, { updatedBy = "dispatch-plan" } = {}) {
  if (!plan?.planDate || !Array.isArray(plan.trucks)) return { planned: 0, unplanned: 0 };
  const plannedRows = [];
  for (const truck of plan.trucks || []) {
    for (const load of truck.loads || []) {
      if (load.returnOnly) continue;
      const assignment = dispatchLoadAssignment(truck, load);
      for (const stop of load.stops || []) {
        if (!["drop", "dropoff"].includes(String(stop.type || "").toLowerCase()) || !stop.orderId) continue;
        const order = (plan.orders || []).find((item) => item.id === stop.orderId);
        if (order?.type !== "PO" && order?.type !== "TO" && order?.sourceTable !== "scm_vrma_orders") continue;
        plannedRows.push({
          orderRef: order.id,
          orderKind: order.sourceTable === "scm_vrma_orders" ? "VRMA" : order.type === "TO" ? "TO" : "PO",
          truckPlate: assignment.truckPlate,
          driver: assignment.driverName || assignment.driverLogin,
          loadName: load.name || "",
          parkingSpot: assignment.parkingSpot,
          etaDate: plan.planDate,
          etaTime: dispatchScheduleEtaTime(stop)
        });
      }
    }
  }
  const vrmaAssignments = plannedRows.filter((row) => row.orderKind === "VRMA");
  if (plan.id) {
    await query("DELETE FROM dispatch_vrma_plan_assignments WHERE plan_id = $1", [plan.id]);
    for (const row of vrmaAssignments) {
      await query(
        `INSERT INTO dispatch_vrma_plan_assignments (
           plan_id, order_ref, plan_date, truck_plate, driver, load_name, parking_spot, eta_time, updated_at
         ) VALUES ($1, $2, $3::date, NULLIF($4, ''), NULLIF($5, ''), NULLIF($6, ''), NULLIF($7, ''), NULLIF($8, ''), now())
         ON CONFLICT (plan_id, order_ref) DO UPDATE SET
           plan_date = EXCLUDED.plan_date,
           truck_plate = EXCLUDED.truck_plate,
           driver = EXCLUDED.driver,
           load_name = EXCLUDED.load_name,
           parking_spot = EXCLUDED.parking_spot,
           eta_time = EXCLUDED.eta_time,
           updated_at = now()`,
        [plan.id, row.orderRef, row.etaDate, row.truckPlate, row.driver, row.loadName, row.parkingSpot, row.etaTime]
      );
    }
  }
  for (const row of plannedRows) {
    await query(
      `INSERT INTO scm_transport_schedule (
         order_kind, order_ref, method, status, eta_date, eta_time, driver,
         dispatch_assignment_note, updated_by, created_by,
         dispatch_plan_id, dispatch_previous_state
       )
       VALUES (
         $1, $2, 'MBT', 'Planned', $3::date, NULLIF($4, ''), NULLIF($5, ''),
         NULLIF($6, ''), $7, $7, $8::bigint, jsonb_build_object('status', 'Queued')
       )
       ON CONFLICT (order_kind, order_ref) DO UPDATE SET
         dispatch_previous_state = CASE
           WHEN scm_transport_schedule.dispatch_previous_state IS NOT NULL
             THEN scm_transport_schedule.dispatch_previous_state
           WHEN scm_transport_schedule.status = 'Planned'
             THEN jsonb_build_object('status', 'Queued')
           ELSE jsonb_build_object(
             'status', scm_transport_schedule.status,
             'etaDate', scm_transport_schedule.eta_date,
             'etaTime', scm_transport_schedule.eta_time,
             'driver', scm_transport_schedule.driver,
             'dispatchAssignmentNote', scm_transport_schedule.dispatch_assignment_note
           )
         END,
         dispatch_plan_id = EXCLUDED.dispatch_plan_id,
         method = CASE WHEN scm_transport_schedule.method IS NULL THEN 'MBT' ELSE scm_transport_schedule.method END,
         status = CASE
           WHEN scm_transport_schedule.reconciliation_blocked = true THEN 'Reconcile Review'
           WHEN scm_transport_schedule.status IN (
             'Completed', 'Cancelled', 'Hold', 'In Transit',
             'Partially Done', 'Reconcile Review'
           ) THEN scm_transport_schedule.status
           ELSE 'Planned'
         END,
         eta_date = EXCLUDED.eta_date,
         eta_time = EXCLUDED.eta_time,
         driver = EXCLUDED.driver,
         dispatch_assignment_note = EXCLUDED.dispatch_assignment_note,
         updated_by = EXCLUDED.updated_by,
         updated_at = now()`,
      [
        row.orderKind,
        row.orderRef,
        row.etaDate,
        row.etaTime,
        row.driver,
        `${row.truckPlate} ${row.loadName}${row.parkingSpot ? ` Parking ${row.parkingSpot}` : ""}`.trim(),
        updatedBy || null,
        plan.id || null
      ]
    );
  }
  let unplanned = 0;
  if (plan.id) {
    const activeScheduleKeys = [...new Set(plannedRows
      .filter((row) => ["PO", "TO"].includes(row.orderKind))
      .map((row) => `${row.orderKind}:${row.orderRef}`.toLowerCase()))];
    const reverted = await query(
      `UPDATE scm_transport_schedule schedule
          SET status = COALESCE(
                NULLIF(schedule.dispatch_previous_state->>'status', ''),
                CASE
                  WHEN schedule.order_kind = 'PO' THEN (
                    SELECT NULLIF(po.initial_scm_status, '')
                      FROM purchase_orders po
                     WHERE lower(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid)) = lower(schedule.order_ref)
                     ORDER BY po.netsuite_active DESC, po.synced_at DESC NULLS LAST
                     LIMIT 1
                  )
                END,
                'Queued'
              ),
              eta_date = NULLIF(schedule.dispatch_previous_state->>'etaDate', '')::date,
              eta_time = NULLIF(schedule.dispatch_previous_state->>'etaTime', ''),
              driver = NULLIF(schedule.dispatch_previous_state->>'driver', ''),
              dispatch_assignment_note = NULLIF(schedule.dispatch_previous_state->>'dispatchAssignmentNote', ''),
              dispatch_plan_id = NULL,
              dispatch_previous_state = NULL,
              updated_by = $3,
              updated_at = now()
        WHERE schedule.dispatch_plan_id = $1::bigint
          AND schedule.order_kind IN ('PO', 'TO')
          AND schedule.status = 'Planned'
          AND NOT (lower(schedule.order_kind || ':' || schedule.order_ref) = ANY($2::text[]))
        RETURNING schedule.id`,
      [plan.id, activeScheduleKeys, updatedBy || null]
    );
    unplanned = reverted.rowCount || 0;
  }
  return { planned: plannedRows.length, unplanned };
}

async function scmPurchaseOrderSplitOperationalConflicts(executor, split = {}) {
  const runQuery = typeof executor === "function" ? executor : executor.query.bind(executor);
  const ref = String(split.split_po_ref || split.splitPoRef || "").trim();
  const splitPoId = Number(split.split_po_id || split.splitPoId || 0);
  const result = await runQuery(
    `SELECT
       EXISTS (
         SELECT 1
           FROM dispatch_plan_order_assignments assignment
           JOIN dispatch_plans plan ON plan.id = assignment.plan_id
          WHERE plan.status <> 'cancelled'
            AND (lower(assignment.order_ref) = lower($1)
              OR lower(NULLIF(assignment.planned_order_ref, '')) = lower($1))
       ) AS indexed_plan,
       EXISTS (
         SELECT 1
           FROM scm_transport_schedule schedule
           JOIN dispatch_plans schedule_plan
             ON schedule_plan.id = schedule.dispatch_plan_id
            AND schedule_plan.status <> 'cancelled'
          WHERE schedule.order_kind = 'PO'
            AND lower(schedule.order_ref) = lower($1)
       ) AS schedule_plan,
       EXISTS (
         SELECT 1
           FROM dispatch_plan_snapshots snapshot
           JOIN dispatch_plans plan ON plan.id = snapshot.plan_id
          WHERE plan.status <> 'cancelled'
            AND snapshot.trucks::text LIKE $3
       ) AS legacy_plan,
       EXISTS (
         SELECT 1
           FROM purchase_order_lines line
          WHERE line.purchase_order_id = $2
            AND (COALESCE(line.received_pallet_qty, 0) > 0
              OR COALESCE(line.received_layer_qty, 0) > 0
              OR COALESCE(line.received_section_qty, 0) > 0
              OR COALESCE(line.received_piece_qty, 0) > 0
              OR COALESCE(line.netsuite_received_qty, 0) > 0
              OR line.confirmed_at IS NOT NULL)
       ) AS receiving_activity,
       EXISTS (
         SELECT 1
           FROM driver_job_records job
          WHERE job.status IN ('in_progress', 'complete')
            AND job.order_refs ? $1
       ) AS driver_activity,
       EXISTS (
         SELECT 1
           FROM dispatch_so_po_allocations allocation
          WHERE allocation.po_order_id = $2
            AND allocation.status = 'active'
       ) AS active_po_link,
       EXISTS (
         SELECT 1
           FROM scm_schedule_group_members member
           JOIN scm_schedule_groups group_header ON group_header.id = member.group_id
          WHERE group_header.status = 'active'
            AND lower(member.order_ref) = lower($1)
       ) AS active_group`,
    [ref, splitPoId, `%"${ref.replaceAll('"', '\\"')}"%`]
  );
  const row = result.rows[0] || {};
  return {
    planned: row.indexed_plan === true || row.schedule_plan === true || row.legacy_plan === true,
    receivingActivity: row.receiving_activity === true,
    driverActivity: row.driver_activity === true,
    activePoLink: row.active_po_link === true,
    activeGroup: row.active_group === true
  };
}

async function assertScmPurchaseOrderSplitMutable(executor, split = {}, {
  action = "change",
  expectedRevision = undefined,
  requireRevision = false
} = {}) {
  const revision = Number(split.revision || 1);
  if ((requireRevision && expectedRevision === undefined)
    || (expectedRevision !== undefined && Number(expectedRevision) !== revision)) {
    throw Object.assign(new Error("This split PO changed after it was opened. Refresh and try again."), {
      status: 409,
      code: "SCM_PO_SPLIT_STALE",
      expectedRevision: expectedRevision === undefined ? null : Number(expectedRevision),
      currentRevision: revision
    });
  }
  const conflicts = await scmPurchaseOrderSplitOperationalConflicts(executor, split);
  if (conflicts.planned) {
    throw Object.assign(new Error(`Cannot ${action} ${split.split_po_ref}. Unplan it from Dispatch first.`), {
      status: 409,
      code: "SCM_PO_SPLIT_OPERATIONAL",
      conflicts
    });
  }
  if (conflicts.receivingActivity || conflicts.driverActivity) {
    throw Object.assign(new Error(`Cannot ${action} ${split.split_po_ref}. Receiving or Driver activity already exists.`), {
      status: 409,
      code: "SCM_PO_SPLIT_OPERATIONAL",
      conflicts
    });
  }
  if (conflicts.activePoLink || conflicts.activeGroup) {
    throw Object.assign(new Error(`Cannot ${action} ${split.split_po_ref}. Unlink or ungroup it first.`), {
      status: 409,
      code: "SCM_PO_SPLIT_OPERATIONAL",
      conflicts
    });
  }
  return conflicts;
}

async function recordScmPurchaseOrderSplitChange(executor, split = {}, {
  expectedRevision = null,
  eventType,
  beforeState = {},
  afterState = {},
  actor = ""
} = {}) {
  const runQuery = typeof executor === "function" ? executor : executor.query.bind(executor);
  const advanced = await runQuery(
    `UPDATE dispatch_scm_po_splits
        SET revision = revision + 1,
            updated_at = GREATEST(clock_timestamp(), updated_at + interval '1 microsecond')
      WHERE id = $1
      RETURNING revision, updated_at`,
    [split.id]
  );
  const appliedRevision = Number(advanced.rows[0]?.revision || Number(split.revision || 1) + 1);
  await runQuery(
    `INSERT INTO dispatch_scm_po_split_change_events (
       split_id, expected_revision, applied_revision, event_type,
       before_state, after_state, actor
     ) VALUES ($1, $2, $3, $4, $5::jsonb, $6::jsonb, NULLIF($7, ''))`,
    [split.id, expectedRevision, appliedRevision, eventType,
      JSON.stringify(beforeState || {}), JSON.stringify(afterState || {}), String(actor || "")]
  );
  return { revision: appliedRevision, updatedAt: advanced.rows[0]?.updated_at || null };
}

export async function updateScmPurchaseOrderSplitRef({
  splitPoRef = "",
  newPoRef = "",
  updatedBy = "",
  expectedRevision = undefined
} = {}) {
  const oldRef = String(splitPoRef || "").trim();
  const nextRef = String(newPoRef || "").trim();
  if (!oldRef) throw new Error("Current split PO ref is required.");
  if (!nextRef) throw new Error("New PO ref number is required.");
  if (oldRef.toLowerCase() === nextRef.toLowerCase()) throw new Error("The new PO ref is the same as the current ref.");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const splitResult = await client.query(
      `SELECT *
         FROM dispatch_scm_po_splits
        WHERE lower(split_po_ref) = lower($1)
          AND status = 'active'
        LIMIT 1
        FOR UPDATE`,
      [oldRef]
    );
    const split = splitResult.rows[0];
    if (!split) throw new Error(`SCM split ${oldRef} was not found.`);
    await assertScmPurchaseOrderSplitMutable(client, split, {
      action: "rename",
      expectedRevision
    });
    const existing = await client.query(
      `SELECT COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid) AS tranid
         FROM purchase_orders po
        WHERE lower(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid)) = lower($1)
          AND po.netsuite_id <> $3
          AND NOT EXISTS (
            SELECT 1
              FROM dispatch_scm_po_splits retired_split
             WHERE retired_split.split_po_id = po.netsuite_id
               AND retired_split.status = 'cancelled'
          )
       UNION
       SELECT split_po_ref AS tranid FROM dispatch_scm_po_splits
        WHERE lower(split_po_ref) = lower($1)
          AND id <> $2
          AND status = 'active'`,
      [nextRef, split.id, split.split_po_id]
    );
    if (existing.rowCount) throw new Error(`PO ref ${nextRef} already exists.`);
    await client.query(
      `UPDATE purchase_orders
          SET dispatch_ref = $2,
              dispatch_ref_updated_at = now(),
              dispatch_ref_updated_by = $3,
              synced_at = now(),
              status_updated_at = now()
        WHERE netsuite_id = $1`,
      [split.split_po_id, nextRef, updatedBy || null]
    );
    await client.query(
      `UPDATE dispatch_scm_po_splits
          SET split_po_ref = $2,
              details = COALESCE(details, '{}'::jsonb) || $3::jsonb
        WHERE id = $1`,
      [
        split.id,
        nextRef,
        JSON.stringify({
          lastRenamedAt: new Date().toISOString(),
          lastRenamedBy: updatedBy || "",
          previousRefs: [...(Array.isArray(split.details?.previousRefs) ? split.details.previousRefs : []), oldRef]
        })
      ]
    );
    const scheduleRename = await client.query(
      `UPDATE scm_transport_schedule
          SET order_ref = $2,
              display_ref = CASE WHEN lower(COALESCE(display_ref, '')) = lower($1) THEN $2 ELSE display_ref END,
              packing_slip_ref = CASE WHEN lower(COALESCE(packing_slip_ref, '')) = lower($1) THEN $2 ELSE packing_slip_ref END,
              updated_by = $3,
              updated_at = GREATEST(clock_timestamp(), updated_at + interval '1 microsecond')
        WHERE order_kind = 'PO' AND lower(order_ref) = lower($1)
        RETURNING to_char(updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS concurrency_updated_at`,
      [oldRef, nextRef, updatedBy || null]
    );
    const snapshotUpdate = await updateDispatchSnapshotsForRef(client, { oldRef, newRef: nextRef });
    const change = await recordScmPurchaseOrderSplitChange(client, split, {
      expectedRevision: expectedRevision === undefined ? null : Number(expectedRevision),
      eventType: "ref_changed",
      beforeState: { splitPoRef: oldRef },
      afterState: { splitPoRef: nextRef },
      actor: updatedBy
    });
    await client.query("COMMIT");
    for (const plan of snapshotUpdate.plans || []) {notifyDispatchPlanMaintenance(plan);}
    return {
      splitId: split.id,
      sourcePoRef: split.source_po_ref,
      oldPoRef: oldRef,
      newPoRef: nextRef,
      updatedPlans: snapshotUpdate.planIds,
      revision: change.revision,
      scheduleUpdatedAt: scheduleRename.rows[0]?.concurrency_updated_at || null
    };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => null);
    throw error;
  } finally {
    client.release();
  }
}

export async function updatePurchaseOrderDispatchRef({
  poRef = "",
  newRef = "",
  updatedBy = ""
} = {}) {
  const lookupRef = String(poRef || "").trim();
  const requestedRef = String(newRef || "").trim();
  if (!lookupRef) throw new Error("Purchase order is required.");
  return withTransaction(async () => {
    const poResult = await query(
      `SELECT netsuite_id, tranid, dispatch_ref
         FROM purchase_orders
        WHERE lower(tranid) = lower($1)
           OR lower(dispatch_ref) = lower($1)
        ORDER BY CASE WHEN lower(dispatch_ref) = lower($1) THEN 0 ELSE 1 END
        LIMIT 1`,
      [lookupRef]
    );
    const po = poResult.rows[0];
    if (!po) throw new Error(`Purchase order ${lookupRef} was not found.`);
    const oldVisibleRef = String(po.dispatch_ref || po.tranid || "").trim();
    const normalizedRef = requestedRef && requestedRef.toLowerCase() !== String(po.tranid || "").toLowerCase()
      ? requestedRef
      : "";
    const newVisibleRef = normalizedRef || po.tranid;
    if (normalizedRef) {
      const existing = await query(
        `SELECT COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid) AS tranid
           FROM purchase_orders po
          WHERE lower(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid)) = lower($1)
            AND po.netsuite_id <> $2
            AND NOT EXISTS (
              SELECT 1
                FROM dispatch_scm_po_splits retired_split
               WHERE retired_split.split_po_id = po.netsuite_id
                 AND retired_split.status = 'cancelled'
            )
         UNION
         SELECT split_po_ref AS tranid FROM dispatch_scm_po_splits
          WHERE lower(split_po_ref) = lower($1)
            AND split_po_id <> $2
            AND status = 'active'`,
        [normalizedRef, po.netsuite_id]
      );
      if (existing.rowCount) throw new Error(`PO ref ${normalizedRef} already exists.`);
    }
    await query(
      `UPDATE purchase_orders
          SET dispatch_ref = NULLIF($2, ''),
              dispatch_ref_updated_at = CASE WHEN COALESCE(dispatch_ref, '') IS DISTINCT FROM $2 THEN now() ELSE dispatch_ref_updated_at END,
              dispatch_ref_updated_by = CASE WHEN COALESCE(dispatch_ref, '') IS DISTINCT FROM $2 THEN $3 ELSE dispatch_ref_updated_by END,
              synced_at = now(),
              status_updated_at = now()
        WHERE netsuite_id = $1
          AND COALESCE(dispatch_ref, '') IS DISTINCT FROM $2`,
      [po.netsuite_id, normalizedRef, updatedBy || null]
    );
    const scheduleUpdate = await query(
      `UPDATE scm_transport_schedule s
          SET order_ref = $2,
              packing_slip_ref = NULLIF($3, ''),
              updated_by = $4,
              updated_at = GREATEST(clock_timestamp(), s.updated_at + interval '1 microsecond')
        WHERE s.order_kind = 'PO'
          AND lower(s.order_ref) = lower($1)
          AND (
            s.order_ref IS DISTINCT FROM $2
            OR s.packing_slip_ref IS DISTINCT FROM NULLIF($3, '')
          )
          AND NOT EXISTS (
            SELECT 1
              FROM scm_transport_schedule duplicate
             WHERE duplicate.order_kind = 'PO'
               AND lower(duplicate.order_ref) = lower($2)
               AND duplicate.id <> s.id
          )
        RETURNING to_char(
          updated_at AT TIME ZONE 'UTC',
          'YYYY-MM-DD"T"HH24:MI:SS.US"Z"'
        ) AS concurrency_updated_at`,
      [oldVisibleRef, newVisibleRef, normalizedRef, updatedBy || null]
    );
    const snapshotUpdate = oldVisibleRef !== newVisibleRef
      ? await updateDispatchSnapshotsForRef(query, { oldRef: oldVisibleRef, newRef: newVisibleRef })
      : { planIds: [] };
    return {
      poId: po.netsuite_id,
      poRef: po.tranid,
      oldDisplayRef: oldVisibleRef,
      dispatchRef: normalizedRef,
      displayRef: newVisibleRef,
      updatedPlans: snapshotUpdate.planIds,
      scheduleUpdatedAt: scheduleUpdate.rows[0]?.concurrency_updated_at || null
    };
  });
}

export async function updateScmPurchaseOrderSplitDestination({
  splitPoRef = "",
  destinationLocationId = null,
  updatedBy = "",
  expectedUpdatedAt = undefined,
  expectedSplitRevision = undefined
} = {}) {
  const ref = String(splitPoRef || "").trim();
  if (!ref) throw new Error("Split PO ref is required.");
  const nextLocationId = normalizeScmDestinationLocationId(destinationLocationId);
  if (!nextLocationId) throw new Error("Destination yard is required.");
  const nextLocationText = locationTextFromId(nextLocationId);
  return withTransaction(async () => {
    const splitResult = await query(
      `SELECT s.*, po.destination_location_id, po.destination_location
         FROM dispatch_scm_po_splits s
         INNER JOIN purchase_orders po ON po.netsuite_id = s.split_po_id
        WHERE lower(s.split_po_ref) = lower($1)
          AND s.status = 'active'
        LIMIT 1
        FOR UPDATE OF s, po`,
      [ref]
    );
    const split = splitResult.rows[0];
    if (!split) throw new Error(`SCM split ${ref} was not found.`);
    await assertScmPurchaseOrderSplitMutable(query, split, {
      action: "change the destination of",
      expectedRevision: expectedSplitRevision
    });
    if (expectedUpdatedAt === undefined) {
      throw Object.assign(new Error("Refresh this split PO before changing its destination."), {
        status: 409,
        code: "SCM_SCHEDULE_STALE"
      });
    }
    const scheduleRevision = await query(
      `SELECT updated_at,
              to_char(updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS concurrency_updated_at
         FROM scm_transport_schedule
        WHERE order_kind = 'PO'
          AND lower(order_ref) = lower($1)
        FOR UPDATE`,
      [split.split_po_ref]
    );
    const currentRevision = scheduleRevision.rows[0]?.concurrency_updated_at || null;
    const expectedRevision = expectedUpdatedAt === null || expectedUpdatedAt === ""
      ? null
      : String(expectedUpdatedAt);
    const exactRevision = expectedRevision !== null
      && /\.\d{4,}(?:Z|[+-]\d{2}:?\d{2})$/i.test(expectedRevision);
    const millisecondRevisionMatches = expectedRevision !== null
      && Number.isFinite(Date.parse(currentRevision))
      && Number.isFinite(Date.parse(expectedRevision))
      && new Date(currentRevision).getTime() === new Date(expectedRevision).getTime();
    const revisionMatches = currentRevision === null
      ? expectedRevision === null
      : exactRevision
        ? currentRevision === expectedRevision
        : millisecondRevisionMatches;
    if (!revisionMatches) {
      throw Object.assign(new Error("This split PO changed after it was opened. Refresh and try again."), {
        status: 409,
        code: "SCM_SCHEDULE_STALE"
      });
    }
    const activity = await query(
      `SELECT COUNT(*)::int AS count
         FROM purchase_order_lines
        WHERE purchase_order_id = $1
          AND (
            COALESCE(received_pallet_qty, 0) > 0
            OR COALESCE(received_layer_qty, 0) > 0
            OR COALESCE(received_section_qty, 0) > 0
            OR COALESCE(received_piece_qty, 0) > 0
            OR COALESCE(netsuite_received_qty, 0) > 0
            OR confirmed_at IS NOT NULL
          )`,
      [split.split_po_id]
    );
    if (Number(activity.rows[0]?.count || 0) > 0) {
      throw new Error(`Cannot change ${ref} destination yard. It already has receiving activity.`);
    }
    await query(
      `UPDATE purchase_orders
          SET destination_location_id = $2,
              destination_location = $3,
              synced_at = now(),
              status_updated_at = now()
        WHERE netsuite_id = $1`,
      [split.split_po_id, nextLocationId, nextLocationText]
    );
    await query(
      `UPDATE purchase_order_lines
          SET location_id = $2,
              location = $3,
              synced_at = now()
        WHERE purchase_order_id = $1`,
      [split.split_po_id, nextLocationId, nextLocationText]
    );
    const scheduleUpdate = await query(
      `INSERT INTO scm_transport_schedule (
         order_kind, order_ref, dropoff_point, updated_by, created_by
       ) VALUES ('PO', $1, $2, $3, $3)
       ON CONFLICT (order_kind, order_ref) DO UPDATE SET
         dropoff_point = EXCLUDED.dropoff_point,
         updated_by = EXCLUDED.updated_by,
         updated_at = GREATEST(clock_timestamp(), scm_transport_schedule.updated_at + interval '1 microsecond')
       RETURNING updated_at,
                 to_char(updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS concurrency_updated_at`,
      [split.split_po_ref, nextLocationText, updatedBy || null]
    );
    await query(
      `UPDATE dispatch_scm_po_splits
          SET details = COALESCE(details, '{}'::jsonb) || $2::jsonb
        WHERE id = $1`,
      [
        split.id,
        JSON.stringify({
          destinationLocationId: nextLocationId,
          destinationLocation: nextLocationText,
          lastDestinationUpdatedAt: new Date().toISOString(),
          lastDestinationUpdatedBy: updatedBy || "",
          previousDestinations: [
            ...(Array.isArray(split.details?.previousDestinations) ? split.details.previousDestinations : []),
            {
              destinationLocationId: split.destination_location_id,
              destinationLocation: split.destination_location || ""
            }
          ]
        })
      ]
    );
    const change = await recordScmPurchaseOrderSplitChange(query, split, {
      expectedRevision: expectedSplitRevision === undefined ? null : Number(expectedSplitRevision),
      eventType: "destination_changed",
      beforeState: {
        destinationLocationId: split.destination_location_id,
        destinationLocation: split.destination_location || ""
      },
      afterState: {
        destinationLocationId: nextLocationId,
        destinationLocation: nextLocationText
      },
      actor: updatedBy
    });
    return {
      splitId: split.id,
      sourcePoRef: split.source_po_ref,
      splitPoRef: split.split_po_ref,
      splitPoId: split.split_po_id,
      oldDestinationLocationId: split.destination_location_id,
      oldDestinationLocation: split.destination_location || "",
      destinationLocationId: nextLocationId,
      destinationLocation: nextLocationText,
      scheduleUpdatedAt: scheduleUpdate.rows[0]?.concurrency_updated_at || scheduleUpdate.rows[0]?.updated_at || null,
      revision: change.revision
    };
  });
}

export async function updateScmPurchaseOrderSplitPickupYard({
  splitPoRef = "",
  pickupPoint = "",
  updatedBy = "",
  expectedRevision = undefined
} = {}) {
  const ref = String(splitPoRef || "").trim();
  const requestedPickup = String(pickupPoint || "").trim();
  if (!ref) throw new Error("Split PO ref is required.");
  if (!requestedPickup) throw new Error("Pickup yard is required.");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const splitResult = await client.query(
      `SELECT s.*, split_po.dispatch_vendor_yard, source_po.tranid AS source_tranid,
              source_po.dispatch_ref AS source_dispatch_ref, source_po.netsuite_id AS source_netsuite_id,
              source_po.vendor_id, source_po.vendor
         FROM dispatch_scm_po_splits s
         INNER JOIN purchase_orders split_po ON split_po.netsuite_id = s.split_po_id
         INNER JOIN purchase_orders source_po ON source_po.netsuite_id = s.source_po_id
        WHERE lower(s.split_po_ref) = lower($1)
          AND s.status = 'active'
        LIMIT 1
        FOR UPDATE OF s, split_po, source_po`,
      [ref]
    );
    const split = splitResult.rows[0];
    if (!split) throw new Error(`SCM split ${ref} was not found.`);
    await assertScmPurchaseOrderSplitMutable(client, split, {
      action: "change the pickup of",
      expectedRevision
    });
    const selected = await resolveScmPurchaseOrderPickupYard(client, {
      tranid: split.source_tranid,
      dispatch_ref: split.source_dispatch_ref,
      netsuite_id: split.source_netsuite_id,
      vendor_id: split.vendor_id,
      vendor: split.vendor
    }, requestedPickup);
    const previousPickup = split.dispatch_vendor_yard || "";
    await client.query(
      `UPDATE purchase_orders
          SET dispatch_vendor_yard = $2,
              dispatch_address = $3,
              dispatch_window_start = $4,
              dispatch_window_end = $5,
              dispatch_instructions = $6,
              dispatch_parse_source = 'manual-scm-po-yard',
              dispatch_parsed_at = now(),
              synced_at = now(),
              status_updated_at = now()
        WHERE netsuite_id = $1`,
      [
        split.split_po_id,
        selected.yard || "",
        selected.address || "",
        selected.windowStart || "",
        selected.windowEnd || "",
        vendorYardInstructions(selected)
      ]
    );
    const scheduleUpdate = await client.query(
      `INSERT INTO scm_transport_schedule (
         order_kind, order_ref, pickup_point, brand, updated_by, created_by
       ) VALUES ('PO', $1, $2, NULLIF($3, ''), $4, $4)
       ON CONFLICT (order_kind, order_ref) DO UPDATE SET
         pickup_point = EXCLUDED.pickup_point,
         brand = COALESCE(scm_transport_schedule.brand, EXCLUDED.brand),
         updated_by = EXCLUDED.updated_by,
         updated_at = GREATEST(clock_timestamp(), scm_transport_schedule.updated_at + interval '1 microsecond')
       RETURNING updated_at,
                 to_char(updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US"Z"') AS concurrency_updated_at`,
      [split.split_po_ref, selected.yard || "", selected.vendor || "", updatedBy || null]
    );
    await client.query(
      `UPDATE dispatch_scm_po_splits
          SET details = COALESCE(details, '{}'::jsonb) || $2::jsonb
        WHERE id = $1`,
      [
        split.id,
        JSON.stringify({
          pickupPoint: selected.yard || "",
          pickupAddress: selected.address || "",
          lastPickupUpdatedAt: new Date().toISOString(),
          lastPickupUpdatedBy: updatedBy || "",
          previousPickups: [
            ...(Array.isArray(split.details?.previousPickups) ? split.details.previousPickups : []),
            previousPickup
          ].filter(Boolean)
        })
      ]
    );
    const change = await recordScmPurchaseOrderSplitChange(client, split, {
      expectedRevision: expectedRevision === undefined ? null : Number(expectedRevision),
      eventType: "pickup_changed",
      beforeState: { pickupPoint: previousPickup },
      afterState: { pickupPoint: selected.yard || "", pickupAddress: selected.address || "" },
      actor: updatedBy
    });
    await client.query("COMMIT");
    return {
      splitId: split.id,
      sourcePoRef: split.source_po_ref,
      splitPoRef: split.split_po_ref,
      splitPoId: split.split_po_id,
      oldPickupPoint: previousPickup,
      pickupPoint: selected.yard || "",
      pickupAddress: selected.address || "",
      scheduleUpdatedAt: scheduleUpdate.rows[0]?.concurrency_updated_at || scheduleUpdate.rows[0]?.updated_at || null,
      revision: change.revision
    };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => null);
    throw error;
  } finally {
    client.release();
  }
}

export async function cancelScmPurchaseOrderSplit({
  splitPoRef = "",
  cancelledBy = "",
  expectedRevision = undefined
} = {}) {
  const ref = String(splitPoRef || "").trim();
  if (!ref) throw new Error("Split PO ref is required.");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const splitResult = await client.query(
      `SELECT *
         FROM dispatch_scm_po_splits
        WHERE lower(split_po_ref) = lower($1)
          AND status = 'active'
        LIMIT 1
        FOR UPDATE`,
      [ref]
    );
    const split = splitResult.rows[0];
    if (!split) throw new Error(`SCM split ${ref} was not found.`);
    await assertScmPurchaseOrderSplitMutable(client, split, {
      action: "unsplit",
      expectedRevision
    });
    const activity = await client.query(
      `SELECT COUNT(*)::int AS count
         FROM purchase_order_lines
        WHERE purchase_order_id = $1
          AND (
            COALESCE(received_pallet_qty, 0) > 0
            OR COALESCE(received_layer_qty, 0) > 0
            OR COALESCE(received_section_qty, 0) > 0
            OR COALESCE(received_piece_qty, 0) > 0
            OR COALESCE(netsuite_received_qty, 0) > 0
            OR confirmed_at IS NOT NULL
          )`,
      [split.split_po_id]
    );
    if (Number(activity.rows[0]?.count || 0) > 0) {
      throw new Error(`Cannot unsplit ${ref}. It already has receiving activity.`);
    }
    const poLinks = await client.query(
      `SELECT COUNT(*)::int AS count
         FROM dispatch_so_po_allocations
        WHERE po_order_id = $1
          AND status = 'active'`,
      [split.split_po_id]
    );
    if (Number(poLinks.rows[0]?.count || 0) > 0) {
      throw new Error(`Cannot unsplit ${ref}. It is linked to sales order shortage allocation.`);
    }
    const snapshotUpdate = await updateDispatchSnapshotsForRef(client, { oldRef: split.split_po_ref, remove: true });
    await client.query(
      `UPDATE purchase_order_lines
          SET netsuite_active = false,
              synced_at = now()
        WHERE purchase_order_id = $1`,
      [split.split_po_id]
    );
    await client.query(
      `UPDATE purchase_orders
          SET netsuite_active = false,
              status_text = COALESCE(status_text, '') || ' (SCM unsplit)',
              synced_at = now(),
              status_updated_at = now()
        WHERE netsuite_id = $1`,
      [split.split_po_id]
    );
    await client.query(
      `UPDATE dispatch_scm_po_splits
          SET status = 'cancelled',
              cancelled_at = now(),
              details = COALESCE(details, '{}'::jsonb) || $2::jsonb
        WHERE id = $1`,
      [
        split.id,
        JSON.stringify({
          cancelledBy: cancelledBy || "",
          cancelledAt: new Date().toISOString()
        })
      ]
    );
    const change = await recordScmPurchaseOrderSplitChange(client, split, {
      expectedRevision: expectedRevision === undefined ? null : Number(expectedRevision),
      eventType: "cancelled",
      beforeState: { status: "active", splitPoRef: split.split_po_ref },
      afterState: { status: "cancelled", splitPoRef: split.split_po_ref },
      actor: cancelledBy
    });
    await client.query("COMMIT");
    for (const plan of snapshotUpdate.plans || []) {notifyDispatchPlanMaintenance(plan);}
    return {
      splitId: split.id,
      sourcePoRef: split.source_po_ref,
      splitPoRef: split.split_po_ref,
      splitPoId: split.split_po_id,
      updatedPlans: snapshotUpdate.planIds,
      revision: change.revision
    };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => null);
    throw error;
  } finally {
    client.release();
  }
}

export async function getScmPurchaseOrderSplitSourceLines(splitPoRef = "") {
  const ref = String(splitPoRef || "").trim();
  if (!ref) throw Object.assign(new Error("Split PO ref is required."), { status: 400 });
  const splitResult = await query(
    `SELECT split.*, child.destination_location_id, child.destination_location
       FROM dispatch_scm_po_splits split
       JOIN purchase_orders child ON child.netsuite_id = split.split_po_id
      WHERE lower(split.split_po_ref) = lower($1)
        AND split.status = 'active'
      LIMIT 1`,
    [ref]
  );
  const split = splitResult.rows[0];
  if (!split) throw Object.assign(new Error(`SCM split ${ref} was not found.`), { status: 404 });
  const conflicts = await scmPurchaseOrderSplitOperationalConflicts(query, split);
  const lineResult = await query(
    `WITH other_split AS (
       SELECT ledger.source_line_id,
              SUM(ledger.pallet_qty) AS pallet_qty,
              SUM(ledger.layer_qty) AS layer_qty,
              SUM(ledger.section_qty) AS section_qty,
              SUM(ledger.piece_qty) AS piece_qty,
              SUM(ledger.sales_qty) AS sales_qty
         FROM dispatch_scm_po_split_lines ledger
         JOIN dispatch_scm_po_splits header ON header.id = ledger.split_id
        WHERE header.status = 'active' AND header.id <> $1
        GROUP BY ledger.source_line_id
     ), blanket_unavailable AS (
       SELECT allocation.source_line_id,
              SUM(CASE
                WHEN allocation.status = 'reserved' THEN allocation.reserved_pallets
                WHEN allocation.status = 'held' THEN allocation.held_pallets
                ELSE 0 END) AS pallet_qty,
              SUM(CASE
                WHEN allocation.status = 'reserved' THEN allocation.reserved_sales_qty
                WHEN allocation.status = 'held' THEN allocation.held_sales_qty
                ELSE 0 END) AS sales_qty
         FROM scm_smart_blanket_allocations allocation
        WHERE allocation.status IN ('reserved', 'held')
        GROUP BY allocation.source_line_id
     )
     SELECT source.*,
            COALESCE(other_split.pallet_qty, 0) + COALESCE(blanket_unavailable.pallet_qty, 0) AS allocated_pallet_qty,
            COALESCE(other_split.layer_qty, 0) AS allocated_layer_qty,
            COALESCE(other_split.section_qty, 0) AS allocated_section_qty,
            COALESCE(other_split.piece_qty, 0) AS allocated_piece_qty,
            COALESCE(other_split.sales_qty, 0) + COALESCE(blanket_unavailable.sales_qty, 0) AS allocated_sales_qty,
            ledger.id AS ledger_id,
            ledger.split_line_id,
            COALESCE(ledger.pallet_qty, 0) AS current_pallet_qty,
            COALESCE(ledger.layer_qty, 0) AS current_layer_qty,
            COALESCE(ledger.section_qty, 0) AS current_section_qty,
            COALESCE(ledger.piece_qty, 0) AS current_piece_qty,
            COALESCE(ledger.sales_qty, 0) AS current_sales_qty,
            child.netsuite_active AS child_active
       FROM purchase_order_lines source
       LEFT JOIN dispatch_scm_po_split_lines ledger
         ON ledger.split_id = $1 AND ledger.source_line_id = source.id
       LEFT JOIN purchase_order_lines child ON child.id = ledger.split_line_id
       LEFT JOIN other_split ON other_split.source_line_id = source.id
       LEFT JOIN blanket_unavailable ON blanket_unavailable.source_line_id = source.id
      WHERE source.purchase_order_id = $2
        AND (source.netsuite_active = true OR ledger.id IS NOT NULL)
      ORDER BY source.line_id NULLS LAST, source.id`,
    [split.id, split.source_po_id]
  );
  const lines = lineResult.rows.map((row) => {
    const maximum = availableUnitSelection(row);
    const current = {
      pallets: positiveQuantity(row.current_pallet_qty),
      layers: positiveQuantity(row.current_layer_qty),
      sections: positiveQuantity(row.current_section_qty),
      pieces: positiveQuantity(row.current_piece_qty),
      salesQty: positiveQuantity(row.current_sales_qty)
    };
    const active = hasRequestedSplitQuantity(current) && row.child_active !== false;
    const availableAdditional = Object.fromEntries(Object.entries(maximum).map(([key, value]) => [
      key,
      roundDispatchQuantity(Math.max(positiveQuantity(value) - positiveQuantity(current[key]), 0))
    ]));
    return {
      sourceLineId: Number(row.id),
      lineId: row.line_id === null ? null : Number(row.line_id),
      netSuiteLineSequence: purchaseOrderNetSuiteLineSequence(row),
      childLineId: row.split_line_id === null ? null : Number(row.split_line_id),
      ledgerId: row.ledger_id === null ? null : Number(row.ledger_id),
      itemId: Number(row.item_id || 0) || null,
      sku: row.sku || row.item_name || "",
      itemName: row.item_name || "",
      description: row.item_description || "",
      unit: row.unit || "",
      itemWeight: positiveQuantity(row.item_weight),
      toPlt: positiveQuantity(row.to_plt),
      toLyr: positiveQuantity(row.to_lyr),
      toSec: positiveQuantity(row.to_sec),
      toPcs: positiveQuantity(row.to_pcs),
      current,
      maximum,
      availableAdditional,
      inSplit: active,
      canAdd: !active && hasRequestedSplitQuantity(maximum)
    };
  }).sort(comparePurchaseOrderNetSuiteLines);
  return {
    split: {
      id: Number(split.id),
      sourcePoId: Number(split.source_po_id),
      sourcePoRef: split.source_po_ref,
      splitPoId: Number(split.split_po_id),
      splitPoRef: split.split_po_ref,
      destinationLocationId: normalizeScmDestinationLocationId(split.destination_location_id),
      destinationLocation: split.destination_location || locationTextFromId(split.destination_location_id),
      revision: Number(split.revision || 1),
      updatedAt: split.updated_at || null,
      locked: Object.values(conflicts).some(Boolean),
      conflicts
    },
    lines
  };
}

async function updateBlanketAllocationForManualSplitLine({
  release,
  split,
  sourceLine,
  childLineId,
  desired,
  updatedBy
}) {
  if (!release) return null;
  let allocationResult = await query(
    `SELECT *
       FROM scm_smart_blanket_allocations
      WHERE release_id = $1 AND source_line_id = $2
      ORDER BY id
      LIMIT 1
      FOR UPDATE`,
    [release.id, sourceLine.id]
  );
  let allocation = allocationResult.rows[0];
  if (!allocation && !hasRequestedSplitQuantity(desired)) return null;
  if (!allocation) {
    let proposalLine = await query(
      `SELECT *
         FROM scm_smart_proposal_lines
        WHERE proposal_id = $1
          AND item_id = $2
          AND destination_location_id = $3
        LIMIT 1
        FOR UPDATE`,
      [release.proposal_id, sourceLine.item_id, split.destination_location_id]
    );
    if (!proposalLine.rowCount) {
      const palletWeight = positiveQuantity(sourceLine.to_plt) > 0
        ? positiveQuantity(sourceLine.item_weight) * positiveQuantity(sourceLine.to_plt)
        : 0;
      proposalLine = await query(
        `INSERT INTO scm_smart_proposal_lines (
           proposal_id, item_id, item_name, item_description, unit,
           required_pallets, proposed_pallets, confirmed_pallets, residual_pallets,
           sales_quantity, pallet_weight_lbs, line_weight_lbs,
           to_plt, to_lyr, to_sec, to_pcs, manual_planning_required, reason,
           destination_location_id, destination_name, added_source, added_by
         ) VALUES (
           $1,$2,$3,$4,$5,$6,$6,$6,0,$7,$8,$9,$10,$11,$12,$13,false,$14::jsonb,
           $15,$16,'manual',$17
         ) RETURNING *`,
        [release.proposal_id, sourceLine.item_id, sourceLine.item_name || sourceLine.sku || "Item",
          sourceLine.item_description || "", sourceLine.unit || "", desired.pallets,
          desired.salesQty, palletWeight, desired.salesQty * positiveQuantity(sourceLine.item_weight),
          sourceLine.to_plt, sourceLine.to_lyr, sourceLine.to_sec, sourceLine.to_pcs,
          JSON.stringify({ manualSplitAdjustment: true, sourcePoRef: split.source_po_ref }),
          split.destination_location_id, split.destination_location || locationTextFromId(split.destination_location_id),
          String(updatedBy || "")]
      );
    }
    allocationResult = await query(
      `INSERT INTO scm_smart_blanket_allocations (
         proposal_id, proposal_line_id, release_id, source_po_id, source_po_ref,
         source_line_id, item_id, destination_location_id, destination_name,
         planned_pallets, planned_sales_qty, released_pallets, released_sales_qty,
         status, split_line_id
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$10,$11,'released',$12)
       RETURNING *`,
      [release.proposal_id, proposalLine.rows[0].id, release.id, split.source_po_id,
        split.source_po_ref, sourceLine.id, sourceLine.item_id, split.destination_location_id,
        split.destination_location || locationTextFromId(split.destination_location_id),
        desired.pallets, desired.salesQty, childLineId]
    );
    return allocationResult.rows[0];
  }
  if (positiveQuantity(allocation.reserved_pallets) > 0.000001
    || positiveQuantity(allocation.reserved_sales_qty) > 0.000001) {
    throw Object.assign(new Error("This Blanket allocation is still reserved and cannot be edited from PO Split."), {
      status: 409,
      code: "SCM_PO_SPLIT_BLANKET_RESERVED"
    });
  }
  const pallets = adjustBlanketSplitAllocation({
    planned: allocation.planned_pallets,
    released: allocation.released_pallets,
    held: allocation.held_pallets,
    cancelled: allocation.cancelled_pallets
  }, desired.pallets - positiveQuantity(allocation.released_pallets));
  const sales = adjustBlanketSplitAllocation({
    planned: allocation.planned_sales_qty,
    released: allocation.released_sales_qty,
    held: allocation.held_sales_qty,
    cancelled: allocation.cancelled_sales_qty
  }, desired.salesQty - positiveQuantity(allocation.released_sales_qty));
  const status = pallets.held > 0.000001 || sales.held > 0.000001
    ? "held"
    : pallets.released > 0.000001 || sales.released > 0.000001
      ? "released"
      : "cancelled";
  const updated = await query(
    `UPDATE scm_smart_blanket_allocations
        SET planned_pallets = $2, planned_sales_qty = $3,
            released_pallets = $4, released_sales_qty = $5,
            held_pallets = $6, held_sales_qty = $7,
            cancelled_pallets = $8, cancelled_sales_qty = $9,
            status = $10, split_line_id = $11, updated_at = now()
      WHERE id = $1
      RETURNING *`,
    [allocation.id, pallets.planned, sales.planned, pallets.released, sales.released,
      pallets.held, sales.held, pallets.cancelled, sales.cancelled, status, childLineId]
  );
  return updated.rows[0];
}

async function refreshBlanketReleaseAfterManualSplitEdit(release, changes = [], updatedBy = "") {
  if (!release) return;
  await query(
    `WITH totals AS (
       SELECT allocation.proposal_line_id,
              SUM(allocation.released_pallets) AS released_pallets,
              SUM(allocation.released_sales_qty) AS released_sales_qty,
              SUM(allocation.held_pallets) AS held_pallets,
              SUM(allocation.cancelled_pallets) AS cancelled_pallets
         FROM scm_smart_blanket_allocations allocation
        WHERE allocation.proposal_id = $1
        GROUP BY allocation.proposal_line_id
     )
     UPDATE scm_smart_proposal_lines line
        SET confirmed_pallets = totals.released_pallets,
            residual_pallets = totals.held_pallets,
            sales_quantity = totals.released_sales_qty,
            line_weight_lbs = totals.released_pallets * COALESCE(line.pallet_weight_lbs, 0),
            vendor_decision = CASE
              WHEN totals.held_pallets > 0 THEN 'hold'
              WHEN totals.released_pallets > 0 THEN 'confirm'
              WHEN totals.cancelled_pallets > 0 THEN 'cancel'
              ELSE line.vendor_decision END,
            updated_at = now()
       FROM totals
      WHERE line.id = totals.proposal_line_id`,
    [release.proposal_id]
  );
  const totals = await query(
    `SELECT COALESCE(SUM(released_pallets), 0) AS released_pallets,
            COALESCE(SUM(held_pallets), 0) AS held_pallets,
            COALESCE(SUM(cancelled_pallets), 0) AS cancelled_pallets
       FROM scm_smart_blanket_allocations
      WHERE release_id = $1`,
    [release.id]
  );
  const released = positiveQuantity(totals.rows[0]?.released_pallets);
  const held = positiveQuantity(totals.rows[0]?.held_pallets);
  const status = held > 0.000001
    ? released > 0.000001 ? "partially_released" : "held"
    : released > 0.000001 ? "released" : "cancelled";
  await query(
    `UPDATE scm_smart_blanket_releases
        SET status = $2,
            finalized_at = CASE WHEN $2 IN ('released', 'cancelled') THEN COALESCE(finalized_at, now()) ELSE finalized_at END,
            finalized_by = CASE WHEN $2 IN ('released', 'cancelled') THEN COALESCE(finalized_by, NULLIF($3, '')) ELSE finalized_by END,
            updated_at = now()
      WHERE id = $1`,
    [release.id, status, String(updatedBy || "")]
  );
  await query(
    `UPDATE scm_smart_proposals
        SET status = CASE
              WHEN $2 = 'released' THEN 'completed'
              WHEN $2 = 'cancelled' THEN 'cancelled'
              ELSE 'order_requested' END,
            vendor_response_status = CASE
              WHEN $2 = 'released' THEN 'confirmed'
              WHEN $2 = 'cancelled' THEN 'cancelled'
              ELSE 'partial' END,
            updated_at = now()
      WHERE id = $1`,
    [release.proposal_id, status]
  );
  await query(
    `INSERT INTO scm_smart_blanket_release_events (release_id, event_type, actor, details)
     VALUES ($1, 'split_adjusted', NULLIF($2, ''), $3::jsonb)`,
    [release.id, String(updatedBy || ""), JSON.stringify({ status, changes })]
  );
}

export async function updateScmPurchaseOrderSplitLines({
  splitPoRef = "",
  lines = [],
  expectedRevision = undefined,
  updatedBy = ""
} = {}) {
  const ref = String(splitPoRef || "").trim();
  if (!ref) throw Object.assign(new Error("Split PO ref is required."), { status: 400 });
  if (!Array.isArray(lines)) throw Object.assign(new Error("Split line desired state is required."), { status: 400 });
  return withTransaction(async () => {
    const splitResult = await query(
      `SELECT split.*, child.destination_location_id, child.destination_location,
              child.netsuite_active AS child_active, source.netsuite_active AS source_active
         FROM dispatch_scm_po_splits split
         JOIN purchase_orders child ON child.netsuite_id = split.split_po_id
         JOIN purchase_orders source ON source.netsuite_id = split.source_po_id
        WHERE lower(split.split_po_ref) = lower($1)
          AND split.status = 'active'
        LIMIT 1
        FOR UPDATE OF split, child, source`,
      [ref]
    );
    const split = splitResult.rows[0];
    if (!split) throw Object.assign(new Error(`SCM split ${ref} was not found.`), { status: 404 });
    await assertNoClosedNetSuiteOrders([split.source_po_ref, split.split_po_ref], "be edited in PO Split");
    if (split.source_active !== true || split.child_active !== true) {
      throw Object.assign(new Error("An inactive PO or split child cannot be edited."), {
        status: 409,
        code: "SCM_PO_SPLIT_INACTIVE"
      });
    }
    await assertScmPurchaseOrderSplitMutable(query, split, {
      action: "edit quantities on",
      expectedRevision,
      requireRevision: true
    });
    const ledgerResult = await query(
      `SELECT ledger.*, child.line_id AS child_line_key
         FROM dispatch_scm_po_split_lines ledger
         JOIN purchase_order_lines child ON child.id = ledger.split_line_id
        WHERE ledger.split_id = $1
        FOR UPDATE OF ledger, child`,
      [split.id]
    );
    const ledgerBySource = new Map(ledgerResult.rows.map((row) => [Number(row.source_line_id), row]));
    const desiredBySource = new Map();
    for (const input of lines) {
      const sourceLineId = Number(input?.sourceLineId ?? input?.source_line_id ?? input?.lineRowId ?? 0);
      if (!Number.isSafeInteger(sourceLineId) || sourceLineId <= 0) {
        throw Object.assign(new Error("Every split line requires a valid source line."), { status: 400 });
      }
      if (desiredBySource.has(sourceLineId)) {
        throw Object.assign(new Error(`Source line ${sourceLineId} appears more than once.`), {
          status: 400,
          code: "SCM_PO_SPLIT_DUPLICATE_SOURCE_LINE"
        });
      }
      desiredBySource.set(sourceLineId, splitLineQuantityPayload(input));
    }
    const activeLedgerSources = ledgerResult.rows
      .filter((row) => hasRequestedSplitQuantity({
        pallets: row.pallet_qty,
        layers: row.layer_qty,
        sections: row.section_qty,
        pieces: row.piece_qty,
        salesQty: row.sales_qty
      }))
      .map((row) => Number(row.source_line_id));
    if (activeLedgerSources.some((sourceLineId) => !desiredBySource.has(sourceLineId))) {
      throw Object.assign(new Error("The desired state omitted an existing split line. Refresh and submit every line, using zero to remove one."), {
        status: 409,
        code: "SCM_PO_SPLIT_DESIRED_STATE_INCOMPLETE"
      });
    }
    if (![...desiredBySource.values()].some(hasRequestedSplitQuantity)) {
      throw Object.assign(new Error("Keep at least one item in the split, or use Unsplit to remove the whole child."), {
        status: 400,
        code: "SCM_PO_SPLIT_EMPTY"
      });
    }
    const sourceIds = [...desiredBySource.keys()];
    const sourceResult = await query(
      `WITH other_split AS (
         SELECT ledger.source_line_id,
                SUM(ledger.pallet_qty) AS pallet_qty,
                SUM(ledger.layer_qty) AS layer_qty,
                SUM(ledger.section_qty) AS section_qty,
                SUM(ledger.piece_qty) AS piece_qty,
                SUM(ledger.sales_qty) AS sales_qty
           FROM dispatch_scm_po_split_lines ledger
           JOIN dispatch_scm_po_splits header ON header.id = ledger.split_id
          WHERE header.status = 'active' AND header.id <> $2
          GROUP BY ledger.source_line_id
       ), blanket_unavailable AS (
         SELECT allocation.source_line_id,
                SUM(CASE WHEN allocation.status = 'reserved' THEN allocation.reserved_pallets
                         WHEN allocation.status = 'held' THEN allocation.held_pallets ELSE 0 END) AS pallet_qty,
                SUM(CASE WHEN allocation.status = 'reserved' THEN allocation.reserved_sales_qty
                         WHEN allocation.status = 'held' THEN allocation.held_sales_qty ELSE 0 END) AS sales_qty
           FROM scm_smart_blanket_allocations allocation
          WHERE allocation.status IN ('reserved', 'held')
          GROUP BY allocation.source_line_id
       )
       SELECT source.*,
              COALESCE(other_split.pallet_qty, 0) + COALESCE(blanket_unavailable.pallet_qty, 0) AS allocated_pallet_qty,
              COALESCE(other_split.layer_qty, 0) AS allocated_layer_qty,
              COALESCE(other_split.section_qty, 0) AS allocated_section_qty,
              COALESCE(other_split.piece_qty, 0) AS allocated_piece_qty,
              COALESCE(other_split.sales_qty, 0) + COALESCE(blanket_unavailable.sales_qty, 0) AS allocated_sales_qty
         FROM purchase_order_lines source
         LEFT JOIN other_split ON other_split.source_line_id = source.id
         LEFT JOIN blanket_unavailable ON blanket_unavailable.source_line_id = source.id
        WHERE source.purchase_order_id = $1
          AND source.id = ANY($3::bigint[])
          AND source.netsuite_active = true
        FOR UPDATE OF source`,
      [split.source_po_id, split.id, sourceIds]
    );
    const sourceById = new Map(sourceResult.rows.map((row) => [Number(row.id), row]));
    if (sourceById.size !== sourceIds.length) {
      throw Object.assign(new Error("One of the requested source PO items is no longer active. Refresh and try again."), {
        status: 409,
        code: "SCM_PO_SPLIT_SOURCE_CHANGED"
      });
    }
    const releaseResult = await query(
      `SELECT * FROM scm_smart_blanket_releases WHERE split_id = $1 LIMIT 1 FOR UPDATE`,
      [split.id]
    );
    const release = releaseResult.rows[0] || null;
    const usedLineKeys = new Set(ledgerResult.rows.map((row) => String(row.child_line_key)));
    const changes = [];
    for (const [sourceLineId, rawDesired] of desiredBySource) {
      const sourceLine = sourceById.get(sourceLineId);
      const ledger = ledgerBySource.get(sourceLineId) || null;
      const current = {
        pallets: positiveQuantity(ledger?.pallet_qty),
        layers: positiveQuantity(ledger?.layer_qty),
        sections: positiveQuantity(ledger?.section_qty),
        pieces: positiveQuantity(ledger?.piece_qty),
        salesQty: positiveQuantity(ledger?.sales_qty)
      };
      const desired = {
        pallets: roundDispatchQuantity(rawDesired.pallets),
        layers: roundDispatchQuantity(rawDesired.layers),
        sections: roundDispatchQuantity(rawDesired.sections),
        pieces: roundDispatchQuantity(rawDesired.pieces),
        salesQty: roundDispatchQuantity(lineSalesQty(sourceLine, {
          ...rawDesired,
          // Converted lines derive sales quantity exclusively from the visible
          // PLT/LYR/SEC/PCS fields. Ignore a stale hidden salesQty supplied by
          // an older client when all converted fields are cleared.
          salesQty: hasConversion(sourceLine) ? 0 : rawDesired.salesQty
        }))
      };
      const maximum = availableUnitSelection(sourceLine);
      for (const key of ["pallets", "layers", "sections", "pieces", "salesQty"]) {
        assertSplitQuantityAvailable({
          current: 0,
          desired: desired[key],
          sourceAvailable: positiveQuantity(maximum[key])
        });
      }
      const active = hasRequestedSplitQuantity(desired);
      let childLineId = ledger?.split_line_id ? Number(ledger.split_line_id) : null;
      if (!childLineId && active) {
        childLineId = syntheticPurchaseOrderId(`scm-po-line:${split.id}:${split.split_po_ref}:${sourceLine.id}:${split.destination_location_id}`);
        const sourceLineKey = String(sourceLine.line_id ?? "");
        const childLineKey = sourceLineKey && !usedLineKeys.has(sourceLineKey)
          ? sourceLine.line_id
          : syntheticPurchaseOrderId(`scm-po-line-key:${split.id}:${split.split_po_ref}:${sourceLine.id}:${split.destination_location_id}`);
        usedLineKeys.add(String(childLineKey));
        await query(
          `INSERT INTO purchase_order_lines (
             id, purchase_order_id, line_id, item_id, item_name, sku, item_description, item_type,
             item_type_text, quantity, unit, location_id, location, pallet_qty, layer_qty,
             section_qty, piece_qty, to_plt, to_lyr, to_sec, to_pcs, received_pallet_qty,
             received_layer_qty, received_section_qty, received_piece_qty, netsuite_received_qty,
             netsuite_active, sync_exception, synced_at, item_weight, sync_exception_at, raw,
             confirmed_at, confirmed_by
           ) VALUES (
             $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,
             0,0,0,0,0,true,null,now(),$22,null,$23::jsonb,null,null
           )`,
          [childLineId, split.split_po_id, childLineKey, sourceLine.item_id, sourceLine.item_name,
            sourceLine.sku, sourceLine.item_description, sourceLine.item_type, sourceLine.item_type_text,
            desired.salesQty, sourceLine.unit, split.destination_location_id,
            split.destination_location || locationTextFromId(split.destination_location_id),
            desired.pallets, desired.layers, desired.sections, desired.pieces,
            sourceLine.to_plt, sourceLine.to_lyr, sourceLine.to_sec, sourceLine.to_pcs,
            sourceLine.item_weight, JSON.stringify({
              scmSplit: true,
              sourcePoRef: split.source_po_ref,
              sourcePoId: split.source_po_id,
              sourceLineId: sourceLine.id,
              ...(purchaseOrderNetSuiteOrderLine(sourceLine)
                ? { orderLine: purchaseOrderNetSuiteOrderLine(sourceLine) }
                : {}),
              ...(purchaseOrderNetSuiteLineSequence(sourceLine) !== null
                ? { lineSequenceNumber: purchaseOrderNetSuiteLineSequence(sourceLine) }
                : {}),
              destinationLocationId: split.destination_location_id,
              manualAdjustment: true
            })]
        );
        await query(
          `INSERT INTO dispatch_scm_po_split_lines (
             split_id, source_line_id, split_line_id, item_id, sku, item_name,
             pallet_qty, layer_qty, section_qty, piece_qty, sales_qty, unit,
             requested_pallet_qty, requested_layer_qty, requested_section_qty,
             requested_piece_qty, requested_sales_qty
           ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$7,$8,$9,$10,$11)`,
          [split.id, sourceLine.id, childLineId, sourceLine.item_id, sourceLine.sku,
            sourceLine.item_name, desired.pallets, desired.layers, desired.sections,
            desired.pieces, desired.salesQty, sourceLine.unit]
        );
      } else if (childLineId) {
        await query(
          `UPDATE purchase_order_lines
              SET quantity = $2, pallet_qty = $3, layer_qty = $4,
                  section_qty = $5, piece_qty = $6, location_id = $7,
                  location = $8, netsuite_active = $9, synced_at = now(),
                  raw = COALESCE(raw, '{}'::jsonb) || $10::jsonb
            WHERE id = $1`,
          [childLineId, desired.salesQty, desired.pallets, desired.layers,
            desired.sections, desired.pieces, split.destination_location_id,
            split.destination_location || locationTextFromId(split.destination_location_id), active,
            JSON.stringify({ manualAdjustment: true, manualAdjustmentAt: new Date().toISOString() })]
        );
        await query(
          `UPDATE dispatch_scm_po_split_lines
              SET pallet_qty = $2, layer_qty = $3, section_qty = $4,
                  piece_qty = $5, sales_qty = $6,
                  requested_pallet_qty = $2, requested_layer_qty = $3,
                  requested_section_qty = $4, requested_piece_qty = $5,
                  requested_sales_qty = $6
            WHERE id = $1`,
          [ledger.id, desired.pallets, desired.layers, desired.sections, desired.pieces, desired.salesQty]
        );
      }
      if (childLineId) {
        await updateBlanketAllocationForManualSplitLine({
          release, split, sourceLine, childLineId, desired, updatedBy
        });
      }
      if (["pallets", "layers", "sections", "pieces", "salesQty"].some((key) =>
        Math.abs(current[key] - desired[key]) > 0.000001)) {
        changes.push({ sourceLineId, childLineId, sku: sourceLine.sku || sourceLine.item_name || "", before: current, after: desired });
      }
    }
    if (!changes.length) {
      throw Object.assign(new Error("No split line quantities changed."), {
        status: 400,
        code: "SCM_PO_SPLIT_NO_CHANGE"
      });
    }
    await query(
      `UPDATE dispatch_scm_po_splits
          SET details = COALESCE(details, '{}'::jsonb) || $2::jsonb
        WHERE id = $1`,
      [split.id, JSON.stringify({
        lastLineAdjustmentAt: new Date().toISOString(),
        lastLineAdjustmentBy: String(updatedBy || ""),
        lastLineAdjustmentCount: changes.length
      })]
    );
    await refreshBlanketReleaseAfterManualSplitEdit(release, changes, updatedBy);
    const change = await recordScmPurchaseOrderSplitChange(query, split, {
      expectedRevision: Number(expectedRevision),
      eventType: "lines_adjusted",
      beforeState: { lines: changes.map((entry) => ({ sourceLineId: entry.sourceLineId, quantities: entry.before })) },
      afterState: { lines: changes.map((entry) => ({ sourceLineId: entry.sourceLineId, quantities: entry.after })) },
      actor: updatedBy
    });
    return {
      splitId: Number(split.id),
      sourcePoRef: split.source_po_ref,
      splitPoRef: split.split_po_ref,
      splitPoId: Number(split.split_po_id),
      revision: change.revision,
      updatedAt: change.updatedAt,
      changes
    };
  });
}

export async function createScmPurchaseOrderSplit({
  sourcePoRef = "",
  newPoRef = "",
  pickupPoint = "",
  destinationLocationId = null,
  status = "Hold",
  remarkOverride = "",
  lines = [],
  createdBy = "",
  details = {},
  blanketReleaseId = null,
  extendSplitId = null
} = {}) {
  const sourceRef = String(sourcePoRef || "").trim();
  const splitRef = String(newPoRef || "").trim();
  if (!sourceRef) throw new Error("Blanket PO is required.");
  if (!splitRef) throw new Error("New PO ref number is required.");
  if (sourceRef.toLowerCase() === splitRef.toLowerCase()) throw new Error("New PO ref must be different from the blanket PO.");
  const splitInitialStatus = normalizeManualScmStatus(status);
  const splitInitialMirrorStatus = ["Queued", "Hold"].includes(splitInitialStatus)
    ? splitInitialStatus
    : "Hold";
  const splitRemarkOverride = normalizeScmScheduleRemarkOverride(remarkOverride);
  const requestedLines = (Array.isArray(lines) ? lines : [])
    .map((line) => ({
      ...line,
      lineRowId: Number(line.lineRowId || line.id || 0),
      destinationLocationId: normalizeScmDestinationLocationId(
        line.destinationLocationId ?? line.destination_location_id ?? destinationLocationId
      ),
      quantities: splitLineQuantityPayload(line)
    }))
    .filter((line) => line.lineRowId && hasRequestedSplitQuantity(line.quantities));
  if (!requestedLines.length) throw new Error("Select at least one PO line quantity to split.");

  return withTransaction(async () => {
    const sourceOrder = await query(
      `SELECT *
         FROM purchase_orders
        WHERE tranid = $1 OR dispatch_ref = $1 OR netsuite_id::text = $1
        ORDER BY CASE WHEN dispatch_ref = $1 THEN 0 ELSE 1 END, netsuite_active DESC, synced_at DESC NULLS LAST
        LIMIT 1
        FOR UPDATE`,
      [sourceRef]
    );
    const source = sourceOrder.rows[0];
    if (!source) throw new Error(`Blanket PO ${sourceRef} was not found.`);
    const splitDestinationLocationId = normalizeScmDestinationLocationId(destinationLocationId)
      || requestedLines.map((line) => line.destinationLocationId).find(Boolean)
      || normalizeScmDestinationLocationId(source.destination_location_id)
      || normalizeScmDestinationLocationId(source.destination_location);
    if (!splitDestinationLocationId) throw new Error("Destination yard is required for the split PO.");
    const splitDestinationLocation = locationTextFromId(splitDestinationLocationId);
    const selectedPickupYard = String(pickupPoint || "").trim()
      ? await resolveScmPurchaseOrderPickupYard(query, source, pickupPoint)
      : null;
    const splitPickupPoint = selectedPickupYard?.yard || source.dispatch_vendor_yard || source.source_location || source.vendor || "";
    const splitPickupAddress = selectedPickupYard?.address || source.dispatch_address || "";
    const splitPickupWindowStart = selectedPickupYard?.windowStart || source.dispatch_window_start || "";
    const splitPickupWindowEnd = selectedPickupYard?.windowEnd || source.dispatch_window_end || "";
    const splitPickupInstructions = selectedPickupYard ? vendorYardInstructions(selectedPickupYard) : source.dispatch_instructions || "";
    const splitPickupParseSource = selectedPickupYard ? "manual-scm-po-yard" : source.dispatch_parse_source || "scm-split";
    const requestedExtensionId = Number(extendSplitId) || null;
    let extendingSplit = null;
    if (requestedExtensionId) {
      const extension = await query(
        `SELECT split.*
           FROM dispatch_scm_po_splits split
           JOIN purchase_orders child ON child.netsuite_id = split.split_po_id
          WHERE split.id = $1
            AND split.source_po_id = $2
            AND split.status = 'active'
          FOR UPDATE OF split, child`,
        [requestedExtensionId, source.netsuite_id]
      );
      extendingSplit = extension.rows[0] || null;
      if (!extendingSplit) throw new Error("The existing Blanket split is no longer active.");
      if (String(extendingSplit.split_po_ref || "").trim().toLowerCase() !== splitRef.toLowerCase()) {
        throw new Error(`Held Blanket quantities must extend the existing split ref ${extendingSplit.split_po_ref}.`);
      }
      const releaseIdentity = Number(extendingSplit.details?.blanketReleaseId);
      if (Number(blanketReleaseId) && releaseIdentity && releaseIdentity !== Number(blanketReleaseId)) {
        throw new Error("The existing Blanket split belongs to another release.");
      }
      const operationalUse = await query(
        `SELECT
           EXISTS (
             SELECT 1
               FROM purchase_order_lines line
              WHERE line.purchase_order_id = $1
                AND (
                  COALESCE(line.received_pallet_qty, 0) > 0
                  OR COALESCE(line.received_layer_qty, 0) > 0
                  OR COALESCE(line.received_section_qty, 0) > 0
                  OR COALESCE(line.received_piece_qty, 0) > 0
                  OR COALESCE(line.netsuite_received_qty, 0) > 0
                  OR line.confirmed_at IS NOT NULL
                )
           ) AS has_receiving_activity,
           EXISTS (
             SELECT 1
               FROM driver_job_records job
              WHERE job.status IN ('in_progress', 'complete')
                AND job.order_refs ? $2
           ) AS has_driver_activity,
           EXISTS (
             SELECT 1
               FROM dispatch_plan_snapshots snapshot
               JOIN dispatch_plans plan ON plan.id = snapshot.plan_id
              WHERE plan.status <> 'cancelled'
                AND snapshot.trucks::text LIKE $3
           ) AS is_scheduled`,
        [extendingSplit.split_po_id, splitRef, `%"${splitRef.replaceAll('"', '\\"')}"%`]
      );
      const use = operationalUse.rows[0] || {};
      if (use.has_receiving_activity || use.has_driver_activity || use.is_scheduled) {
        throw Object.assign(
          new Error(
            `Held quantities cannot extend ${splitRef} after it has been scheduled or used. Remove it from the active dispatch plan before confirming the held quantity, or cancel that held quantity.`
          ),
          {
            status: 409,
            code: "SCM_BLANKET_SPLIT_OPERATIONAL",
            conflicts: {
              receivingActivity: use.has_receiving_activity === true,
              driverActivity: use.has_driver_activity === true,
              scheduled: use.is_scheduled === true
            }
          }
        );
      }
    } else {
      const existing = await query(
        `SELECT COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid) AS tranid
           FROM purchase_orders po
          WHERE lower(COALESCE(NULLIF(po.dispatch_ref, ''), po.tranid)) = lower($1)
            AND NOT EXISTS (
              SELECT 1
                FROM dispatch_scm_po_splits retired_split
               WHERE retired_split.split_po_id = po.netsuite_id
                 AND retired_split.status = 'cancelled'
            )
         UNION
         SELECT split_po_ref AS tranid
           FROM dispatch_scm_po_splits
          WHERE lower(split_po_ref) = lower($1)
            AND status = 'active'`,
        [splitRef]
      );
      if (existing.rowCount) throw new Error(`PO ref ${splitRef} already exists.`);
    }

    const lineIds = requestedLines.map((line) => line.lineRowId);
    const sourceLines = await query(
      `WITH scm_alloc AS (
         SELECT sl.source_line_id,
                SUM(sl.pallet_qty) AS split_pallet_qty,
                SUM(sl.layer_qty) AS split_layer_qty,
                SUM(sl.section_qty) AS split_section_qty,
                SUM(sl.piece_qty) AS split_piece_qty,
                SUM(sl.sales_qty) AS split_sales_qty
           FROM dispatch_scm_po_split_lines sl
           JOIN dispatch_scm_po_splits s ON s.id = sl.split_id
          WHERE s.status = 'active'
          GROUP BY sl.source_line_id
       ), blanket_alloc AS (
         SELECT allocation.source_line_id,
                SUM(CASE WHEN allocation.status = 'reserved' THEN allocation.reserved_pallets ELSE allocation.held_pallets END) AS blanket_pallet_qty,
                SUM(CASE WHEN allocation.status = 'reserved' THEN allocation.reserved_sales_qty ELSE allocation.held_sales_qty END) AS blanket_sales_qty
           FROM scm_smart_blanket_allocations allocation
          WHERE allocation.status IN ('reserved', 'held')
            AND ($3::bigint IS NULL OR allocation.release_id <> $3::bigint)
          GROUP BY allocation.source_line_id
       )
       SELECT l.*,
              COALESCE(sa.split_pallet_qty, 0) + COALESCE(ba.blanket_pallet_qty, 0) AS allocated_pallet_qty,
              COALESCE(sa.split_layer_qty, 0) AS allocated_layer_qty,
              COALESCE(sa.split_section_qty, 0) AS allocated_section_qty,
              COALESCE(sa.split_piece_qty, 0) AS allocated_piece_qty,
              COALESCE(sa.split_sales_qty, 0) + COALESCE(ba.blanket_sales_qty, 0) AS allocated_sales_qty
         FROM purchase_order_lines l
         LEFT JOIN scm_alloc sa ON sa.source_line_id = l.id
         LEFT JOIN blanket_alloc ba ON ba.source_line_id = l.id
        WHERE l.purchase_order_id = $1
          AND l.id = ANY($2::bigint[])
          AND l.netsuite_active = true
        FOR UPDATE OF l`,
      [source.netsuite_id, lineIds, Number(blanketReleaseId) || null]
    );
    const sourceLineById = new Map(sourceLines.rows.map((row) => [Number(row.id), row]));
    const selected = [];
    const selectedQuantityBySourceLine = new Map();
    for (const request of requestedLines) {
      const sourceLine = sourceLineById.get(request.lineRowId);
      if (!sourceLine) throw new Error(`Selected PO line ${request.lineRowId} was not found on ${source.tranid}.`);
      const qtys = request.quantities;
      const salesQty = roundDispatchQuantity(lineSalesQty(sourceLine, qtys));
      const alreadySelected = selectedQuantityBySourceLine.get(request.lineRowId) || {
        pallets: 0,
        layers: 0,
        sections: 0,
        pieces: 0,
        salesQty: 0
      };
      const label = sourceLine.sku || sourceLine.item_name || `line ${sourceLine.line_id || sourceLine.id}`;
      if (hasConversion(sourceLine)) {
        const unitChecks = [
          ["pallet", "pallets", qtys.pallets, "PLT"],
          ["layer", "layers", qtys.layers, "LYR"],
          ["section", "sections", qtys.sections, "SEC"],
          ["piece", "pieces", qtys.pieces, "PCS"]
        ];
        for (const [unit, selectedKey, value, unitLabel] of unitChecks) {
          if (!value) continue;
          const available = Math.max(availableUnitQty(sourceLine, unit) - positiveQuantity(alreadySelected[selectedKey]), 0);
          if (value > available + 0.000001) {
            throw new Error(`${label}: blanket PO only has ${available} ${unitLabel} remaining.`);
          }
        }
      }
      const salesRemaining = Math.max(
        positiveQuantity(sourceLine.quantity) - purchaseOrderReceivedBaseline(sourceLine)
          - positiveQuantity(sourceLine.allocated_sales_qty) - positiveQuantity(alreadySelected.salesQty),
        0
      );
      if (salesQty <= 0) throw new Error(`${label}: selected quantity is zero.`);
      if (salesQty > salesRemaining + 0.000001) {
        throw new Error(`${label}: blanket PO only has ${salesRemaining} ${sourceLine.unit || "UOM"} remaining.`);
      }
      const lineDestinationLocationId = request.destinationLocationId || splitDestinationLocationId;
      const lineDestinationLocation = locationTextFromId(lineDestinationLocationId);
      selected.push({
        sourceLine,
        qtys,
        salesQty,
        destinationLocationId: lineDestinationLocationId,
        destinationLocation: lineDestinationLocation
      });
      selectedQuantityBySourceLine.set(request.lineRowId, {
        pallets: roundDispatchQuantity(positiveQuantity(alreadySelected.pallets) + positiveQuantity(qtys.pallets)),
        layers: roundDispatchQuantity(positiveQuantity(alreadySelected.layers) + positiveQuantity(qtys.layers)),
        sections: roundDispatchQuantity(positiveQuantity(alreadySelected.sections) + positiveQuantity(qtys.sections)),
        pieces: roundDispatchQuantity(positiveQuantity(alreadySelected.pieces) + positiveQuantity(qtys.pieces)),
        salesQty: roundDispatchQuantity(positiveQuantity(alreadySelected.salesQty) + salesQty)
      });
    }

    let splitOrderId = extendingSplit?.split_po_id || null;
    let split = extendingSplit;
    if (!split) {
      const splitIdentity = await query(
        `SELECT nextval(pg_get_serial_sequence('dispatch_scm_po_splits', 'id'))::bigint AS id`
      );
      const splitHeaderId = splitIdentity.rows[0]?.id;
      if (!splitHeaderId) throw new Error("Unable to reserve the SCM split identity.");
      splitOrderId = syntheticPurchaseOrderId(`scm-po:${source.netsuite_id}:${splitRef}:${splitHeaderId}`);
      await query(
        `INSERT INTO purchase_orders (
           netsuite_id, tranid, trandate, vendor_id, vendor, status, status_text, foreign_total,
           destination_location_id, destination_location, memo, dispatch_vendor_yard, dispatch_address,
           dispatch_window_start, dispatch_window_end, dispatch_instructions, receipt_status,
           initial_scm_status,
           netsuite_active, synced_at, source_location_id, source_location, expected_delivery_date,
           dispatch_parse_source, dispatch_note_hash, dispatch_parsed_at, netsuite_missing_at,
           last_item_receipt_id, last_item_receipt_tranid, received_at, status_updated_at,
           dispatch_ref, dispatch_ref_updated_at, dispatch_ref_updated_by
         )
         SELECT
           $1, $2, trandate, vendor_id, vendor, status, status_text, foreign_total,
            $5::bigint, $6::text,
            CONCAT(COALESCE(memo, ''), CASE WHEN COALESCE(memo, '') = '' THEN '' ELSE E'\n' END, 'SCM split from ', tranid),
            $7::text, $8::text,
           $9::text, $10::text, $11::text, receipt_status,
           $13::text,
           true, now(), source_location_id, source_location, expected_delivery_date,
           $12::text, dispatch_note_hash, now(), null,
           null, null, null, now(),
            $2, now(), $4
           FROM purchase_orders
          WHERE netsuite_id = $3`,
        [
          splitOrderId,
          splitRef,
          source.netsuite_id,
          createdBy || null,
          splitDestinationLocationId,
          splitDestinationLocation,
          splitPickupPoint,
          splitPickupAddress,
          splitPickupWindowStart,
          splitPickupWindowEnd,
          splitPickupInstructions,
          splitPickupParseSource,
          splitInitialMirrorStatus
        ]
      );

      const splitHeader = await query(
        `INSERT INTO dispatch_scm_po_splits (
           id, source_po_id, source_po_ref, split_po_id, split_po_ref, created_by, details
         ) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)
         RETURNING *`,
        [
          splitHeaderId,
          source.netsuite_id,
          source.tranid,
          splitOrderId,
          splitRef,
          createdBy,
          JSON.stringify({
            ...(details || {}),
            pickupPoint: splitPickupPoint,
            pickupAddress: splitPickupAddress,
            destinationLocationId: splitDestinationLocationId,
            destinationLocation: splitDestinationLocation
          })
        ]
      );
      split = splitHeader.rows[0];
    }
    const splitSchedule = await query(
      `INSERT INTO scm_transport_schedule (
         order_kind, order_ref, pickup_point, dropoff_point, brand, packing_slip_ref,
         status, remark_override, updated_by, created_by
       ) VALUES (
         'PO', $1, NULLIF($2, ''), NULLIF($3, ''), NULLIF($4, ''), $1,
         $5, NULLIF($6, ''), $7, $7
       )
       ON CONFLICT (order_kind, order_ref) DO UPDATE SET
         pickup_point = COALESCE(EXCLUDED.pickup_point, scm_transport_schedule.pickup_point),
         dropoff_point = COALESCE(NULLIF(scm_transport_schedule.dropoff_point, ''), EXCLUDED.dropoff_point),
         brand = COALESCE(scm_transport_schedule.brand, EXCLUDED.brand),
         packing_slip_ref = COALESCE(NULLIF(scm_transport_schedule.packing_slip_ref, ''), EXCLUDED.packing_slip_ref),
         status = CASE WHEN $8::boolean THEN scm_transport_schedule.status ELSE EXCLUDED.status END,
         remark_override = CASE WHEN $8::boolean THEN scm_transport_schedule.remark_override ELSE EXCLUDED.remark_override END,
         updated_by = EXCLUDED.updated_by,
         updated_at = now()
       RETURNING status, remark_override`,
      [
        splitRef,
        splitPickupPoint,
        splitDestinationLocation,
        selectedPickupYard?.vendor || "",
        splitInitialStatus,
        splitRemarkOverride || "",
        createdBy || null,
        Boolean(extendingSplit)
      ]
    );
    const createdLines = [];
    const existingChildLines = await query(
      `SELECT ledger.id AS ledger_id, ledger.source_line_id, ledger.split_line_id,
              child.location_id, child.line_id
         FROM dispatch_scm_po_split_lines ledger
         JOIN purchase_order_lines child ON child.id = ledger.split_line_id
        WHERE ledger.split_id = $1
        FOR UPDATE OF ledger, child`,
      [split.id]
    );
    const existingChildBySourceDestination = new Map(existingChildLines.rows.map((row) => [
      `${row.source_line_id}:${normalizeScmDestinationLocationId(row.location_id)}`,
      row
    ]));
    const usedChildLineKeys = new Set(existingChildLines.rows.map((row) => String(row.line_id)));
    for (const selection of selected) {
      const sourceLine = selection.sourceLine;
      const qtys = selection.qtys;
      const childLineIdentity = `${sourceLine.id}:${selection.destinationLocationId}`;
      const existingChild = existingChildBySourceDestination.get(childLineIdentity);
      if (existingChild) {
        const extended = await query(
          `UPDATE purchase_order_lines
              SET quantity = COALESCE(quantity, 0) + $2,
                  pallet_qty = COALESCE(pallet_qty, 0) + $3,
                  layer_qty = COALESCE(layer_qty, 0) + $4,
                  section_qty = COALESCE(section_qty, 0) + $5,
                  piece_qty = COALESCE(piece_qty, 0) + $6,
                  synced_at = now(),
                  raw = COALESCE(raw, '{}'::jsonb) || jsonb_build_object(
                    'blanketExtension', true,
                    'blanketExtensionAt', now(),
                    'blanketReleaseId', $7::bigint
                  )
            WHERE id = $1
            RETURNING *`,
          [existingChild.split_line_id, selection.salesQty,
            hasConversion(sourceLine) ? qtys.pallets : 0,
            hasConversion(sourceLine) ? qtys.layers : 0,
            hasConversion(sourceLine) ? qtys.sections : 0,
            hasConversion(sourceLine) ? qtys.pieces : 0,
            Number(blanketReleaseId) || null]
        );
        await query(
          `UPDATE dispatch_scm_po_split_lines
              SET pallet_qty = pallet_qty + $2,
                  layer_qty = layer_qty + $3,
                  section_qty = section_qty + $4,
                  piece_qty = piece_qty + $5,
                  sales_qty = sales_qty + $6,
                  requested_pallet_qty = COALESCE(requested_pallet_qty, 0) + $2,
                  requested_layer_qty = COALESCE(requested_layer_qty, 0) + $3,
                  requested_section_qty = COALESCE(requested_section_qty, 0) + $4,
                  requested_piece_qty = COALESCE(requested_piece_qty, 0) + $5,
                  requested_sales_qty = COALESCE(requested_sales_qty, 0) + $6
            WHERE id = $1`,
          [existingChild.ledger_id,
            hasConversion(sourceLine) ? qtys.pallets : 0,
            hasConversion(sourceLine) ? qtys.layers : 0,
            hasConversion(sourceLine) ? qtys.sections : 0,
            hasConversion(sourceLine) ? qtys.pieces : 0,
            selection.salesQty]
        );
        createdLines.push({ ...extended.rows[0], source_line_id: sourceLine.id });
        continue;
      }
      const splitLineId = syntheticPurchaseOrderId(`scm-po-line:${split.id}:${splitRef}:${childLineIdentity}`);
      const originalLineKey = Number(sourceLine.line_id);
      const childLineKey = !usedChildLineKeys.has(String(originalLineKey))
        ? sourceLine.line_id
        : syntheticPurchaseOrderId(`scm-po-line-key:${split.id}:${splitRef}:${childLineIdentity}`);
      usedChildLineKeys.add(String(childLineKey));
      const inserted = await query(
        `INSERT INTO purchase_order_lines (
           id, purchase_order_id, line_id, item_id, item_name, sku, item_description, item_type,
           item_type_text, quantity, unit, location_id, location, pallet_qty, layer_qty,
           section_qty, piece_qty, to_plt, to_lyr, to_sec, to_pcs, received_pallet_qty,
           received_layer_qty, received_section_qty, received_piece_qty, netsuite_received_qty,
           netsuite_active, sync_exception, synced_at, item_weight, sync_exception_at, raw,
           confirmed_at, confirmed_by
         ) VALUES (
           $1, $2, $3, $4, $5, $6, $7, $8,
           $9, $10, $11, $12, $13, $14, $15,
           $16, $17, $18, $19, $20, $21, 0,
           0, 0, 0, 0,
           true, null, now(), $22, null, $23::jsonb,
           null, null
         )
         RETURNING *`,
        [
          splitLineId,
          splitOrderId,
          childLineKey,
          sourceLine.item_id,
          sourceLine.item_name,
          sourceLine.sku,
          sourceLine.item_description,
          sourceLine.item_type,
          sourceLine.item_type_text,
          selection.salesQty,
          sourceLine.unit,
          selection.destinationLocationId,
          selection.destinationLocation,
          hasConversion(sourceLine) ? qtys.pallets : 0,
          hasConversion(sourceLine) ? qtys.layers : 0,
          hasConversion(sourceLine) ? qtys.sections : 0,
          hasConversion(sourceLine) ? qtys.pieces : 0,
          sourceLine.to_plt,
          sourceLine.to_lyr,
          sourceLine.to_sec,
          sourceLine.to_pcs,
          sourceLine.item_weight,
          JSON.stringify({
            scmSplit: true,
            sourcePoRef: source.tranid,
            sourcePoId: source.netsuite_id,
            sourceLineId: sourceLine.id,
            sourceLineKey: sourceLine.line_id,
            ...(purchaseOrderNetSuiteOrderLine(sourceLine)
              ? { orderLine: purchaseOrderNetSuiteOrderLine(sourceLine) }
              : {}),
            ...(purchaseOrderNetSuiteLineSequence(sourceLine) !== null
              ? { lineSequenceNumber: purchaseOrderNetSuiteLineSequence(sourceLine) }
              : {}),
            destinationLocationId: selection.destinationLocationId,
            destinationLocation: selection.destinationLocation,
            selected: qtys
          })
        ]
      );
      const splitLine = inserted.rows[0];
      createdLines.push({ ...splitLine, source_line_id: sourceLine.id });
      await query(
        `INSERT INTO dispatch_scm_po_split_lines (
           split_id, source_line_id, split_line_id, item_id, sku, item_name,
           pallet_qty, layer_qty, section_qty, piece_qty, sales_qty, unit,
           requested_pallet_qty, requested_layer_qty, requested_section_qty,
           requested_piece_qty, requested_sales_qty
         ) VALUES (
           $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12,
           $7, $8, $9, $10, $11
         )`,
        [
          split.id,
          sourceLine.id,
          splitLine.id,
          sourceLine.item_id,
          sourceLine.sku,
          sourceLine.item_name,
          hasConversion(sourceLine) ? qtys.pallets : 0,
          hasConversion(sourceLine) ? qtys.layers : 0,
          hasConversion(sourceLine) ? qtys.sections : 0,
          hasConversion(sourceLine) ? qtys.pieces : 0,
          selection.salesQty,
          sourceLine.unit
        ]
      );
    }
    return {
      split: {
        id: split.id,
        sourcePoRef: source.tranid,
        sourcePoId: source.netsuite_id,
        splitPoRef: splitRef,
        splitPoId: splitOrderId,
        destinationLocationId: splitDestinationLocationId,
        destinationLocation: splitDestinationLocation,
        pickupPoint: splitPickupPoint,
        pickupAddress: splitPickupAddress,
        status: splitSchedule.rows[0]?.status || splitInitialStatus,
        remarkOverride: splitSchedule.rows[0]?.remark_override || "",
        createdAt: split.created_at
      },
      lines: createdLines.map((line) => ({
        id: line.id,
        lineId: line.line_id,
        itemId: line.item_id,
        sku: line.sku || line.item_name,
        itemName: line.item_name,
        sourceLineId: Number(line.source_line_id),
        quantity: positiveQuantity(line.quantity),
        unit: line.unit || "",
        pallets: positiveQuantity(line.pallet_qty),
        layers: positiveQuantity(line.layer_qty),
        sections: positiveQuantity(line.section_qty),
        pieces: positiveQuantity(line.piece_qty),
        destinationLocationId: normalizeScmDestinationLocationId(line.location_id),
        destinationLocation: line.location || locationTextFromId(line.location_id)
      }))
    };
  });
}

const MBBS_SPECIAL_ITEM_ID = 2055;

function isMbbsSpecialLine(line = {}) {
  return Number(line.item_id ?? line.itemId) === MBBS_SPECIAL_ITEM_ID;
}

function isSelectableServiceFeeLine(line = {}) {
  return isMbbsSpecialLine(line);
}

function isDispatchOperationalLine(line = {}) {
  if (isMbbsSpecialLine(line)) return true;
  const itemLabel = `${line.sku || ""} ${line.item_name || line.itemName || ""}`.trim();
  const itemType = `${line.item_type || line.itemType || ""} ${line.item_type_text || line.itemTypeText || ""}`.trim();
  if (/delivery\s*(charge|fee)|shipping\s*(charge|fee)|sales\s*credit|discount/i.test(itemLabel)) return false;
  return !/oth\s*charge|other\s*charge|service|discount|description|subtotal|payment|markup/i.test(itemType);
}

function salesQuantityOnlyAvailability(line = {}) {
  const available = availableUnitSelection(line);
  return {
    pallets: 0,
    layers: 0,
    sections: 0,
    pieces: 0,
    salesQty: positiveQuantity(available.salesQty)
  };
}

function normalizedSpecialDescription(value, itemName = "") {
  const normalize = (text) => String(text || "").normalize("NFKC").trim().toLowerCase().replace(/\s+/g, " ");
  const itemLabel = normalize(itemName);
  const parts = String(value || "").normalize("NFKC").split(/\r?\n/).map(normalize).filter(Boolean);
  while (parts.length && [itemLabel, "mbbs-special", "mbbs special"].filter(Boolean).includes(parts[0])) parts.shift();
  return normalize(parts.join(" "))
    .replace(/^mbbs[\s-]*special(?:\s+order)?\s*[:\-–—]?\s*/, "")
    .replace(/\s*([:;,])\s*/g, "$1")
    .trim();
}

function normalizedLinkUnit(value) {
  return String(value || "").normalize("NFKC").trim().toUpperCase().replace(/\s+/g, " ");
}

function lineItemMatches(left, right) {
  if (left.item_id && right.item_id && String(left.item_id) === String(right.item_id)) return true;
  const leftSku = String(left.sku || left.item_name || "").trim().toLowerCase();
  const rightSku = String(right.sku || right.item_name || "").trim().toLowerCase();
  return Boolean(leftSku && rightSku && leftSku === rightSku);
}

function lineUnitMatches(left, right) {
  return normalizedLinkUnit(left.unit) === normalizedLinkUnit(right.unit);
}

function lineMatches(left, right) {
  return lineItemMatches(left, right) && lineUnitMatches(left, right);
}

function allocationDetails(row = {}) {
  const details = row.details;
  if (details && typeof details === "object" && !Array.isArray(details)) return details;
  if (typeof details !== "string") return {};
  try {
    const parsed = JSON.parse(details);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function normalizeAllocationRow(row) {
  const salesQuantityOnly = isMbbsSpecialLine(row);
  const details = allocationDetails(row);
  const directServicePoLines = Array.isArray(details.directServicePoLines)
    ? details.directServicePoLines
    : [];
  const serviceSalesLines = Array.isArray(details.serviceSalesLines)
    ? details.serviceSalesLines
    : [];
  return {
    id: row.id,
    salesOrderId: row.sales_order_id,
    salesOrderRef: row.sales_order_ref,
    salesLineId: row.sales_line_id,
    dispatchTargetRef: row.dispatch_target_ref || row.sales_order_ref,
    dispatchTargetKind: row.dispatch_target_kind || "normal",
    targetLineKey: row.dispatch_target_line_key || "",
    poOrderId: row.po_order_id,
    poOrderRef: row.po_order_ref,
    poLineId: row.po_line_id,
    itemId: row.item_id,
    itemName: row.item_name,
    sku: row.sku,
    pallets: salesQuantityOnly ? 0 : positiveQuantity(row.allocated_pallet_qty),
    layers: salesQuantityOnly ? 0 : positiveQuantity(row.allocated_layer_qty),
    sections: salesQuantityOnly ? 0 : positiveQuantity(row.allocated_section_qty),
    pieces: salesQuantityOnly ? 0 : positiveQuantity(row.allocated_piece_qty),
    salesQty: positiveQuantity(row.allocated_sales_qty),
    salesQuantityOnly,
    status: row.status,
    createdBy: row.created_by,
    createdAt: row.created_at,
    poVendor: row.po_vendor || "",
    poVendorYard: row.po_vendor_yard || "",
    poAddress: row.po_address || "",
    details,
    directServicePoLines,
    serviceSalesLines
  };
}

function dispatchItemLineIdentities(item = {}) {
  return [...new Set([
    item.lineRowId,
    item.sourceLineId,
    item.lineId,
    item.line_id,
    item.id
  ].map((value) => String(value || "").trim()).filter(Boolean))];
}

function allocationMatchesDispatchItem(allocation = {}, item = {}, sourceRefs = []) {
  const key = String(allocation.dispatch_target_line_key || "");
  const identities = dispatchItemLineIdentities(item);
  if (!identities.some((identity) => key.endsWith(`::${identity}`))) return false;
  const sources = sourceRefs.map((value) => String(value || "").trim()).filter(Boolean);
  return !sources.length || sources.some((source) => key.includes(`::${source}::`));
}

function allocatedDispatchPhysicalQuantity(item = {}, field, explicitAllocated, allocatedSalesQty) {
  const explicit = positiveQuantity(explicitAllocated);
  if (!isMbbsSpecialLine(item)) return explicit;
  const totalPhysical = positiveQuantity(item[field]);
  const totalSales = positiveQuantity(item.quantity ?? item.salesQty);
  if (!totalPhysical || !totalSales) return Math.min(totalPhysical || explicit, explicit);
  const salesCoverage = Math.min(positiveQuantity(allocatedSalesQty) / totalSales, 1);
  return Number(Math.min(totalPhysical, Math.max(explicit, totalPhysical * salesCoverage)).toFixed(6));
}

function selectedServiceSalesLines(allocations = []) {
  const byTargetLine = new Map();
  for (const allocation of allocations) {
    for (const line of allocationDetails(allocation).serviceSalesLines || []) {
      const targetLineKey = String(line?.targetLineKey || "").trim();
      if (targetLineKey && !byTargetLine.has(targetLineKey)) {
        byTargetLine.set(targetLineKey, { ...line, targetLineKey });
      }
    }
  }
  return [...byTargetLine.values()];
}

function selectedDirectServicePoLineIds(allocations = []) {
  return new Set(allocations.flatMap((allocation) =>
    (allocationDetails(allocation).directServicePoLines || [])
      .map((line) => String(line?.poLineId || "").trim())
      .filter(Boolean)
  ));
}

function applyTargetPoAllocationsToOrder(order = {}, allocations = []) {
  const serviceSalesLines = selectedServiceSalesLines(allocations);
  const directServicePoLineIds = selectedDirectServicePoLineIds(allocations);
  const applyItems = (candidate) => {
    const sources = [candidate.id, candidate.originalOrderId];
    const childOrderDetails = (candidate.childOrderDetails || []).map(applyItems);
    const items = childOrderDetails.length
      ? childOrderDetails.flatMap((child) => child.items || [])
      : (candidate.items || []).map((item) => {
          const serviceFee = serviceSalesLines.some((line) => allocationMatchesDispatchItem({
            dispatch_target_line_key: line.targetLineKey
          }, item, sources));
          if (serviceFee) {
            return {
              ...item,
              dispatchServiceFee: true,
              poAllocatedPallets: positiveQuantity(item.pallets),
              poAllocatedLayers: positiveQuantity(item.layers),
              poAllocatedSections: positiveQuantity(item.sections),
              poAllocatedPieces: positiveQuantity(item.pieces),
              poAllocatedSalesQty: positiveQuantity(item.quantity ?? item.salesQty)
            };
          }
          const matches = allocations.filter((allocation) => allocationMatchesDispatchItem(allocation, item, sources));
          if (!matches.length) return item;
          const allocatedSalesQty = matches.reduce((sum, row) => sum + positiveQuantity(row.allocated_sales_qty), 0);
          return {
            ...item,
            poAllocatedPallets: allocatedDispatchPhysicalQuantity(
              item,
              "pallets",
              matches.reduce((sum, row) => sum + positiveQuantity(row.allocated_pallet_qty), 0),
              allocatedSalesQty
            ),
            poAllocatedLayers: allocatedDispatchPhysicalQuantity(
              item,
              "layers",
              matches.reduce((sum, row) => sum + positiveQuantity(row.allocated_layer_qty), 0),
              allocatedSalesQty
            ),
            poAllocatedSections: allocatedDispatchPhysicalQuantity(
              item,
              "sections",
              matches.reduce((sum, row) => sum + positiveQuantity(row.allocated_section_qty), 0),
              allocatedSalesQty
            ),
            poAllocatedPieces: allocatedDispatchPhysicalQuantity(
              item,
              "pieces",
              matches.reduce((sum, row) => sum + positiveQuantity(row.allocated_piece_qty), 0),
              allocatedSalesQty
            ),
            poAllocatedSalesQty: allocatedSalesQty
          };
        });
    return { ...candidate, childOrderDetails, items };
  };
  const enriched = applyItems(order);
  const manifestByLocation = new Map();
  for (const allocation of allocations) {
    if (directServicePoLineIds.has(String(allocation.po_line_id || "").trim())) continue;
    const location = allocation.po_vendor_yard || allocation.po_vendor || "";
    if (!location) continue;
    const key = `${allocation.po_order_ref || ""}|${location}`;
    const entry = manifestByLocation.get(key) || {
      poOrderRef: allocation.po_order_ref || "",
      location,
      address: allocation.po_address || "",
      items: []
    };
    const salesQuantityOnly = isMbbsSpecialLine(allocation);
    entry.items.push({
      itemId: allocation.item_id,
      itemName: allocation.item_name,
      sku: allocation.sku,
      unit: allocation.unit || "",
      pallets: salesQuantityOnly ? 0 : positiveQuantity(allocation.allocated_pallet_qty),
      layers: salesQuantityOnly ? 0 : positiveQuantity(allocation.allocated_layer_qty),
      sections: salesQuantityOnly ? 0 : positiveQuantity(allocation.allocated_section_qty),
      pieces: salesQuantityOnly ? 0 : positiveQuantity(allocation.allocated_piece_qty),
      quantity: positiveQuantity(allocation.allocated_sales_qty),
      itemWeight: positiveQuantity(allocation.item_weight)
    });
    manifestByLocation.set(key, entry);
  }
  const poPickupManifest = [...manifestByLocation.values()];
  return {
    ...enriched,
    pickupLocations: uniqueDispatchLocations([
      ...(enriched.pickupLocations || []),
      ...poPickupManifest.map((entry) => entry.location).filter(Boolean)
    ]),
    poPickupManifest
  };
}

export async function enrichDispatchOrdersWithPoTargetAllocations(orders = [], {
  projectUnallocatedPoRefs = [],
  releasedTargetRefs = []
} = {}) {
  if (!orders.length) return orders;
  const forcedPoRefs = new Set((Array.isArray(projectUnallocatedPoRefs) ? projectUnallocatedPoRefs : [])
    .map((value) => String(value || "").trim().toLowerCase())
    .filter(Boolean));
  const refs = [...new Set(orders.flatMap((order) => [
    order?.id,
    order?.originalPoRef,
    order?.dispatchRef,
    order?.sourcePoRef
  ]).map((value) => String(value || "").trim().toLowerCase()).filter(Boolean))];
  const result = await query(
    `SELECT allocation.*, po.vendor AS po_vendor, po.dispatch_vendor_yard AS po_vendor_yard,
            po.dispatch_address AS po_address, po_line.unit, po_line.item_weight
       FROM dispatch_so_po_allocations allocation
       LEFT JOIN purchase_orders po ON po.netsuite_id = allocation.po_order_id
       LEFT JOIN purchase_order_lines po_line ON po_line.id = allocation.po_line_id
      WHERE allocation.status = 'active'
        AND (
          lower(allocation.dispatch_target_ref) = ANY($1::text[])
          OR lower(allocation.po_order_ref) = ANY($1::text[])
        )
      ORDER BY allocation.dispatch_target_ref, allocation.po_order_ref, allocation.id`,
    [refs]
  );
  const byTarget = new Map();
  const byPurchaseOrder = new Map();
  for (const allocation of result.rows) {
    const ref = String(allocation.dispatch_target_ref || allocation.sales_order_ref || "").toLowerCase();
    if (!byTarget.has(ref)) byTarget.set(ref, []);
    byTarget.get(ref).push(allocation);
    const poRef = String(allocation.po_order_ref || "").toLowerCase();
    if (!byPurchaseOrder.has(poRef)) byPurchaseOrder.set(poRef, []);
    byPurchaseOrder.get(poRef).push(allocation);
  }
  return orders.map((order) => {
    const targetAllocations = byTarget.get(String(order?.id || "").toLowerCase()) || [];
    const targetEnriched = targetAllocations.length
      ? applyTargetPoAllocationsToOrder(order, targetAllocations)
      : order;
    if (String(order?.type || "").toUpperCase() !== "PO") return targetEnriched;
    const poRefs = [order.id, order.originalPoRef, order.dispatchRef, order.sourcePoRef]
      .map((value) => String(value || "").trim().toLowerCase())
      .filter(Boolean);
    const poAllocations = [...new Map(poRefs.flatMap((poRef) => byPurchaseOrder.get(poRef) || [])
      .map((allocation) => [String(allocation.id), allocation])).values()];
    const force = poRefs.some((poRef) => forcedPoRefs.has(poRef));
    return projectPurchaseOrderRouteResidual(targetEnriched, poAllocations, {
      force,
      targetRefs: releasedTargetRefs
    });
  });
}

function targetLineAsAllocationRow(line = {}) {
  return {
    id: line.salesLineId,
    line_id: line.lineId,
    item_id: line.itemId,
    sku: line.sku,
    item_name: line.itemName,
    item_description: line.description,
    item_type: line.itemType,
    item_type_text: line.itemTypeText,
    unit: line.unit,
    quantity: line.quantity,
    pallet_qty: line.pallets,
    layer_qty: line.layers,
    section_qty: line.sections,
    piece_qty: line.pieces,
    to_plt: line.toPlt,
    to_lyr: line.toLyr,
    to_sec: line.toSec,
    to_pcs: line.toPcs,
    netsuite_received_qty: 0,
    allocated_pallet_qty: line.poAllocatedPallets,
    allocated_layer_qty: line.poAllocatedLayers,
    allocated_section_qty: line.poAllocatedSections,
    allocated_piece_qty: line.poAllocatedPieces,
    allocated_sales_qty: line.poAllocatedSalesQty
  };
}

export async function getSalesOrderPoAllocationOptions(orderRef, { planDate = "" } = {}) {
  const resolved = await resolveDispatchSalesTarget({ dispatchTargetRef: orderRef, planDate });
  await assertNoClosedNetSuiteOrders(
    [resolved.target.ref, ...(resolved.target.memberRefs || [])],
    "be viewed in Dispatch PO links"
  );
  const operationalTargetLines = resolved.lines.filter(isDispatchOperationalLine);
  const salesLines = operationalTargetLines.map(targetLineAsAllocationRow);
  const itemIds = [...new Set(salesLines.map((line) => line.item_id).filter(Boolean))];
  const itemNames = [...new Set(salesLines.map((line) => String(line.sku || line.item_name || "").trim()).filter(Boolean))];
  const poParams = [itemIds, itemNames];
  const poLines = await query(
    `WITH alloc AS (
       SELECT po_line_id,
              SUM(allocated_pallet_qty) AS allocated_pallet_qty,
              SUM(allocated_layer_qty) AS allocated_layer_qty,
              SUM(allocated_section_qty) AS allocated_section_qty,
              SUM(allocated_piece_qty) AS allocated_piece_qty,
              SUM(allocated_sales_qty) AS allocated_sales_qty
         FROM dispatch_so_po_allocations
        WHERE status = 'active'
        GROUP BY po_line_id
     )
     SELECT l.*,
            COALESCE(NULLIF(o.dispatch_ref, ''), o.tranid) AS po_ref,
            o.tranid AS po_original_ref,
            o.dispatch_ref AS po_dispatch_ref,
            o.vendor AS po_vendor,
            o.dispatch_vendor_yard AS po_vendor_yard,
            o.dispatch_address AS po_address,
            o.status_text AS po_status_text,
            COALESCE(a.allocated_pallet_qty, 0) AS allocated_pallet_qty,
            COALESCE(a.allocated_layer_qty, 0) AS allocated_layer_qty,
            COALESCE(a.allocated_section_qty, 0) AS allocated_section_qty,
            COALESCE(a.allocated_piece_qty, 0) AS allocated_piece_qty,
            COALESCE(a.allocated_sales_qty, 0) AS allocated_sales_qty
       FROM purchase_order_lines l
       JOIN purchase_orders o ON o.netsuite_id = l.purchase_order_id
       LEFT JOIN alloc a ON a.po_line_id = l.id
      WHERE o.netsuite_active = true
        AND (o.status_text ILIKE '%Pending Receipt%' OR o.status_text ILIKE '%Partially Received%')
        AND l.netsuite_active = true
        AND NOT EXISTS (
          SELECT 1
            FROM dispatch_scm_po_split_lines split_line
            JOIN dispatch_scm_po_splits split_header
              ON split_header.id = split_line.split_id
             AND split_header.status = 'active'
           WHERE split_line.source_line_id = l.id
        )
        AND COALESCE(l.item_type, '') IN ('InvtPart', 'NonInvtPart')
        AND (
          (array_length($1::bigint[], 1) IS NOT NULL AND l.item_id = ANY($1::bigint[]))
          OR (array_length($2::text[], 1) IS NOT NULL AND COALESCE(l.sku, l.item_name) = ANY($2::text[]))
          OR (
            l.item_id = 2055
            AND EXISTS (
              SELECT 1
                FROM purchase_order_lines material_line
               WHERE material_line.purchase_order_id = o.netsuite_id
                 AND material_line.netsuite_active = true
                 AND COALESCE(material_line.item_type, '') IN ('InvtPart', 'NonInvtPart')
                 AND (
                   (array_length($1::bigint[], 1) IS NOT NULL AND material_line.item_id = ANY($1::bigint[]))
                   OR (array_length($2::text[], 1) IS NOT NULL AND COALESCE(material_line.sku, material_line.item_name) = ANY($2::text[]))
                 )
                 AND NOT EXISTS (
                   SELECT 1
                     FROM dispatch_scm_po_split_lines material_split_line
                     JOIN dispatch_scm_po_splits material_split_header
                       ON material_split_header.id = material_split_line.split_id
                      AND material_split_header.status = 'active'
                    WHERE material_split_line.source_line_id = material_line.id
                 )
            )
          )
        )
      ORDER BY o.trandate DESC, o.tranid DESC, l.line_id NULLS LAST, l.id`,
    poParams
  );

  const allocations = await query(
    `SELECT a.*, po.vendor AS po_vendor, po.dispatch_vendor_yard AS po_vendor_yard, po.dispatch_address AS po_address
       FROM dispatch_so_po_allocations a
       LEFT JOIN purchase_orders po ON po.netsuite_id = a.po_order_id
      WHERE a.dispatch_target_ref = $1
        AND a.status = 'active'
      ORDER BY a.created_at DESC, a.id DESC`,
    [resolved.target.ref]
  );

  return {
    order: {
      id: resolved.target.ref,
      kind: resolved.target.kind,
      memberRefs: resolved.target.memberRefs,
      customer: resolved.target.customer || "",
      outboundLocation: resolved.target.outboundLocation || "",
      targetSignature: resolved.signature
    },
    salesLines: operationalTargetLines.map((targetLine) => {
      const line = targetLineAsAllocationRow(targetLine);
      const special = isMbbsSpecialLine(line);
      const normalizedDescription = normalizedSpecialDescription(line.item_description, line.item_name || line.sku);
      const lineCandidates = poLines.rows.filter((poLine) =>
        lineMatches(line, poLine)
      ).map((poLine) => ({
        poLineId: poLine.id,
        poRef: poLine.po_ref,
        originalPoRef: poLine.po_original_ref,
        poAliases: [...new Set([
          poLine.po_ref,
          poLine.po_dispatch_ref,
          poLine.po_original_ref
        ].map((value) => String(value || "").trim()).filter(Boolean))],
        descriptionMatch: Boolean(normalizedDescription) && normalizedDescription === normalizedSpecialDescription(poLine.item_description, poLine.item_name || poLine.sku),
        unitMatch: lineUnitMatches(line, poLine),
        exactMatch: !special || (Boolean(normalizedDescription) && normalizedDescription === normalizedSpecialDescription(poLine.item_description, poLine.item_name || poLine.sku) && lineUnitMatches(line, poLine))
      }));
      return {
      id: line.id,
      targetLineKey: targetLine.targetLineKey,
      sourceOrderRef: targetLine.sourceOrderRef,
      lineId: line.line_id,
      itemId: line.item_id,
      sku: line.sku || line.item_name,
      itemName: line.item_name,
      description: line.item_description || "",
      isSpecial: special,
      serviceFeeSelectable: special,
      independentSalesQty: !special && !hasConversion(line) && hasCustomQuantity(line),
      salesQuantityOnly: special,
      poCandidates: lineCandidates,
      required: {
        pallets: positiveQuantity(line.pallet_qty),
        layers: positiveQuantity(line.layer_qty),
        sections: positiveQuantity(line.section_qty),
        pieces: positiveQuantity(line.piece_qty),
        salesQty: positiveQuantity(line.quantity),
        unit: line.unit || ""
      },
      allocated: {
        pallets: positiveQuantity(line.allocated_pallet_qty),
        layers: positiveQuantity(line.allocated_layer_qty),
        sections: positiveQuantity(line.allocated_section_qty),
        pieces: positiveQuantity(line.allocated_piece_qty),
        salesQty: positiveQuantity(line.allocated_sales_qty)
      },
      available: special ? salesQuantityOnlyAvailability(line) : availableUnitSelection(line),
      conversions: {
        pallets: positiveQuantity(line.to_plt),
        layers: positiveQuantity(line.to_lyr),
        sections: positiveQuantity(line.to_sec),
        pieces: positiveQuantity(line.to_pcs)
      }
    }; }),
    poLines: poLines.rows.map((line) => {
      const special = isMbbsSpecialLine(line);
      return {
      id: line.id,
      orderId: line.purchase_order_id,
      poRef: line.po_ref,
      originalPoRef: line.po_original_ref,
      poAliases: [...new Set([
        line.po_ref,
        line.po_dispatch_ref,
        line.po_original_ref
      ].map((value) => String(value || "").trim()).filter(Boolean))],
      vendor: line.po_vendor || "",
      vendorYard: line.po_vendor_yard || "",
      address: line.po_address || "",
      lineId: line.line_id,
      itemId: line.item_id,
      sku: line.sku || line.item_name,
      itemName: line.item_name,
      description: line.item_description || "",
      isSpecial: special,
      salesQuantityOnly: special,
      serviceFeeSelectable: isSelectableServiceFeeLine(line),
      directToCustomerEligible: isSelectableServiceFeeLine(line),
      statusText: line.po_status_text || "",
      required: {
        pallets: positiveQuantity(line.pallet_qty),
        layers: positiveQuantity(line.layer_qty),
        sections: positiveQuantity(line.section_qty),
        pieces: positiveQuantity(line.piece_qty),
        salesQty: positiveQuantity(line.quantity),
        unit: line.unit || ""
      },
      allocated: {
        pallets: positiveQuantity(line.allocated_pallet_qty),
        layers: positiveQuantity(line.allocated_layer_qty),
        sections: positiveQuantity(line.allocated_section_qty),
        pieces: positiveQuantity(line.allocated_piece_qty),
        salesQty: positiveQuantity(line.allocated_sales_qty)
      },
      available: special ? salesQuantityOnlyAvailability(line) : availableUnitSelection(line)
    };
    }),
    allocations: allocations.rows.map(normalizeAllocationRow)
  };
}

async function createSalesOrderPoAllocationWithExecutor(executor, {
  dispatchTargetRef = "", salesOrderRef, targetLineKey = "", salesLineId, poLineId, poRef = "",
  planDate = "", targetSignature = "", quantities = {}, createdBy = ""
} = {}) {
  const resolved = await resolveDispatchSalesTarget({
    dispatchTargetRef: dispatchTargetRef || salesOrderRef,
    planDate
  });
  await assertNoClosedNetSuiteOrders(
    [resolved.target.ref, ...(resolved.target.memberRefs || [])],
    "be linked to a PO in Dispatch"
  );
  if (targetSignature && targetSignature !== resolved.signature) {
    const error = new Error(`${resolved.target.ref} changed while the link window was open. Refresh before linking the PO.`);
    error.status = 409;
    error.code = "DISPATCH_TARGET_CHANGED";
    throw error;
  }
  const targetLine = resolved.lines.find((line) => line.targetLineKey === String(targetLineKey || ""))
    || resolved.lines.find((line) => Number(line.salesLineId) === Number(salesLineId));
  const salesLine = targetLine ? {
    ...targetLineAsAllocationRow(targetLine),
    sales_order_id: targetLine.sourceOrderId,
    sales_order_ref: targetLine.sourceOrderRef
  } : null;
  if (isMbbsSpecialLine(salesLine) && !poLineId) {
    throw new Error("Select the exact PO line for MBBS-Special before connecting quantity.");
  }
  if (!salesLine) throw new Error("Sales order line not found.");
  if (!isDispatchOperationalLine(salesLine)) {
    throw Object.assign(new Error(`${salesLine.sku || salesLine.item_name || "This line"} is not an operational inventory pickup and cannot be linked to a PO.`), {
      status: 400,
      code: "DISPATCH_PO_LINK_NON_OPERATIONAL_LINE"
    });
  }

  const poParams = poLineId
    ? [poLineId]
    : [
        String(poRef || "").trim(),
        salesLine.item_id || null,
        salesLine.sku || salesLine.item_name || "",
        salesLine.unit || ""
      ];
  const poWhere = poLineId
    ? "l.id = $1"
    : `(lower(o.tranid) = lower($1)
        OR lower(COALESCE(NULLIF(o.dispatch_ref, ''), '')) = lower($1)
        OR o.netsuite_id::text = $1)
        AND (
          ($2::bigint IS NOT NULL AND l.item_id = $2::bigint)
          OR COALESCE(l.sku, l.item_name) = $3
        )
        AND UPPER(REGEXP_REPLACE(BTRIM(COALESCE(l.unit, '')), '\\s+', ' ', 'g'))
          = UPPER(REGEXP_REPLACE(BTRIM($4), '\\s+', ' ', 'g'))`;
  const po = await executor.query(
    `WITH alloc AS (
       SELECT po_line_id,
              SUM(allocated_pallet_qty) AS allocated_pallet_qty,
              SUM(allocated_layer_qty) AS allocated_layer_qty,
              SUM(allocated_section_qty) AS allocated_section_qty,
              SUM(allocated_piece_qty) AS allocated_piece_qty,
              SUM(allocated_sales_qty) AS allocated_sales_qty
         FROM dispatch_so_po_allocations
        WHERE status = 'active'
        GROUP BY po_line_id
     )
     SELECT l.*,
            COALESCE(NULLIF(o.dispatch_ref, ''), o.tranid) AS po_order_ref,
            o.tranid AS po_original_ref,
            o.dispatch_ref AS po_dispatch_ref,
            o.status_text, o.vendor, o.dispatch_vendor_yard, o.dispatch_address,
            COALESCE(a.allocated_pallet_qty, 0) AS allocated_pallet_qty,
            COALESCE(a.allocated_layer_qty, 0) AS allocated_layer_qty,
            COALESCE(a.allocated_section_qty, 0) AS allocated_section_qty,
            COALESCE(a.allocated_piece_qty, 0) AS allocated_piece_qty,
            COALESCE(a.allocated_sales_qty, 0) AS allocated_sales_qty
       FROM purchase_order_lines l
       JOIN purchase_orders o ON o.netsuite_id = l.purchase_order_id
       LEFT JOIN alloc a ON a.po_line_id = l.id
      WHERE o.netsuite_active = true
        AND (o.status_text ILIKE '%Pending Receipt%' OR o.status_text ILIKE '%Partially Received%')
        AND ${poWhere}
        AND l.netsuite_active = true
      ORDER BY o.trandate DESC, o.tranid DESC, l.line_id NULLS LAST, l.id
      LIMIT 1`,
    poParams
  );
  const poLine = po.rows[0];
  if (!poLine) throw new Error("Purchase order line not found.");
  const activeSplitChildren = await executor.query(
    `SELECT DISTINCT split_header.split_po_ref
       FROM dispatch_scm_po_split_lines split_line
       JOIN dispatch_scm_po_splits split_header
         ON split_header.id = split_line.split_id
        AND split_header.status = 'active'
      WHERE split_line.source_line_id = $1
      ORDER BY split_header.split_po_ref`,
    [poLine.id]
  );
  if (activeSplitChildren.rowCount) {
    const splitPoRefs = activeSplitChildren.rows.map((row) => row.split_po_ref).filter(Boolean);
    throw Object.assign(
      new Error(
        `${poLine.po_order_ref} has active split ${splitPoRefs.join(", ")}. Link the SO to the exact split PO instead of its source PO.`
      ),
      {
        status: 409,
        code: "DISPATCH_PO_SPLIT_SOURCE_REQUIRES_CHILD",
        splitPoRefs
      }
    );
  }
  await assertNoClosedNetSuiteOrders(
    [poLine.po_order_ref, poLine.po_original_ref],
    "be linked to an SO in Dispatch"
  );
  const requestedPoRef = String(poRef || "").trim().toLowerCase();
  const acceptedPoRefs = new Set([
    poLine.po_order_ref,
    poLine.po_dispatch_ref,
    poLine.po_original_ref,
    poLine.purchase_order_id
  ].map((value) => String(value || "").trim().toLowerCase()).filter(Boolean));
  if (requestedPoRef && !acceptedPoRefs.has(requestedPoRef)) {
    throw new Error("Selected PO line is not part of the entered purchase order.");
  }
  if (!lineItemMatches(salesLine, poLine)) {
    throw Object.assign(new Error("Selected PO line item does not match the SO line item."), {
      status: 400,
      code: "DISPATCH_PO_LINK_ITEM_MISMATCH"
    });
  }
  if (!lineUnitMatches(salesLine, poLine)) {
    const salesUnit = normalizedLinkUnit(salesLine.unit) || "blank";
    const purchaseUnit = normalizedLinkUnit(poLine.unit) || "blank";
    throw Object.assign(
      new Error(`${salesLine.sku || salesLine.item_name || "Item"}: SO UOM ${salesUnit} does not match PO ${poLine.po_order_ref} UOM ${purchaseUnit}.`),
      { status: 400, code: "DISPATCH_PO_LINK_UOM_MISMATCH" }
    );
  }

  const specialSalesQuantityOnly = isMbbsSpecialLine(salesLine);

  const submittedPallets = positiveQuantity(quantities.pallets);
  const submittedLayers = positiveQuantity(quantities.layers);
  const submittedSections = positiveQuantity(quantities.sections);
  const submittedPieces = positiveQuantity(quantities.pieces);
  const pallets = specialSalesQuantityOnly ? 0 : submittedPallets;
  const layers = specialSalesQuantityOnly ? 0 : submittedLayers;
  const sections = specialSalesQuantityOnly ? 0 : submittedSections;
  const pieces = specialSalesQuantityOnly ? 0 : submittedPieces;
  const independentSalesQty = !specialSalesQuantityOnly && !hasConversion(salesLine) && hasCustomQuantity(salesLine);
  const conversionLine = independentSalesQty ? salesLine : hasConversion(salesLine) ? salesLine : poLine;
  let salesQty = roundDispatchQuantity(specialSalesQuantityOnly
    ? positiveQuantity(quantities.salesQty)
    : lineSalesQty(conversionLine, { ...quantities, pallets, layers, sections, pieces }));
  if (specialSalesQuantityOnly && salesQty <= 0) {
    throw Object.assign(
      new Error(`MBBS-Special PO links require Sales Qty in ${salesLine.unit || "the sales UOM"}; PLT/LYR/SEC/PCS are operational display only.`),
      { status: 400, code: "DISPATCH_MBBS_SPECIAL_SALES_QTY_REQUIRED" }
    );
  }
  if (pallets + layers + sections + pieces + salesQty <= 0) throw new Error("Allocation quantity is required.");

  const checks = [
    ["pallet", pallets, "PLT"],
    ["layer", layers, "LYR"],
    ["section", sections, "SEC"],
    ["piece", pieces, "PCS"]
  ];
  const itemLabel = salesLine.sku || salesLine.item_name || poLine.sku || poLine.item_name || "item";
  for (const [unit, value, label] of checks) {
    if (!value) continue;
    const salesAvailable = availableUnitQty(salesLine, unit);
    const poAvailable = availableUnitQty(poLine, unit);
    if (value > salesAvailable) throw new Error(`${itemLabel}: SO open quantity is only ${salesAvailable} ${label}.`);
    if (value > poAvailable) throw new Error(`${itemLabel}: PO ${poLine.po_order_ref} only has ${poAvailable} ${label} available.`);
  }
  const salesRemaining = Math.max(positiveQuantity(salesLine.quantity) - positiveQuantity(salesLine.allocated_sales_qty), 0);
  const poRemaining = Math.max(positiveQuantity(poLine.quantity) - purchaseOrderReceivedBaseline(poLine) - positiveQuantity(poLine.allocated_sales_qty), 0);
  const selectedPhysical = pallets + layers + sections + pieces > 0;
  const fullPhysical = selectedPhysical && checks.every(([unit, value]) => {
    const available = availableUnitQty(salesLine, unit);
    return available <= 0.000001 || value + 0.000001 >= available;
  });
  if (independentSalesQty && selectedPhysical && salesQty <= 0) {
    if (!fullPhysical) throw new Error(`${itemLabel}: enter the sales-unit quantity for a partial manual PLT/LYR/SEC/PCS allocation.`);
    salesQty = salesRemaining;
  }
  if (salesQty > salesRemaining + 0.000001) throw new Error(`${itemLabel}: SO open sales quantity is only ${salesRemaining}.`);
  if (salesQty > poRemaining + 0.000001) throw new Error(`${itemLabel}: PO ${poLine.po_order_ref} only has ${poRemaining} sales quantity available.`);
  salesQty = roundDispatchQuantity(Math.min(salesQty, salesRemaining, poRemaining));
  if (pallets + layers + sections + pieces + salesQty <= 0) throw new Error("Allocation quantity is required.");

  const inserted = await executor.query(
    `INSERT INTO dispatch_so_po_allocations (
       sales_order_id, sales_order_ref, sales_line_id, po_order_id, po_order_ref, po_line_id,
       item_id, item_name, sku, allocated_pallet_qty, allocated_layer_qty, allocated_section_qty,
       allocated_piece_qty, allocated_sales_qty, created_by, details,
       dispatch_target_ref, dispatch_target_kind, dispatch_target_line_key
     ) VALUES (
       $1, $2, $3, $4, $5, $6,
       $7, $8, $9, $10, $11, $12,
       $13, $14, $15, $16::jsonb, $17, $18, $19
     )
     RETURNING *`,
    [
      salesLine.sales_order_id,
      salesLine.sales_order_ref,
      salesLine.id,
      poLine.purchase_order_id,
      poLine.po_order_ref,
      poLine.id,
      salesLine.item_id || poLine.item_id || null,
      salesLine.item_name || poLine.item_name || "",
      salesLine.sku || poLine.sku || salesLine.item_name || "",
      pallets,
      layers,
      sections,
      pieces,
      salesQty,
      createdBy || null,
      JSON.stringify({
        poVendor: poLine.vendor || "",
        poVendorYard: poLine.dispatch_vendor_yard || "",
        poAddress: poLine.dispatch_address || ""
      }),
      resolved.target.ref,
      resolved.target.kind,
      targetLine.targetLineKey
    ]
  );
  return normalizeAllocationRow({
    ...inserted.rows[0],
    po_vendor: poLine.vendor,
    po_vendor_yard: poLine.dispatch_vendor_yard,
    po_address: poLine.dispatch_address
  });
}

export async function createSalesOrderPoAllocation(options = {}) {
  return createSalesOrderPoAllocationWithExecutor({ query }, options);
}

export async function createSalesOrderPoAllocations({
  dispatchTargetRef = "", salesOrderRef, poRef = "", planDate = "", targetSignature = "", lines = [],
  directServicePoLineIds, serviceSalesLineKeys, createdBy = ""
} = {}) {
  const poServiceSelectionProvided = Array.isArray(directServicePoLineIds);
  const salesServiceSelectionProvided = Array.isArray(serviceSalesLineKeys);
  const serviceSelectionProvided = poServiceSelectionProvided || salesServiceSelectionProvided;
  const serviceIds = poServiceSelectionProvided
    ? [...new Set(directServicePoLineIds
        .map(Number)
        .filter((id) => Number.isSafeInteger(id) && id > 0))]
    : [];
  const serviceTargetLineKeys = salesServiceSelectionProvided
    ? [...new Set(serviceSalesLineKeys.map((value) => String(value || "").trim()).filter(Boolean))]
    : [];
  const cleaned = (Array.isArray(lines) ? lines : [])
    .map((line) => ({
      salesLineId: line.salesLineId,
      targetLineKey: line.targetLineKey,
      poLineId: line.poLineId,
      quantities: line.quantities || line
    }))
    .filter((line) => {
      const q = line.quantities || {};
      return positiveQuantity(q.pallets) + positiveQuantity(q.layers) + positiveQuantity(q.sections) + positiveQuantity(q.pieces) + positiveQuantity(q.salesQty) > 0;
    });
  if (poServiceSelectionProvided && cleaned.some((line) => serviceIds.includes(Number(line.poLineId)))) {
    throw Object.assign(new Error("A PO line cannot be linked as material and marked as a service fee in the same request."), {
      status: 400,
      code: "DISPATCH_PO_SERVICE_LINE_CONFLICT"
    });
  }
  if (salesServiceSelectionProvided && cleaned.some((line) => serviceTargetLineKeys.includes(String(line.targetLineKey || "")))) {
    throw Object.assign(new Error("An SO line cannot be linked as material and marked as a service fee in the same request."), {
      status: 400,
      code: "DISPATCH_SO_SERVICE_LINE_CONFLICT"
    });
  }
  if (!cleaned.length && !serviceSelectionProvided) throw new Error("At least one SO item quantity is required.");
  if (!String(poRef || "").trim()) throw new Error("Purchase order number is required.");

  return withTransaction(async () => {
    const executor = { query };
    const created = [];
    let resolvedTarget = null;
    if (!cleaned.length) {
      resolvedTarget = await resolveDispatchSalesTarget({
        dispatchTargetRef: dispatchTargetRef || salesOrderRef,
        planDate
      });
      await assertNoClosedNetSuiteOrders(
        [resolvedTarget.target.ref, ...(resolvedTarget.target.memberRefs || [])],
        "change a Dispatch PO service route"
      );
      if (targetSignature && targetSignature !== resolvedTarget.signature) {
        throw Object.assign(
          new Error(`${resolvedTarget.target.ref} changed while the link window was open. Refresh before linking the PO.`),
          { status: 409, code: "DISPATCH_TARGET_CHANGED" }
        );
      }
    }
    for (const line of cleaned) {
      created.push(await createSalesOrderPoAllocationWithExecutor(executor, {
        dispatchTargetRef: dispatchTargetRef || salesOrderRef,
        salesOrderRef,
        salesLineId: line.salesLineId,
        targetLineKey: line.targetLineKey,
        poLineId: line.poLineId,
        poRef,
        planDate,
        targetSignature,
        quantities: line.quantities,
        createdBy
      }));
    }
    if (serviceSelectionProvided) {
      const targetRef = created[0]?.dispatchTargetRef
        || resolvedTarget?.target?.ref
        || dispatchTargetRef
        || salesOrderRef;
      const requestedRef = String(poRef || "").trim().toLowerCase();
      const existing = await query(
        `SELECT allocation.*, po.vendor AS po_vendor,
                po.dispatch_vendor_yard AS po_vendor_yard,
                po.dispatch_address AS po_address,
                po.tranid AS po_original_ref,
                po.dispatch_ref AS po_dispatch_ref
           FROM dispatch_so_po_allocations allocation
           JOIN purchase_orders po ON po.netsuite_id = allocation.po_order_id
          WHERE allocation.status = 'active'
            AND lower(allocation.dispatch_target_ref) = lower($1)
            AND (
              lower(allocation.po_order_ref) = $2
              OR lower(po.tranid) = $2
              OR lower(COALESCE(NULLIF(po.dispatch_ref, ''), '')) = $2
              OR po.netsuite_id::text = $2
            )
          ORDER BY allocation.id
          FOR UPDATE OF allocation`,
        [targetRef, requestedRef]
      );
      if (!existing.rows.length) {
        throw Object.assign(new Error("Connect at least one material PO line before saving service-fee choices."), {
          status: 400,
          code: "DISPATCH_PO_SERVICE_ROUTE_REQUIRES_LINK"
        });
      }
      const currentDetails = allocationDetails(existing.rows[0]);
      let directServicePoLines = Array.isArray(currentDetails.directServicePoLines)
        ? currentDetails.directServicePoLines
        : [];
      let serviceSalesLines = Array.isArray(currentDetails.serviceSalesLines)
        ? currentDetails.serviceSalesLines
        : [];
      const poOrderId = existing.rows[0].po_order_id;

      if (poServiceSelectionProvided) {
        const selected = serviceIds.length
          ? await query(
            `SELECT l.*, o.netsuite_id AS po_order_id,
                    COALESCE(NULLIF(o.dispatch_ref, ''), o.tranid) AS po_order_ref,
                    o.tranid AS po_original_ref, o.dispatch_ref AS po_dispatch_ref
               FROM purchase_order_lines l
               JOIN purchase_orders o ON o.netsuite_id = l.purchase_order_id
              WHERE l.id = ANY($1::bigint[])
                AND l.netsuite_active = true
                AND o.netsuite_active = true
                AND (o.status_text ILIKE '%Pending Receipt%' OR o.status_text ILIKE '%Partially Received%')
                AND NOT EXISTS (
                  SELECT 1
                    FROM dispatch_scm_po_split_lines split_line
                    JOIN dispatch_scm_po_splits split_header
                      ON split_header.id = split_line.split_id
                     AND split_header.status = 'active'
                   WHERE split_line.source_line_id = l.id
                )
              FOR SHARE OF l, o`,
            [serviceIds]
          )
          : { rows: [] };
        if (selected.rows.length !== serviceIds.length) {
          throw Object.assign(new Error("One or more selected PO service-fee lines are no longer available."), {
            status: 409,
            code: "DISPATCH_PO_SERVICE_LINE_UNAVAILABLE"
          });
        }
        for (const line of selected.rows) {
          const aliases = [line.po_order_ref, line.po_original_ref, line.po_dispatch_ref, line.purchase_order_id]
            .map((value) => String(value || "").trim().toLowerCase())
            .filter(Boolean);
          if (!aliases.includes(requestedRef)
            || String(line.purchase_order_id) !== String(poOrderId)
            || !isSelectableServiceFeeLine(line)) {
            throw Object.assign(new Error("Only an explicitly selected MBBS-Special line from this PO can be marked as a service fee."), {
              status: 400,
              code: "DISPATCH_PO_SERVICE_LINE_INVALID"
            });
          }
        }
        const claimed = serviceIds.length ? await query(
          `SELECT DISTINCT allocation.dispatch_target_ref, line.value->>'poLineId' AS po_line_id
             FROM dispatch_so_po_allocations allocation
             CROSS JOIN LATERAL jsonb_array_elements(
               COALESCE(allocation.details->'directServicePoLines', '[]'::jsonb)
             ) line(value)
            WHERE allocation.status = 'active'
              AND allocation.po_order_id = $1
              AND line.value->>'poLineId' = ANY($2::text[])
              AND lower(allocation.dispatch_target_ref) <> lower($3)`,
          [poOrderId, serviceIds.map(String), targetRef]
        ) : { rows: [] };
        if (claimed.rows.length) {
          throw Object.assign(new Error("A selected PO service-fee line already belongs to another customer order."), {
            status: 409,
            code: "DISPATCH_PO_SERVICE_LINE_ALREADY_LINKED"
          });
        }
        directServicePoLines = selected.rows.map((line) => ({
          poLineId: String(line.id),
          itemId: line.item_id,
          itemName: line.item_name || "",
          sku: line.sku || line.item_name || "",
          description: line.item_description || "",
          unit: line.unit || "",
          quantity: positiveQuantity(line.quantity)
        }));
      }

      if (salesServiceSelectionProvided) {
        if (serviceTargetLineKeys.length) {
          resolvedTarget ||= await resolveDispatchSalesTarget({
            dispatchTargetRef: dispatchTargetRef || salesOrderRef,
            planDate
          });
          const targetLinesByKey = new Map(resolvedTarget.lines.map((line) => [line.targetLineKey, line]));
          const selectedTargetLines = serviceTargetLineKeys.map((key) => targetLinesByKey.get(key));
          if (selectedTargetLines.some((line) => !line)) {
            throw Object.assign(new Error("One or more selected SO service-fee lines changed. Refresh Link PO and try again."), {
              status: 409,
              code: "DISPATCH_SO_SERVICE_LINE_UNAVAILABLE"
            });
          }
          if (selectedTargetLines.some((line) => !isSelectableServiceFeeLine(targetLineAsAllocationRow(line)))) {
            throw Object.assign(new Error("Only an explicitly selected MBBS-Special SO line can be marked as a service fee."), {
              status: 400,
              code: "DISPATCH_SO_SERVICE_LINE_INVALID"
            });
          }
          serviceSalesLines = selectedTargetLines.map((line) => ({
            targetLineKey: line.targetLineKey,
            salesLineId: line.salesLineId,
            sourceOrderRef: line.sourceOrderRef || "",
            itemId: line.itemId,
            itemName: line.itemName || "",
            sku: line.sku || line.itemName || "",
            description: line.description || "",
            unit: line.unit || "",
            quantity: positiveQuantity(line.quantity)
          }));
        } else {
          serviceSalesLines = [];
        }
      }

      await query(
        `UPDATE dispatch_so_po_allocations
            SET details = jsonb_set(
                  jsonb_set(
                    COALESCE(details, '{}'::jsonb),
                    '{directServicePoLines}',
                    $3::jsonb,
                    true
                  ),
                  '{serviceSalesLines}',
                  $4::jsonb,
                  true
                ),
                updated_at = now()
          WHERE status = 'active'
            AND lower(dispatch_target_ref) = lower($1)
            AND po_order_id = $2`,
        [targetRef, poOrderId, JSON.stringify(directServicePoLines), JSON.stringify(serviceSalesLines)]
      );
      for (const allocation of created) {
        allocation.details = {
          ...(allocation.details || {}),
          directServicePoLines,
          serviceSalesLines
        };
        allocation.directServicePoLines = directServicePoLines;
        allocation.serviceSalesLines = serviceSalesLines;
      }
      if (!created.length) {
        return existing.rows.map((row) => normalizeAllocationRow({
          ...row,
          details: {
            ...allocationDetails(row),
            directServicePoLines,
            serviceSalesLines
          }
        }));
      }
    }
    return created;
  });
}

export async function cancelSalesOrderPoAllocation(allocationId, { cancelledBy = "" } = {}) {
  return withTransaction(async () => {
    const current = await query(
      `SELECT sales_order_ref, po_order_ref, dispatch_target_ref
         FROM dispatch_so_po_allocations
        WHERE id = $1
          AND status = 'active'
        FOR UPDATE`,
      [allocationId]
    );
    if (!current.rows[0]) return null;
    await assertNoClosedNetSuiteOrders([
      current.rows[0].sales_order_ref,
      current.rows[0].po_order_ref,
      current.rows[0].dispatch_target_ref
    ], "change a Dispatch PO link");
    const result = await query(
      `UPDATE dispatch_so_po_allocations
          SET status = 'cancelled',
              cancelled_by = $2,
              cancelled_at = now(),
              updated_at = now()
        WHERE id = $1
          AND status = 'active'
        RETURNING *`,
      [allocationId, cancelledBy || null]
    );
    return result.rows[0] ? normalizeAllocationRow(result.rows[0]) : null;
  });
}

function localCoChildSourceYards(child = {}) {
  const raw = child.raw && typeof child.raw === "object" ? child.raw : {};
  const normalized = (values) => uniqueDispatchLocations(values.map(locationTextFromId).filter(Boolean));
  const rawYards = normalized([
    raw.pickup_location,
    raw.outbound_location,
    raw.source_location
  ]);
  if (rawYards.length) return rawYards;
  const originalYards = normalized([
    ...(Array.isArray(child.transitOriginalPickupLocations) ? child.transitOriginalPickupLocations : []),
    child.transitOriginalSourceYard
  ]);
  if (originalYards.length) return originalYards;
  return normalized([
    ...(Array.isArray(child.pickupLocations) ? child.pickupLocations : []),
    child.sourceYard
  ]);
}

function isLocalCoTransportItem(item = {}) {
  const itemName = String(item.sku || item.itemName || item.item_name || "").trim().toUpperCase();
  if (itemName.startsWith("DELIVERY CHARGE") || itemName.startsWith("SALES CREDIT")) return false;
  return positiveQuantity(item.quantity || item.salesQty)
    + positiveQuantity(item.pallets || item.pallet_qty)
    + positiveQuantity(item.layers || item.layer_qty)
    + positiveQuantity(item.sections || item.section_qty)
    + positiveQuantity(item.pieces || item.piece_qty) > 0;
}

function localCoSourceItems(order = {}, fromYard = "") {
  const children = Array.isArray(order.childOrderDetails) ? order.childOrderDetails : [];
  if (!children.length) return (Array.isArray(order.items) ? order.items : []).map(restoreCoSourceRequirement).filter(isLocalCoTransportItem);
  const fromText = locationTextFromId(fromYard);
  const selectedChildren = children.filter((child) => {
    const yards = localCoChildSourceYards(child);
    return !yards.length || yards.some((yard) => dispatchLocationsShareYard(yard, fromText));
  });
  const childItems = selectedChildren.flatMap((child) => (
    Array.isArray(child.items) && child.items.length
      ? child.items
      : Array.isArray(child.raw?.items) ? child.raw.items : []
  )).map(restoreCoSourceRequirement).filter(isLocalCoTransportItem);
  if (!childItems.length) return (Array.isArray(order.items) ? order.items : []).map(restoreCoSourceRequirement).filter(isLocalCoTransportItem);
  const unique = new Map();
  childItems.forEach((item, index) => {
    const key = String(item.lineRowId || item.line_row_id || item.lineId || item.line_id || `${item.itemId || item.item_id || item.sku || "item"}:${index}`);
    if (!unique.has(key)) unique.set(key, item);
  });
  return [...unique.values()];
}

export function upsertLocalCoOrder(options = {}) {
  const order = options.order || {};
  const sourceRef = String(options.sourceOrderRef || order.id || "").trim();
  return withCoSourcePackingHandoff({
    coRef: String(order.transitCo?.id || `CO-${sourceRef}`).trim(),
    sourceOrderRef: sourceRef,
    childRefs: [...(order.childOrders || []), ...(order.childOrderDetails || []).map(child => child.id)],
    fromYard: locationTextFromId(options.fromYard || order.sourceYard || order.pickupLocations?.[0]),
    reactivateCancelled: options.reactivateCancelled === true,
    requestedBy: options.requestedBy || ""
  }, () => upsertLocalCoOrderUnlocked(options));
}

async function upsertLocalCoOrderUnlocked({
  sourceOrderRef,
  fromYard,
  toYard,
  order = {},
  plan = {},
  requestedBy = "",
  reactivateCancelled = false
} = {}) {
  const sourceRef = String(sourceOrderRef || order.id || "").trim();
  const fromText = locationTextFromId(fromYard || order.sourceYard || order.pickupLocations?.[0]);
  const toText = locationTextFromId(toYard || "12441");
  if (!sourceRef) throw new Error("Source order is required for CO.");
  await assertNoClosedNetSuiteOrders([
    sourceRef,
    ...(Array.isArray(order.childOrders) ? order.childOrders : [])
  ], "create or change a local CO in Dispatch");
  if (!fromText || !toText || dispatchLocationsShareYard(fromText, toText)) {
    throw new Error("CO source and destination yard must be different.");
  }
  const coRef = String(order.transitCo?.id || `CO-${sourceRef}`).trim();
  const details = {
    customer: order.customer || "",
    notes: order.notes || `Local transit depot order for ${sourceRef}.`,
    sourceOrderId: sourceRef,
    sourceOrderType: order.sourceOrderType || order.type || "",
    childOrderIds: Array.isArray(order.childOrders) ? order.childOrders : [],
    childOrderDetails: Array.isArray(order.childOrderDetails) ? order.childOrderDetails : [],
    groupAliases: Array.isArray(order.groupAliases) ? order.groupAliases : [],
    weight: order.weight || 0,
    salesQty: order.salesQty || 0
  };
  const hasDispatchAssignment = Boolean(plan.truckPlate || plan.loadName || plan.parkingSpot);
  const inserted = await query(
    `INSERT INTO local_co_orders (
       co_ref, source_order_ref, from_location_id, from_location, to_location_id, to_location,
       status, dispatch_plan_id, dispatch_plan_date, dispatch_truck_plate, dispatch_load_name,
       dispatch_parking_spot, created_by, details
     ) VALUES (
       $1, $2, $3, $4, $5, $6,
       'pending_load', $7, $8::date, $9, $10,
       $11, $12, $13::jsonb
     )
     ON CONFLICT (co_ref) DO UPDATE SET
       source_order_ref = EXCLUDED.source_order_ref,
       from_location_id = EXCLUDED.from_location_id,
       from_location = EXCLUDED.from_location,
       to_location_id = EXCLUDED.to_location_id,
       to_location = EXCLUDED.to_location,
       status = CASE
         WHEN local_co_orders.status = 'cancelled' AND $14::boolean THEN 'pending_load'
         ELSE local_co_orders.status
       END,
       dispatch_plan_id = COALESCE(EXCLUDED.dispatch_plan_id, local_co_orders.dispatch_plan_id),
       dispatch_plan_date = COALESCE(EXCLUDED.dispatch_plan_date, local_co_orders.dispatch_plan_date),
       dispatch_truck_plate = CASE
         WHEN EXCLUDED.dispatch_plan_id IS NULL AND EXCLUDED.dispatch_plan_date IS NULL THEN local_co_orders.dispatch_truck_plate
         ELSE EXCLUDED.dispatch_truck_plate
       END,
       dispatch_load_name = CASE
         WHEN EXCLUDED.dispatch_plan_id IS NULL AND EXCLUDED.dispatch_plan_date IS NULL THEN local_co_orders.dispatch_load_name
         ELSE EXCLUDED.dispatch_load_name
       END,
       dispatch_parking_spot = CASE
         WHEN EXCLUDED.dispatch_plan_id IS NULL AND EXCLUDED.dispatch_plan_date IS NULL THEN local_co_orders.dispatch_parking_spot
         ELSE EXCLUDED.dispatch_parking_spot
       END,
       details = EXCLUDED.details,
       updated_at = now()
     WHERE local_co_orders.status NOT IN ('cancelled', 'completed')
        OR (local_co_orders.status = 'cancelled' AND $14::boolean)
     RETURNING *`,
    [
      coRef,
      sourceRef,
      locationIdFromText(fromText),
      fromText,
      locationIdFromText(toText),
      toText,
      hasDispatchAssignment ? plan.id || null : null,
      hasDispatchAssignment ? plan.planDate || null : null,
      hasDispatchAssignment ? plan.truckPlate || "" : "",
      hasDispatchAssignment ? plan.loadName || "" : "",
      hasDispatchAssignment ? plan.parkingSpot || "" : "",
      requestedBy || null,
      JSON.stringify(details),
      reactivateCancelled === true
    ]
  );
  const co = inserted.rows[0];
  if (!co) {
    const existing = await query(
      `SELECT status
         FROM local_co_orders
        WHERE co_ref = $1`,
      [coRef]
    );
    if (String(existing.rows[0]?.status || "").toLowerCase() === "completed") {
      throw Object.assign(
        new Error(`${coRef} was completed in Driver PWA and cannot be changed or planned again.`),
        { code: "DISPATCH_CO_COMPLETED", status: 409, coRef }
      );
    }
    throw Object.assign(
      new Error(`${coRef} was cancelled. Recreate it explicitly before assigning it to a Dispatch plan.`),
      { code: "DISPATCH_CO_CANCELLED", status: 409, coRef }
    );
  }
  if (!co.delivery_order_id) {
    await query("UPDATE local_co_orders SET delivery_order_id = $2 WHERE id = $1", [co.id, -Number(co.id)]);
    co.delivery_order_id = -Number(co.id);
  }

  const items = localCoSourceItems(order, fromText);
  const activeLineIds = [];
  for (let index = 0; index < items.length; index += 1) {
    const item = items[index] || {};
    const sourceLineId = Number(item.lineId || item.line_id || item.lineRowId || item.line_row_id);
    const lineId = Number.isSafeInteger(sourceLineId) && sourceLineId > 0 && !activeLineIds.includes(sourceLineId)
      ? sourceLineId
      : -(index + 1);
    activeLineIds.push(lineId);
    await query(
      `INSERT INTO local_co_order_lines (
         co_id, line_id, item_id, item_name, item_type, item_type_text, item_description, sku,
         quantity, unit, item_weight, pallet_qty, layer_qty, piece_qty, section_qty, to_plt, to_lyr, to_sec, to_pcs, raw
       ) VALUES (
         $1, $2, $3, $4, COALESCE($5, 'InvtPart'), $6, $7, $8,
         $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20::jsonb
       )
       ON CONFLICT (co_id, line_id) DO UPDATE SET
         item_id = EXCLUDED.item_id,
         item_name = EXCLUDED.item_name,
         item_type = EXCLUDED.item_type,
         item_type_text = EXCLUDED.item_type_text,
         item_description = EXCLUDED.item_description,
         sku = EXCLUDED.sku,
         quantity = EXCLUDED.quantity,
         unit = EXCLUDED.unit,
         item_weight = EXCLUDED.item_weight,
         pallet_qty = EXCLUDED.pallet_qty,
         layer_qty = EXCLUDED.layer_qty,
         piece_qty = EXCLUDED.piece_qty,
         section_qty = EXCLUDED.section_qty,
         to_plt = EXCLUDED.to_plt,
         to_lyr = EXCLUDED.to_lyr,
         to_sec = EXCLUDED.to_sec,
         to_pcs = EXCLUDED.to_pcs,
         raw = EXCLUDED.raw`,
      [
        co.id,
        lineId,
        item.itemId || item.item_id || null,
        item.itemName || item.item_name || item.sku || "",
        item.itemType || item.item_type || "InvtPart",
        item.itemTypeText || item.item_type_text || "Inventory Item",
        item.description || item.itemDescription || item.item_description || "",
        item.sku || item.itemName || item.item_name || "",
        item.quantity || item.salesQty || 0,
        item.unit || "",
        item.itemWeight || item.item_weight || 0,
        item.pallets || item.pallet_qty || 0,
        item.layers || item.layer_qty || 0,
        item.pieces || item.piece_qty || 0,
        item.sections || item.section_qty || 0,
        item.toPlt || item.to_plt || null,
        item.toLyr || item.to_lyr || null,
        item.toSec || item.to_sec || null,
        item.toPcs || item.to_pcs || null,
        JSON.stringify(item)
      ]
    );
  }
  if (activeLineIds.length) {
    await query(
      `DELETE FROM local_co_order_lines
       WHERE co_id = $1
         AND NOT (line_id = ANY($2::bigint[]))
         AND NOT (quantity=0 AND raw ? 'coDirectToRequirement')`,
      [co.id, activeLineIds]
    );
  }
  await reconcileCoDirectToCargo({ coRefs: [coRef], requestedBy });
  return getLocalCoOrder(coRef);
}

export async function cancelLocalCoOrder(coRef, { requestedBy = "" } = {}) {
  return cancelDispatchCoGlobally(coRef, { requestedBy });
}

export async function getLocalCoOrder(coRefOrId) {
  const result = await query(
    `SELECT *
       FROM local_co_orders
      WHERE co_ref = $1 OR delivery_order_id::text = $1 OR id::text = $1`,
    [String(coRefOrId)]
  );
  const co = result.rows[0];
  if (!co) return null;
  const lines = await query(
    `SELECT *
       FROM local_co_order_lines
      WHERE co_id = $1
      ORDER BY line_id, id`,
    [co.id]
  );
  return { ...co, lines: lines.rows };
}

export async function createDispatchOperatorRequest({ requestType, orderRef, sourceOrderType, requestedBy = "", details = {} } = {}) {
  if (!requestType || !orderRef) throw new Error("Request type and order reference are required.");
  await assertNoClosedNetSuiteOrders([orderRef], "create an Operator request");
  const result = await query(
    `INSERT INTO dispatch_operator_requests (
       request_type, order_ref, source_order_type, requested_by, details
     ) VALUES ($1, $2, $3, $4, $5::jsonb)
     RETURNING *`,
    [
      requestType,
      orderRef,
      sourceOrderType || null,
      requestedBy || null,
      JSON.stringify(details || {})
    ]
  );
  return result.rows[0];
}

export async function listDispatchOperatorRequests({ status = "open", locationId = null, orderType = null } = {}) {
  await query(
    `WITH delivery_request_orders AS (
       SELECT netsuite_id, tranid, 'sales_order'::text AS order_type,
              operator_status, outbound_location_id, outbound_location
         FROM sales_orders
       UNION ALL
       SELECT netsuite_id, tranid, 'transfer_order'::text AS order_type,
              outbound_operator_status AS operator_status,
              from_location_id AS outbound_location_id,
              from_location AS outbound_location
         FROM transfer_orders
     )
     UPDATE dispatch_operator_requests r
        SET status = 'resolved',
            resolved_at = now(),
            details = r.details || '{"autoResolved":"order_not_packed"}'::jsonb
       FROM delivery_request_orders d
      WHERE r.status = 'open'
        AND r.request_type = 'unpack_for_split'
        AND (d.tranid = r.order_ref OR d.netsuite_id::text = r.order_ref)
        AND d.operator_status <> 'packed'`
  );

  const params = [status];
  const clauses = ["r.status = $1"];
  if (locationId) {
    params.push(locationId);
    clauses.push(`(d.outbound_location_id = $${params.length} OR d.outbound_location_id IS NULL)`);
  }
  if (orderType) {
    params.push(orderType);
    clauses.push(`(d.order_type = $${params.length} OR d.order_type IS NULL)`);
  }
  clauses.push(`(
    r.request_type <> 'unpack_for_split'
    OR d.operator_status = 'packed'
  )`);
  const result = await query(
    `WITH delivery_request_orders AS (
       SELECT netsuite_id, tranid, 'sales_order'::text AS order_type,
              operator_status, outbound_location_id, outbound_location
         FROM sales_orders
       UNION ALL
       SELECT netsuite_id, tranid, 'transfer_order'::text AS order_type,
              outbound_operator_status AS operator_status,
              from_location_id AS outbound_location_id,
              from_location AS outbound_location
         FROM transfer_orders
     )
     SELECT r.*,
            d.netsuite_id,
            d.tranid,
            d.operator_status,
            d.outbound_location_id,
            d.outbound_location
       FROM dispatch_operator_requests r
       LEFT JOIN delivery_request_orders d
         ON d.tranid = r.order_ref
         OR d.netsuite_id::text = r.order_ref
      WHERE ${clauses.join(" AND ")}
      ORDER BY r.requested_at DESC, r.id DESC
      LIMIT 100`,
    params
  );
  const closed = await listClosedNetSuiteOrders(result.rows.map((row) => row.order_ref));
  const closedRefs = new Set(closed.map((entry) => entry.requestedRef));
  return result.rows.filter((row) => !closedRefs.has(String(row.order_ref || "").trim().toUpperCase()));
}

export async function resolveDispatchOperatorRequestsForOrder(orderRef, operatorId = "") {
  const result = await query(
    `WITH delivery_request_orders AS (
       SELECT netsuite_id, tranid FROM sales_orders
       UNION ALL
       SELECT netsuite_id, tranid FROM transfer_orders
     )
     UPDATE dispatch_operator_requests
        SET status = 'resolved',
            resolved_by = $2,
            resolved_at = now()
      WHERE status = 'open'
        AND (order_ref = $1 OR order_ref IN (
          SELECT tranid FROM delivery_request_orders WHERE netsuite_id::text = $1
        ))
      RETURNING *`,
    [String(orderRef), operatorId || null]
  );
  return result.rows;
}
