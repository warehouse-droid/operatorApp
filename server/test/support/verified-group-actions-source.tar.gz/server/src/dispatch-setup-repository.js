import crypto from "node:crypto";
import { promisify } from "node:util";
import { query, withTransaction } from "./db.js";

export { updateDispatchTruckCapabilities } from "./mbt/dispatch-truck-capability-repository.js";

const scrypt = promisify(crypto.scrypt);

function numberValue(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function normalizedPlate(value) {
  return String(value || "").replace(/\s+/g, "").toUpperCase();
}

function cleanDriver(driver = {}, displayOrder = 0) {
  const login = String(driver.login || "").trim().toLowerCase();
  const name = String(driver.name || "").trim();
  if (!login) throw new Error("Every driver must have a login.");
  if (!name) throw new Error(`Driver ${login} must have a name.`);
  return {
    id: /^\d+$/.test(String(driver.id || "")) ? String(driver.id) : null,
    name,
    license: String(driver.license || "").trim(),
    number: String(driver.number || "").trim(),
    login,
    password: String(driver.password || ""),
    samsaraPrimaryLogin: String(driver.samsaraPrimaryLogin || "").trim(),
    samsaraSecondaryLogin: String(driver.samsaraSecondaryLogin || "").trim(),
    samsaraEnabled: driver.samsaraEnabled === true || driver.connectSamsara === true,
    ownYardFixedMinutes: numberValue(driver.ownYardFixedMinutes ?? driver.loadMinutes, 40),
    vendorFixedMinutes: numberValue(driver.vendorFixedMinutes ?? driver.outsideFixedMinutes ?? driver.unloadMinutes, 35),
    deliveryFixedMinutes: numberValue(driver.deliveryFixedMinutes ?? driver.outsideFixedMinutes ?? driver.unloadMinutes, 35),
    minutesPerPallet: numberValue(driver.minutesPerPallet, 1),
    active: driver.active !== false,
    displayOrder
  };
}

function cleanTruck(truck = {}, displayOrder = 0) {
  const plate = String(truck.plate || "").trim().toUpperCase();
  if (!plate) throw new Error("Every truck must have a plate number.");
  return {
    id: /^\d+$/.test(String(truck.id || "")) ? String(truck.id) : null,
    plate,
    capacityLbs: numberValue(truck.capacityLbs, 48000),
    travelTimePercent: numberValue(truck.travelTimePercent, 0),
    baseYard: String(truck.baseYard || truck.base || "").trim(),
    active: truck.active !== false,
    displayOrder
  };
}

function publicDriver(row) {
  if (!row) return null;
  const ownYardFixedMinutes = numberValue(row.own_yard_fixed_minutes, 40);
  const vendorFixedMinutes = numberValue(row.vendor_fixed_minutes, 35);
  const deliveryFixedMinutes = numberValue(row.delivery_fixed_minutes, 35);
  return {
    id: String(row.id),
    name: row.name,
    license: row.license_class,
    number: row.license_number,
    login: row.login,
    active: row.active !== false,
    password: "",
    passwordConfigured: Boolean(row.password_hash && row.password_salt),
    samsaraPrimaryLogin: row.samsara_primary_login,
    samsaraSecondaryLogin: row.samsara_secondary_login,
    samsaraEnabled: row.samsara_enabled === true,
    ownYardFixedMinutes,
    vendorFixedMinutes,
    deliveryFixedMinutes,
    outsideFixedMinutes: deliveryFixedMinutes,
    minutesPerPallet: numberValue(row.minutes_per_pallet, 1),
    displayOrder: numberValue(row.display_order, 0),
    loadMinutes: ownYardFixedMinutes,
    unloadMinutes: deliveryFixedMinutes
  };
}

function publicTruck(row) {
  if (!row) return null;
  return {
    id: String(row.id),
    plate: row.plate,
    active: row.active !== false,
    capacityLbs: numberValue(row.capacity_lbs, 48000),
    travelTimePercent: numberValue(row.travel_time_percent, 0),
    baseYard: String(row.base_yard || "").trim(),
    displayOrder: numberValue(row.display_order, 0),
    truckType: row.truck_type === "bin" ? "bin" : "flatbed",
    revision: numberValue(row.revision, 1),
    binServiceEnabled: row.truck_type === "bin" && row.bin_service_enabled === true,
    binSlotCapacity: numberValue(row.bin_slot_capacity, 0),
    supportedBinTypeCodes: Array.isArray(row.supported_bin_type_codes)
      ? row.supported_bin_type_codes.map((code) => String(code))
      : []
  };
}

async function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const derived = await scrypt(String(password), salt, 64);
  return { salt, hash: derived.toString("hex") };
}

async function verifyPassword(password, salt, expectedHash) {
  const { hash } = await hashPassword(password, salt);
  const expected = Buffer.from(expectedHash, "hex");
  const actual = Buffer.from(hash, "hex");
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

function assertUnique(values, label) {
  const seen = new Set();
  for (const value of values) {
    if (seen.has(value)) throw new Error(`Duplicate ${label}: ${value}`);
    seen.add(value);
  }
}

async function driverRows({ activeOnly = true } = {}) {
  const result = await query(
    `SELECT *
     FROM dispatch_drivers
     ${activeOnly ? "WHERE active = true" : ""}
     ORDER BY display_order ASC, id ASC`
  );
  return result.rows;
}

async function truckRows({ activeOnly = true } = {}) {
  const result = await query(
    `SELECT truck.*,
            COALESCE(supported.codes, ARRAY[]::text[]) AS supported_bin_type_codes
       FROM dispatch_trucks truck
       LEFT JOIN LATERAL (
         SELECT array_agg(bin_type.type_code ORDER BY bin_type.type_code) AS codes
           FROM dispatch_truck_bin_types capability
           JOIN mbt_bin_types bin_type ON bin_type.bin_type_id = capability.bin_type_id
          WHERE capability.truck_id = truck.id
            AND capability.active
       ) supported ON true
      ${activeOnly ? "WHERE truck.active = true" : ""}
      ORDER BY truck.display_order ASC, truck.id ASC`
  );
  return result.rows;
}

export async function listDispatchOwnYards({ activeOnly = true } = {}) {
  const result = await query(
    `SELECT yard_code,
            display_name,
            dispatch_location_id,
            address_line_1,
            latitude,
            longitude
       FROM mbt_yards
      ${activeOnly ? "WHERE active = true" : ""}
      ORDER BY dispatch_location_id ASC, yard_code ASC`
  );
  return result.rows.map((row) => {
    const yard = {
      code: String(row.yard_code),
      name: String(row.display_name),
      locationId: Number(row.dispatch_location_id),
      address: String(row.address_line_1 || "")
    };
    if (row.latitude !== null && row.longitude !== null) {
      yard.lat = Number(row.latitude);
      yard.lng = Number(row.longitude);
    }
    return yard;
  });
}

async function upsertDrivers(drivers, { deactivateMissing = true } = {}) {
  const cleaned = drivers.map((driver, index) => cleanDriver(driver, index));
  assertUnique(cleaned.map((driver) => driver.login), "driver login");
  const existingRows = await driverRows({ activeOnly: false });
  const existingById = new Map(existingRows.map((row) => [String(row.id), row]));
  const existingByLogin = new Map(existingRows.map((row) => [String(row.login).trim().toLowerCase(), row]));
  const keptIds = [];

  for (const driver of cleaned) {
    const existing = (driver.id && existingById.get(driver.id)) || existingByLogin.get(driver.login) || null;
    const persistedLogin = existing ? String(existing.login || "").trim().toLowerCase() : driver.login;
    let passwordHash = existing?.password_hash || null;
    let passwordSalt = existing?.password_salt || null;
    if (driver.password) {
      const password = await hashPassword(driver.password);
      passwordHash = password.hash;
      passwordSalt = password.salt;
    }
    const params = [
      driver.name,
      driver.license,
      driver.number,
      persistedLogin,
      passwordHash,
      passwordSalt,
      driver.samsaraPrimaryLogin,
      driver.samsaraSecondaryLogin,
      driver.samsaraEnabled,
      driver.ownYardFixedMinutes,
      driver.vendorFixedMinutes,
      driver.deliveryFixedMinutes,
      driver.minutesPerPallet,
      driver.displayOrder
    ];
    const result = existing
      ? await query(
          `UPDATE dispatch_drivers
           SET name = $1,
               license_class = $2,
               license_number = $3,
               login = $4,
               password_hash = $5,
               password_salt = $6,
               samsara_primary_login = $7,
               samsara_secondary_login = $8,
               samsara_enabled = $9,
               own_yard_fixed_minutes = $10,
               vendor_fixed_minutes = $11,
               delivery_fixed_minutes = $12,
               minutes_per_pallet = $13,
               display_order = $14,
               updated_at = now()
           WHERE id = $15
           RETURNING id`,
          [...params, existing.id]
        )
      : await query(
          `INSERT INTO dispatch_drivers (
             name, license_class, license_number, login, password_hash, password_salt,
             samsara_primary_login, samsara_secondary_login, samsara_enabled, own_yard_fixed_minutes,
             vendor_fixed_minutes, delivery_fixed_minutes, minutes_per_pallet, display_order, active
           )
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
           RETURNING id`,
          [...params, driver.active]
        );
    keptIds.push(String(result.rows[0].id));
  }

  if (deactivateMissing) {
    if (keptIds.length) {
      await query(
        `UPDATE dispatch_drivers
         SET active = false, updated_at = now()
         WHERE NOT (id = ANY($1::bigint[]))`,
        [keptIds]
      );
    } else {
      await query("UPDATE dispatch_drivers SET active = false, updated_at = now() WHERE active = true");
    }
  }
}

async function upsertTrucks(trucks, { deactivateMissing = true } = {}) {
  const cleaned = trucks.map((truck, index) => cleanTruck(truck, index));
  assertUnique(cleaned.map((truck) => normalizedPlate(truck.plate)), "truck plate");
  const existingRows = await truckRows({ activeOnly: false });
  const existingById = new Map(existingRows.map((row) => [String(row.id), row]));
  const existingByPlate = new Map();
  for (const row of existingRows) {
    const plate = normalizedPlate(row.plate);
    if (!existingByPlate.has(plate)) existingByPlate.set(plate, []);
    existingByPlate.get(plate).push(row);
  }
  const keptIds = [];

  for (const truck of cleaned) {
    const plateMatches = existingByPlate.get(normalizedPlate(truck.plate)) || [];
    if (!truck.id && plateMatches.length > 1) {
      throw new Error(`Ambiguous truck plate: ${truck.plate}. Resolve the existing duplicate fleet records first.`);
    }
    const existing = (truck.id && existingById.get(truck.id)) || (plateMatches.length === 1 ? plateMatches[0] : null);
    const persistedPlate = existing ? String(existing.plate || "").trim().toUpperCase() : truck.plate;
    const params = [persistedPlate, truck.capacityLbs, truck.travelTimePercent, truck.baseYard, truck.displayOrder];
    const result = existing
      ? await query(
          `UPDATE dispatch_trucks
           SET plate = $1,
               capacity_lbs = $2,
               travel_time_percent = $3,
               -- A Bin truck's text yard is a compatibility projection of
               -- base_yard_id. Only the audited capability command may move it.
               base_yard = CASE WHEN truck_type = 'bin' THEN base_yard ELSE $4 END,
               display_order = $5,
               updated_at = now()
           WHERE id = $6
           RETURNING id`,
          [...params, existing.id]
        )
      : await query(
          `INSERT INTO dispatch_trucks (plate, capacity_lbs, travel_time_percent, base_yard, display_order, active)
           VALUES ($1, $2, $3, $4, $5, $6)
           RETURNING id`,
          [...params, truck.active]
        );
    keptIds.push(String(result.rows[0].id));
  }

  if (deactivateMissing) {
    if (keptIds.length) {
      await query(
        `UPDATE dispatch_trucks
         SET active = false, updated_at = now()
         WHERE NOT (id = ANY($1::bigint[]))`,
        [keptIds]
      );
    } else {
      await query("UPDATE dispatch_trucks SET active = false, updated_at = now() WHERE active = true");
    }
  }
}

export async function listDispatchDrivers({ activeOnly = true } = {}) {
  return (await driverRows({ activeOnly })).map(publicDriver);
}

export async function listDispatchTrucks({ activeOnly = true } = {}) {
  return (await truckRows({ activeOnly })).map(publicTruck);
}

function fleetRecordId(value, label) {
  const id = String(value || "").trim();
  if (!/^[1-9]\d*$/.test(id)) {
    const error = new Error(`${label} ID must be a positive integer.`);
    error.status = 400;
    throw error;
  }
  return id;
}

export async function setDispatchDriverActive(id, active) {
  const driverId = fleetRecordId(id, "Driver");
  return withTransaction(async () => {
    const existing = await query("SELECT * FROM dispatch_drivers WHERE id = $1 FOR UPDATE", [driverId]);
    if (!existing.rows[0]) return null;
    const updated = await query(
      `UPDATE dispatch_drivers
       SET active = $2, updated_at = now()
       WHERE id = $1
       RETURNING *`,
      [driverId, active === true]
    );
    return {
      before: publicDriver(existing.rows[0]),
      driver: publicDriver(updated.rows[0])
    };
  });
}

export async function setDispatchTruckActive(id, active) {
  const truckId = fleetRecordId(id, "Truck");
  return withTransaction(async () => {
    const existing = await query("SELECT * FROM dispatch_trucks WHERE id = $1 FOR UPDATE", [truckId]);
    if (!existing.rows[0]) return null;
    const updated = await query(
      `UPDATE dispatch_trucks
       SET active = $2, updated_at = now()
       WHERE id = $1
       RETURNING *`,
      [truckId, active === true]
    );
    return {
      before: publicTruck(existing.rows[0]),
      truck: publicTruck(updated.rows[0])
    };
  });
}

export async function getDispatchDriverByLogin(login) {
  const result = await query(
    `SELECT *
     FROM dispatch_drivers
     WHERE lower(btrim(login)) = $1
       AND active = true
     LIMIT 1`,
    [String(login || "").trim().toLowerCase()]
  );
  return publicDriver(result.rows[0]);
}

export async function authenticateDispatchDriver(login, password) {
  const result = await query(
    `SELECT *
     FROM dispatch_drivers
     WHERE lower(btrim(login)) = $1
       AND active = true
     LIMIT 1`,
    [String(login || "").trim().toLowerCase()]
  );
  const row = result.rows[0];
  if (!row) return { driver: null, reason: "invalid" };
  if (!row.password_hash || !row.password_salt) {
    return String(password || "")
      ? { driver: null, reason: "password_not_configured" }
      : { driver: publicDriver(row), reason: "" };
  }
  const valid = await verifyPassword(String(password || ""), row.password_salt, row.password_hash);
  return valid ? { driver: publicDriver(row), reason: "" } : { driver: null, reason: "invalid" };
}

export async function replaceDispatchFleetSetup({ drivers = [], trucks = [] }, { activeOnly = true, deactivateMissing = true } = {}) {
  return withTransaction(async () => {
    await upsertDrivers(drivers, { deactivateMissing });
    await upsertTrucks(trucks, { deactivateMissing });
    return {
      drivers: (await driverRows({ activeOnly })).map(publicDriver),
      trucks: (await truckRows({ activeOnly })).map(publicTruck)
    };
  });
}

export async function ensureDispatchFleetSetup({ drivers = [], trucks = [] }) {
  return withTransaction(async () => {
    await query("SELECT pg_advisory_xact_lock(hashtext('dispatch_fleet_setup_seed'))");
    const driverCount = await query("SELECT count(*)::integer AS count FROM dispatch_drivers");
    const truckCount = await query("SELECT count(*)::integer AS count FROM dispatch_trucks");
    if (!driverCount.rows[0].count && drivers.length) await upsertDrivers(drivers, { deactivateMissing: false });
    if (!truckCount.rows[0].count && trucks.length) await upsertTrucks(trucks, { deactivateMissing: false });
    return {
      drivers: (await driverRows()).map(publicDriver),
      trucks: (await truckRows()).map(publicTruck)
    };
  });
}
