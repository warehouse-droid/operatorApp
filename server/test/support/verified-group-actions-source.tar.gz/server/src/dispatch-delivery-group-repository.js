import { query, withTransaction } from "./db.js";
import { DISPATCH_FLEET_PLANNING_LOCK } from "./dispatch-fleet-status.js";
import { dispatchLoadAssignment } from "./dispatch-load-assignment.js";
import {
  compactDispatchOrderCard,
  dispatchOrderSearchText
} from "./dispatch-planner-optimization.js";
import {
  applyActiveTransitCoMetadata,
  clearCancelledTransitCoMetadata
} from "./dispatch-planner-performance.js";

const GLOBAL_GROUP_ORDER_TYPES = new Set(["SO", "PO", "TO", "CO"]);
const GLOBAL_DERIVED_ORDER_TYPES = new Set(["SO", "PO", "TO", "CO", "CUSTOM"]);
const NETSUITE_DISPATCH_SOURCE_TABLES = new Set(["sales_orders", "purchase_orders", "transfer_orders"]);
const SPLIT_LIVE_SOURCE_FIELDS = Object.freeze([
  "sourceTable", "netsuiteId", "dispatchRef", "customer", "customerName",
  "address", "pickupAddress", "pickupAddressOverride", "sourceAddress",
  "defaultSourceAddress", "pickupLocation", "pickupLocations", "sourceYard",
  "destinationYard", "destinationAddress", "defaultDestinationAddress",
  "deliveryAddressOverride", "destinationLocationId", "expectedDeliveryDate",
  "windowStart", "windowEnd", "instructions", "notes", "vendorYard",
  "parseSource", "netsuiteStatus", "netsuiteStatusText", "fulfillmentStatus",
  "netsuiteActive", "operatorStatus", "localYardOrderStatus", "raw", "scm"
]);
const PLAN_LIVE_DEFINITION_FIELDS = Object.freeze([
  ...SPLIT_LIVE_SOURCE_FIELDS,
  "dispatchDetailsOverride",
  "customer", "customerName", "childOrders", "groupAliases", "isGrouped", "isSplit",
  "items", "pallets", "layers", "sections", "pieces", "salesQty",
  "salesQuantities", "packed", "weight", "totalWeightLbs", "unloadMinutes",
  "travelMinutes", "stopMinutes", "childOrderDetails", "transitCo",
  "dropoffs", "poRouteProjection",
  "transitOriginalPickupLocations", "transitOriginalSourceYard"
]);

function dateOnly(value) {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  const text = String(value).slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : null;
}

function text(value) {
  return String(value ?? "").trim();
}

function orderIdentity(order = {}) {
  return text(order.id || order.orderId || order.orderRef || order.tranid || order.refNumber);
}

function cloneOrder(order = {}) {
  return JSON.parse(JSON.stringify(order));
}

function cloneValue(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function locationKey(value) {
  return text(value).split(/\s*:\s*/u, 1)[0].toLowerCase();
}

function uniqueLocations(values = []) {
  const seen = new Set();
  return values.map(text).filter((value) => {
    const key = locationKey(value);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function isNetSuiteDispatchSourceOrder(order = {}) {
  return NETSUITE_DISPATCH_SOURCE_TABLES.has(text(order.sourceTable || order.raw?.source_table).toLowerCase());
}

export function netSuiteDispatchSourceSnapshot(order = {}) {
  const snapshot = cloneOrder(order);
  const raw = snapshot.raw && typeof snapshot.raw === "object" && !Array.isArray(snapshot.raw)
    ? snapshot.raw
    : {};
  const rawPickups = uniqueLocations([
    raw.pickup_location,
    raw.outbound_location,
    raw.source_location,
    ...(Array.isArray(raw.allocation_pickup_locations) ? raw.allocation_pickup_locations : [])
  ]);
  const fallbackPickups = uniqueLocations([
    ...(Array.isArray(snapshot.transitOriginalPickupLocations)
      ? snapshot.transitOriginalPickupLocations
      : []),
    snapshot.transitOriginalSourceYard,
    snapshot.transitCo?.fromYard,
    ...(Array.isArray(snapshot.pickupLocations)
      ? snapshot.pickupLocations.filter((location) => (
        locationKey(location) !== locationKey(snapshot.transitCo?.toYard)
      ))
      : [])
  ]);
  const pickupLocations = rawPickups.length ? rawPickups : fallbackPickups;
  snapshot.pickupLocations = pickupLocations;
  snapshot.sourceYard = pickupLocations[0] || snapshot.transitOriginalSourceYard
    || snapshot.transitCo?.fromYard || snapshot.sourceYard || "";
  snapshot.notes = text(snapshot.notes).replace(/^Transit via [^.]+\.?\s*/iu, "").trim();
  snapshot.transitCo = null;
  delete snapshot.transitOriginalPickupLocations;
  delete snapshot.transitOriginalSourceYard;
  return snapshot;
}

function canonicalGroupedOrderType(order = {}) {
  const direct = text(order.type).toUpperCase();
  if (GLOBAL_GROUP_ORDER_TYPES.has(direct)) return direct;
  const childTypes = [...new Set((Array.isArray(order.childOrderDetails) ? order.childOrderDetails : [])
    .map((child) => text(child?.type).toUpperCase())
    .filter((type) => GLOBAL_GROUP_ORDER_TYPES.has(type)))];
  return childTypes.length === 1 ? childTypes[0] : "";
}

function isAggregateCoGroup(order = {}) {
  if (canonicalGroupedOrderType(order) !== "CO") return false;
  const childRefs = Array.isArray(order.childOrders) ? order.childOrders : [];
  const childDetails = Array.isArray(order.childOrderDetails) ? order.childOrderDetails : [];
  return childRefs.some((ref) => text(ref).toUpperCase().startsWith("CO-"))
    || childDetails.some((child) => (
      canonicalGroupedOrderType(child) === "CO"
      || text(child?.id).toUpperCase().startsWith("CO-")
    ));
}

function isGroupedDispatchOrder(order = {}) {
  const type = canonicalGroupedOrderType(order);
  return Boolean(type)
    && Array.isArray(order.childOrders)
    && order.childOrders.length > 0
    // A normal CO created for a grouped source carries the source children for
    // detail, but it is still one canonical local CO—not a grouped-CO order.
    && (type !== "CO" || isAggregateCoGroup(order));
}

function childOrderRefs(order = {}) {
  const refs = new Set();
  const visiting = new Set();
  const rootType = canonicalGroupedOrderType(order);

  const visit = (candidate, { root = false } = {}) => {
    const candidateId = String(candidate?.id || "").trim();
    const children = (Array.isArray(candidate?.childOrders) ? candidate.childOrders : [])
      .map((ref) => String(ref || "").trim())
      .filter(Boolean);
    if (!root && rootType === "CO" && canonicalGroupedOrderType(candidate) === "CO" && !isAggregateCoGroup(candidate)) {
      if (candidateId) refs.add(candidateId);
      return;
    }
    if (!children.length) {
      if (candidateId) refs.add(candidateId);
      return;
    }
    if (candidateId && visiting.has(candidateId)) return;
    if (candidateId) visiting.add(candidateId);

    const detailById = new Map(
      (Array.isArray(candidate?.childOrderDetails) ? candidate.childOrderDetails : [])
        .filter((detail) => detail?.id)
        .map((detail) => [String(detail.id), detail])
    );
    for (const childRef of children) {
      const detail = detailById.get(childRef);
      if (detail && Array.isArray(detail.childOrders) && detail.childOrders.length) visit(detail);
      else refs.add(childRef);
    }
    if (candidateId) visiting.delete(candidateId);
  };

  visit(order, { root: true });
  return [...refs].sort((left, right) => left.localeCompare(right, undefined, { numeric: true, sensitivity: "base" }));
}

function childOrderMembers(order = {}, groupType = canonicalGroupedOrderType(order)) {
  const detailTypes = new Map();
  const visit = (candidate = {}) => {
    const candidateRef = text(candidate.id).toLowerCase();
    const candidateType = text(candidate.type).toUpperCase();
    if (candidateRef && GLOBAL_GROUP_ORDER_TYPES.has(candidateType)) {
      detailTypes.set(candidateRef, candidateType);
    }
    for (const child of Array.isArray(candidate.childOrderDetails) ? candidate.childOrderDetails : []) visit(child);
  };
  visit(order);
  return childOrderRefs(order).map((memberOrderRef) => {
    const memberType = detailTypes.get(memberOrderRef.toLowerCase())
      || (memberOrderRef.toUpperCase().startsWith("CO-") ? "CO" : "");
    return {
      memberOrderRef,
      // A CO created for a source group carries the source members for detail,
      // but it must not hide those SO/TO members from their own lifecycle.
      hidesMember: groupType === "CO"
        ? memberType === "CO"
        : !memberType || memberType === groupType
    };
  });
}

function findGroupAssignment(plan, groupRef) {
  for (const truck of plan.trucks || []) {
    for (const load of truck.loads || []) {
      if (load.returnOnly) continue;
      if (!(load.stops || []).some((stop) => String(stop.orderId || "") === groupRef)) continue;
      const assignment = dispatchLoadAssignment(truck, load);
      return {
        truckPlate: assignment.truckPlate,
        loadName: String(load.name || ""),
        parkingSpot: assignment.parkingSpot
      };
    }
  }
  return null;
}

function globalGroupSnapshot(order = {}, { sourcePlanId, sourcePlanDate, orderType } = {}) {
  const snapshot = JSON.parse(JSON.stringify(order));
  for (const field of [
    "dispatchSnapshotSourcePlanId",
    "dispatchSnapshotSourcePlanDate",
    "dispatchPlanned",
    "dispatchPlanId",
    "dispatchPlanDate",
    "dispatchTruckPlate",
    "dispatchLoadName",
    "dispatchParkingSpot",
    "dispatchDriverLogin",
    "dispatchDriverName",
    "jump",
    "readOnly",
    "assigned"
  ]) delete snapshot[field];
  return {
    ...snapshot,
    type: orderType || canonicalGroupedOrderType(order) || snapshot.type,
    globalGroupDefinition: true,
    globalGroupSourcePlanId: sourcePlanId === null || sourcePlanId === undefined ? "" : String(sourcePlanId),
    globalGroupSourcePlanDate: sourcePlanDate,
    groupPlanId: "",
    groupPlanDate: "",
    planOwned: false,
    dispatchPlanned: false,
    catalogHydrated: true
  };
}

function projectGlobalGroups(plan = {}) {
  const planId = Number(plan.id);
  const planDate = dateOnly(plan.planDate || plan.plan_date);
  if (!Number.isInteger(planId) || !planDate) return [];
  const groups = [];
  for (const order of plan.orders || []) {
    if (!isGroupedDispatchOrder(order)) continue;
    const orderType = canonicalGroupedOrderType(order);
    const groupRef = text(order.id);
    const members = childOrderMembers(order, orderType);
    const memberRefs = members.map((member) => member.memberOrderRef);
    if (!groupRef || !members.length) continue;
    const assignment = findGroupAssignment(plan, groupRef);
    const declaredSourcePlanId = Number(
      order.globalGroupSourcePlanId
      || order.groupPlanId
      || planId
    );
    const declaredSourcePlanDate = dateOnly(
      order.globalGroupSourcePlanDate
      || order.groupPlanDate
      || planDate
    );
    const belongsToPlan = declaredSourcePlanId === planId
      && (!declaredSourcePlanDate || declaredSourcePlanDate === planDate);
    // A foreign unassigned snapshot is stale plan-local structure, not a new
    // global definition. An actual assignment transfers canonical ownership.
    if (!belongsToPlan && !assignment) continue;
    const snapshot = globalGroupSnapshot(order, {
      sourcePlanId: planId,
      sourcePlanDate: planDate,
      orderType
    });
    groups.push({
      groupRef,
      orderType,
      sourcePlanId: planId,
      sourcePlanDate: planDate,
      sourceRevision: Math.max(0, Number(plan.revision || 0)),
      memberRefs,
      members,
      snapshot,
      card: compactDispatchOrderCard(snapshot),
      searchText: dispatchOrderSearchText(snapshot),
      eligible: order.eligible !== false,
      assigned: Boolean(assignment)
    });
  }
  return groups;
}

async function syncDispatchGlobalOrderGroupsFromPlan(plan = {}) {
  const planId = Number(plan.id);
  const planDate = dateOnly(plan.planDate || plan.plan_date);
  if (!Number.isInteger(planId) || !planDate) return { groups: 0, members: 0, deactivated: 0 };
  const projected = projectGlobalGroups(plan);
  const lockRefs = [...new Set(projected
    .map((group) => group.groupRef.toLowerCase())
    .filter(Boolean))].sort();
  for (const groupRef of lockRefs) {
    await query(
      "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
      [`dispatch-global-order-group:${groupRef}`]
    );
  }
  const existingSources = projected.length
    ? await query(
        `SELECT lower(group_ref) AS group_key, source_plan_id,
                source_plan_date::text AS source_plan_date
           FROM dispatch_global_order_groups
          WHERE lower(group_ref) = ANY($1::text[])`,
        [projected.map((group) => group.groupRef.toLowerCase())]
      )
    : { rows: [] };
  const sourceByGroup = new Map(existingSources.rows.map((row) => [
    text(row.group_key),
    {
      planId: row.source_plan_id === null ? null : Number(row.source_plan_id),
      planDate: dateOnly(row.source_plan_date)
    }
  ]));
  const groups = projected.flatMap((group) => {
    const existingSource = sourceByGroup.get(group.groupRef.toLowerCase());
    if (existingSource && existingSource.planId !== planId && !group.assigned) return [];
    if (!existingSource) return [group];
    const sourcePlanId = existingSource.planId;
    const sourcePlanDate = existingSource.planDate || group.sourcePlanDate;
    const snapshot = {
      ...group.snapshot,
      globalGroupSourcePlanId: sourcePlanId === null ? "" : String(sourcePlanId),
      globalGroupSourcePlanDate: sourcePlanDate
    };
    return [{
      ...group,
      sourcePlanId,
      sourcePlanDate,
      snapshot,
      card: compactDispatchOrderCard(snapshot),
      searchText: dispatchOrderSearchText(snapshot)
    }];
  });
  const groupRefs = groups.map((group) => group.groupRef);
  // Missing from a compact plan means unassigned, not deleted. Retirement is
  // an explicit ungroup/unsplit operation handled by
  // deactivateDispatchGlobalOrderDefinitions().
  const deactivated = { rowCount: 0, rows: [] };
  if (groups.length) {
    await query(
      `INSERT INTO dispatch_global_order_groups (
         group_ref, order_type, source_plan_id, source_plan_date,
         full_order, card, search_text, eligible, active,
         source_revision, updated_at
       )
       SELECT source.group_ref, source.order_type, source.source_plan_id,
              source.source_plan_date, source.full_order, source.card,
              source.search_text, source.eligible, true,
              source.source_revision, now()
         FROM jsonb_to_recordset($1::jsonb) AS source(
           group_ref text, order_type text, source_plan_id bigint,
           source_plan_date date, full_order jsonb, card jsonb,
           search_text text, eligible boolean, source_revision bigint
         )
       ON CONFLICT (group_ref) DO UPDATE
         SET order_type = EXCLUDED.order_type,
             full_order = EXCLUDED.full_order,
             card = EXCLUDED.card,
             search_text = EXCLUDED.search_text,
             eligible = EXCLUDED.eligible,
             active = true,
             source_revision = EXCLUDED.source_revision,
             updated_at = now()`,
      [JSON.stringify(groups.map((group) => ({
        group_ref: group.groupRef,
        order_type: group.orderType,
        source_plan_id: group.sourcePlanId,
        source_plan_date: group.sourcePlanDate,
        full_order: group.snapshot,
        card: group.card,
        search_text: group.searchText,
        eligible: group.eligible,
        source_revision: group.sourceRevision
      })))]
    );
    await query(
      "DELETE FROM dispatch_global_order_group_members WHERE group_ref = ANY($1::text[])",
      [groupRefs]
    );
    const members = groups.flatMap((group) => group.members.map((member, position) => ({
      groupRef: group.groupRef,
      memberOrderRef: member.memberOrderRef,
      position,
      hidesMember: member.hidesMember
    })));
    await query(
      `INSERT INTO dispatch_global_order_group_members (
         group_ref, member_order_ref, position, hides_member
       )
       SELECT source.group_ref, source.member_order_ref, source.position,
              source.hides_member
         FROM jsonb_to_recordset($1::jsonb) AS source(
           group_ref text, member_order_ref text, position integer,
           hides_member boolean
         )`,
      [JSON.stringify(members.map((member) => ({
        group_ref: member.groupRef,
        member_order_ref: member.memberOrderRef,
        position: member.position,
        hides_member: member.hidesMember
      })))]
    );
    await query(
      `DELETE FROM dispatch_order_catalog_entries
        WHERE lower(order_ref) = ANY($1::text[])`,
      [groupRefs.map((ref) => ref.toLowerCase())]
    );
  }
  if (groups.length || deactivated.rowCount) {
    await query(
      `UPDATE dispatch_order_catalog_state
          SET generation = generation + 1,
              catalog_count = (SELECT count(*)::int FROM dispatch_order_catalog_entries),
              updated_at = now()
        WHERE singleton = true`
    );
  }
  return {
    groups: groups.length,
    members: groups.reduce((count, group) => count + group.memberRefs.length, 0),
    deactivated: deactivated.rowCount
  };
}

function splitParentRef(order = {}) {
  const explicit = text(order.originalOrderId || order.parentOrderRef);
  if (explicit) return explicit;
  const ref = text(order.id);
  return /-S\d+$/iu.test(ref) ? ref.replace(/-S\d+$/iu, "") : "";
}

function canonicalDerivedOrderType(order = {}) {
  const type = text(order.type).toUpperCase();
  return GLOBAL_DERIVED_ORDER_TYPES.has(type) ? type : "";
}

function derivedDefinitionKind(order = {}) {
  if (!canonicalDerivedOrderType(order)) return "";
  if (splitParentRef(order)) return "split";
  const declared = text(order.globalOrderDefinitionKind).toLowerCase();
  if (["consolidation", "derived"].includes(declared)) return declared;
  if (text(order.id).toUpperCase().startsWith("TO-DRAFT-")) return "consolidation";
  return "";
}

function derivedParentRef(order = {}, plan = {}) {
  const explicit = splitParentRef(order) || text(order.sourceOrderId || order.parentOrderRef);
  if (explicit) return explicit;
  const ref = text(order.id).toLowerCase();
  const source = (plan.orders || []).find((candidate) => (
    text(candidate?.consolidation?.transferOrderId).toLowerCase() === ref
  ));
  return text(source?.id);
}

function isGlobalDerivedOrder(order = {}) {
  return Boolean(derivedDefinitionKind(order));
}

function globalSplitSnapshot(order = {}, {
  sourcePlanId,
  sourcePlanDate,
  orderType,
  definitionKind,
  parentOrderRef
} = {}) {
  const snapshot = JSON.parse(JSON.stringify(order));
  for (const field of [
    "dispatchSnapshotSourcePlanId",
    "dispatchSnapshotSourcePlanDate",
    "dispatchPlanned",
    "dispatchPlanId",
    "dispatchPlanDate",
    "dispatchTruckPlate",
    "dispatchLoadName",
    "dispatchParkingSpot",
    "dispatchDriverLogin",
    "dispatchDriverName",
    "jump",
    "readOnly",
    "assigned"
  ]) delete snapshot[field];
  return {
    ...snapshot,
    type: orderType || canonicalDerivedOrderType(order) || snapshot.type,
    ...(definitionKind === "split" ? { originalOrderId: parentOrderRef } : {}),
    ...(definitionKind !== "split" && parentOrderRef && !snapshot.sourceOrderId
      ? { sourceOrderId: parentOrderRef }
      : {}),
    globalOrderDefinition: true,
    globalOrderDefinitionKind: definitionKind,
    globalOrderSourcePlanId: sourcePlanId === null || sourcePlanId === undefined ? "" : String(sourcePlanId),
    globalOrderSourcePlanDate: sourcePlanDate,
    planOwned: false,
    dispatchPlanned: false,
    catalogHydrated: true
  };
}

function projectGlobalSplits(plan = {}) {
  const planId = Number(plan.id);
  const sourcePlanDate = dateOnly(plan.planDate || plan.plan_date);
  if (!Number.isInteger(planId) || !sourcePlanDate) return [];
  const splits = [];
  for (const order of plan.orders || []) {
    if (!isGlobalDerivedOrder(order)) continue;
    const splitRef = text(order.id);
    const definitionKind = derivedDefinitionKind(order);
    const parentOrderRef = derivedParentRef(order, plan);
    if (definitionKind === "split" && !parentOrderRef) continue;
    const assignment = findGroupAssignment(plan, splitRef);
    const declaredSourcePlanId = Number(
      order.globalOrderSourcePlanId
      || order.dispatchSnapshotSourcePlanId
      || planId
    );
    const declaredSourcePlanDate = dateOnly(
      order.globalOrderSourcePlanDate
      || order.dispatchSnapshotSourcePlanDate
      || sourcePlanDate
    );
    const belongsToPlan = declaredSourcePlanId === planId
      && (!declaredSourcePlanDate || declaredSourcePlanDate === sourcePlanDate);
    if (!belongsToPlan && !assignment) continue;
    const orderType = canonicalDerivedOrderType(order);
    const snapshot = globalSplitSnapshot(order, {
      sourcePlanId: planId,
      sourcePlanDate,
      orderType,
      definitionKind,
      parentOrderRef
    });
    splits.push({
      splitRef,
      orderType,
      definitionKind,
      parentOrderRef,
      sourcePlanId: planId,
      sourcePlanDate,
      sourceRevision: Math.max(0, Number(plan.revision || 0)),
      snapshot,
      card: compactDispatchOrderCard(snapshot),
      searchText: dispatchOrderSearchText(snapshot),
      eligible: order.eligible !== false,
      assigned: Boolean(assignment)
    });
  }
  return splits;
}

async function syncDispatchGlobalOrderSplitsFromPlan(plan = {}) {
  const planId = Number(plan.id);
  const sourcePlanDate = dateOnly(plan.planDate || plan.plan_date);
  if (!Number.isInteger(planId) || !sourcePlanDate) return { splits: 0, deactivated: 0 };
  const projected = projectGlobalSplits(plan);
  const lockRefs = [...new Set(projected
    .map((split) => split.splitRef.toLowerCase())
    .filter(Boolean))].sort();
  for (const splitRef of lockRefs) {
    await query(
      "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
      [`dispatch-global-order-split:${splitRef}`]
    );
  }
  const existingSources = projected.length
    ? await query(
        `SELECT lower(split_ref) AS split_key, source_plan_id,
                source_plan_date::text AS source_plan_date
           FROM dispatch_global_order_splits
          WHERE lower(split_ref) = ANY($1::text[])`,
        [projected.map((split) => split.splitRef.toLowerCase())]
      )
    : { rows: [] };
  const sourceBySplit = new Map(existingSources.rows.map((row) => [
    text(row.split_key),
    {
      planId: row.source_plan_id === null ? null : Number(row.source_plan_id),
      planDate: dateOnly(row.source_plan_date)
    }
  ]));
  const splits = projected.flatMap((split) => {
    const existingSource = sourceBySplit.get(split.splitRef.toLowerCase());
    if (existingSource && existingSource.planId !== planId && !split.assigned) return [];
    if (!existingSource) return [split];
    const sourcePlanId = existingSource.planId;
    const sourcePlanDate = existingSource.planDate || split.sourcePlanDate;
    const snapshot = {
      ...split.snapshot,
      globalOrderSourcePlanId: sourcePlanId === null ? "" : String(sourcePlanId),
      globalOrderSourcePlanDate: sourcePlanDate
    };
    return [{
      ...split,
      sourcePlanId,
      sourcePlanDate,
      snapshot,
      card: compactDispatchOrderCard(snapshot),
      searchText: dispatchOrderSearchText(snapshot)
    }];
  });
  const splitRefs = splits.map((split) => split.splitRef);
  const deactivated = { rowCount: 0, rows: [] };
  if (splits.length) {
    await query(
      `INSERT INTO dispatch_global_order_splits (
         split_ref, order_type, definition_kind, parent_order_ref, source_plan_id,
         source_plan_date, full_order, card, search_text, eligible, active,
         source_revision, updated_at
       )
       SELECT source.split_ref, source.order_type, source.definition_kind,
              source.parent_order_ref,
              source.source_plan_id, source.source_plan_date, source.full_order,
              source.card, source.search_text, source.eligible, true,
              source.source_revision, now()
         FROM jsonb_to_recordset($1::jsonb) AS source(
           split_ref text, order_type text, definition_kind text,
           parent_order_ref text,
           source_plan_id bigint, source_plan_date date, full_order jsonb,
           card jsonb, search_text text, eligible boolean,
           source_revision bigint
         )
       ON CONFLICT (split_ref) DO UPDATE
         SET order_type = EXCLUDED.order_type,
             definition_kind = EXCLUDED.definition_kind,
             parent_order_ref = EXCLUDED.parent_order_ref,
             full_order = EXCLUDED.full_order,
             card = EXCLUDED.card,
             search_text = EXCLUDED.search_text,
             eligible = EXCLUDED.eligible,
             active = true,
             source_revision = EXCLUDED.source_revision,
             updated_at = now()`,
      [JSON.stringify(splits.map((split) => ({
        split_ref: split.splitRef,
        order_type: split.orderType,
        definition_kind: split.definitionKind,
        parent_order_ref: split.parentOrderRef,
        source_plan_id: split.sourcePlanId,
        source_plan_date: split.sourcePlanDate,
        full_order: split.snapshot,
        card: split.card,
        search_text: split.searchText,
        eligible: split.eligible,
        source_revision: split.sourceRevision
      })))]
    );
    await query(
      `DELETE FROM dispatch_order_catalog_entries
        WHERE lower(order_ref) = ANY($1::text[])`,
      [splitRefs.map((ref) => ref.toLowerCase())]
    );
  }
  if (splits.length || deactivated.rowCount) {
    await query(
      `UPDATE dispatch_order_catalog_state
          SET generation = generation + 1,
              catalog_count = (SELECT count(*)::int FROM dispatch_order_catalog_entries),
              updated_at = now()
        WHERE singleton = true`
    );
  }
  return { splits: splits.length, deactivated: deactivated.rowCount };
}

function transitCoRecord(co = {}, sourceOrderRef = "") {
  return {
    coRef: text(co.co_ref || co.coRef || co.id),
    sourceOrderRef: text(co.source_order_ref || co.sourceOrderRef || sourceOrderRef),
    fromYard: text(co.from_location || co.fromYard),
    toYard: text(co.to_location || co.toYard),
    status: text(co.status),
    createdAt: co.created_at || co.createdAt || null
  };
}

async function dispatchTransitCoState() {
  const localCos = await query(
    `SELECT co_ref, source_order_ref, from_location, to_location,
            status, created_at, updated_at
       FROM local_co_orders
      ORDER BY updated_at, id`
  );
  const activeBySource = new Map();
  const cancelledByRef = new Map();
  const allByRef = new Map();
  for (const row of localCos.rows) {
    const record = transitCoRecord(row, row.source_order_ref);
    if (!record.coRef) continue;
    allByRef.set(record.coRef.toLowerCase(), record);
    if (text(row.status).toLowerCase() === "cancelled") {
      cancelledByRef.set(record.coRef.toLowerCase(), record);
    } else if (record.sourceOrderRef && record.fromYard && record.toYard) {
      activeBySource.set(record.sourceOrderRef.toLowerCase(), record);
    }
  }
  return { activeBySource, cancelledByRef, allByRef };
}

async function updateGlobalDefinitionTransitCo({
  tableName,
  refColumn,
  sourceOrderRef,
  co,
  cancelled
}) {
  const sourceRef = text(sourceOrderRef || co?.source_order_ref || co?.sourceOrderRef);
  const record = transitCoRecord(co, sourceRef);
  if (!sourceRef || !record.coRef) return [];
  const rows = await query(
    `SELECT ${refColumn} AS order_ref, full_order
       FROM ${tableName}
      WHERE active = true
        AND (
          lower(${refColumn}) = lower($1)
          OR full_order::text ILIKE ('%' || $1 || '%')
        )`,
    [sourceRef]
  );
  const updatedRefs = [];
  for (const row of rows.rows) {
    const current = row.full_order || {};
    let next = cancelled
      ? clearCancelledTransitCoMetadata(current, [record])
      : applyActiveTransitCoMetadata(current, [record]);
    if (
      tableName === "dispatch_global_order_groups"
      && Array.isArray(next.childOrderDetails)
      && next.childOrderDetails.length
    ) {
      next = aggregateGlobalGroup(next, next.childOrderDetails, { preserveTransitCo: true });
    }
    if (JSON.stringify(next) === JSON.stringify(current)) continue;
    await query(
      `UPDATE ${tableName}
          SET full_order = $2::jsonb,
              card = $3::jsonb,
              search_text = $4,
              updated_at = now()
        WHERE lower(${refColumn}) = lower($1)`,
      [
        row.order_ref,
        JSON.stringify(next),
        JSON.stringify(compactDispatchOrderCard(next)),
        dispatchOrderSearchText(next)
      ]
    );
    updatedRefs.push(text(row.order_ref));
  }
  return updatedRefs;
}

export async function syncDispatchGlobalOrderTransitCo({
  sourceOrderRef = "",
  co = {},
  cancelled = false
} = {}) {
  const groups = await updateGlobalDefinitionTransitCo({
    tableName: "dispatch_global_order_groups",
    refColumn: "group_ref",
    sourceOrderRef,
    co,
    cancelled
  });
  const splits = await updateGlobalDefinitionTransitCo({
    tableName: "dispatch_global_order_splits",
    refColumn: "split_ref",
    sourceOrderRef,
    co,
    cancelled
  });
  const orderRefs = [...new Set([...groups, ...splits])];
  if (orderRefs.length) {
    await query(
      `UPDATE dispatch_order_catalog_state
          SET generation = generation + 1,
              updated_at = now()
        WHERE singleton = true`
    );
  }
  return { updated: orderRefs.length, orderRefs };
}

async function reconcileGlobalDefinitionTableTransitCos({
  tableName,
  refColumn,
  activeBySource,
  cancelledByRef
}) {
  const rows = await query(
    `SELECT ${refColumn} AS order_ref, full_order
       FROM ${tableName}
      WHERE active = true
      ORDER BY lower(${refColumn})`
  );
  const updatedRefs = [];
  for (const row of rows.rows) {
    const current = row.full_order || {};
    let next = clearCancelledTransitCoMetadata(current, cancelledByRef);
    next = applyActiveTransitCoMetadata(next, activeBySource);
    if (
      tableName === "dispatch_global_order_groups"
      && Array.isArray(next.childOrderDetails)
      && next.childOrderDetails.length
    ) {
      next = aggregateGlobalGroup(next, next.childOrderDetails, { preserveTransitCo: true });
    }
    if (JSON.stringify(next) === JSON.stringify(current)) continue;
    await query(
      `UPDATE ${tableName}
          SET full_order = $2::jsonb,
              card = $3::jsonb,
              search_text = $4,
              updated_at = now()
        WHERE lower(${refColumn}) = lower($1)`,
      [
        row.order_ref,
        JSON.stringify(next),
        JSON.stringify(compactDispatchOrderCard(next)),
        dispatchOrderSearchText(next)
      ]
    );
    updatedRefs.push(text(row.order_ref));
  }
  return updatedRefs;
}

export async function reconcileDispatchGlobalOrderTransitCos() {
  return withTransaction(async () => {
    const { activeBySource, cancelledByRef } = await dispatchTransitCoState();
    const groups = await reconcileGlobalDefinitionTableTransitCos({
      tableName: "dispatch_global_order_groups",
      refColumn: "group_ref",
      activeBySource,
      cancelledByRef
    });
    const splits = await reconcileGlobalDefinitionTableTransitCos({
      tableName: "dispatch_global_order_splits",
      refColumn: "split_ref",
      activeBySource,
      cancelledByRef
    });
    const orderRefs = [...new Set([...groups, ...splits])];
    if (orderRefs.length) {
      await query(
        `UPDATE dispatch_order_catalog_state
            SET generation = generation + 1,
                updated_at = now()
          WHERE singleton = true`
      );
    }
    return { updated: orderRefs.length, orderRefs };
  });
}

function groupedSalesOrderDeliveryFields(order = {}, children = []) {
  if (text(order.type).toUpperCase() !== "SO" || !children.length) return {};
  const previous = Array.isArray(order.childOrderDetails) ? order.childOrderDetails : [];
  const representativeRef = text(order.groupKey || previous[0]?.id || children[0]?.id).toLowerCase();
  const representative = children.find((child) => text(child.id).toLowerCase() === representativeRef) || children[0];
  const prior = previous.find((child) => text(child.id).toLowerCase() === representativeRef);
  const currentAddress = text(order.address);
  // Grouping inherits the first selected member's address. Keep deliberate
  // group-only edits while refreshing inherited addresses with their source.
  const manuallyChanged = prior && currentAddress !== text(prior.address);
  const address = manuallyChanged ? currentAddress : text(representative.address);
  return {
    address,
    destinationAddress: address,
    defaultDestinationAddress: text(representative.defaultDestinationAddress ?? representative.address)
  };
}

export function aggregateGlobalGroup(order = {}, childOrderDetails = [], { preserveTransitCo = false } = {}) {
  // A CO for a grouped SO/TO owns its persisted manifest. Source children are
  // informational and may be incomplete cards, not constituent CO cargo.
  if (text(order.type).toUpperCase() === "CO" && order.sourceTable === "local_co_orders"
    && text(order.sourceOrderId) && !(order.childOrders || []).some((ref) => text(ref).toUpperCase().startsWith("CO-"))) {
    return order;
  }
  const sum = (field) => childOrderDetails.reduce(
    (total, child) => total + Number(child?.[field] || 0),
    0
  );
  const pickupLocations = [...new Set(childOrderDetails
    .flatMap((child) => child.pickupLocations || [])
    .map(text)
    .filter(Boolean))];
  const existingSourceYard = text(order.sourceYard);
  const sourceYard = pickupLocations.length === 1
    ? pickupLocations[0]
    : pickupLocations.some((location) => locationKey(location) === locationKey(existingSourceYard))
      ? existingSourceYard
      : pickupLocations[0] || existingSourceYard;
  return {
    ...order,
    ...groupedSalesOrderDeliveryFields(order, childOrderDetails),
    childOrders: childOrderDetails.map((child) => text(child?.id)).filter(Boolean),
    childOrderDetails,
    items: childOrderDetails.flatMap((child) => Array.isArray(child.items) ? child.items : []),
    pallets: sum("pallets"),
    layers: sum("layers"),
    sections: sum("sections"),
    pieces: sum("pieces"),
    salesQty: sum("salesQty"),
    weight: sum("weight"),
    unloadMinutes: sum("unloadMinutes"),
    travelMinutes: Math.max(0, ...childOrderDetails.map((child) => Number(child?.travelMinutes || 0))),
    pickupLocations,
    sourceYard,
    customer: `${childOrderDetails.length} orders grouped`,
    sourceOrderId: "",
    relatedSoId: "",
    relatedToId: "",
    relatedCustomOrderId: "",
    transitCo: preserveTransitCo ? order.transitCo : null
  };
}

function stripTransitOverlays(order = {}, allByRef = new Map()) {
  const overlays = new Map(allByRef);
  const visit = (candidate = {}) => {
    const coRef = text(candidate.transitCo?.id);
    if (coRef && !overlays.has(coRef.toLowerCase())) {
      overlays.set(coRef.toLowerCase(), {
        coRef,
        fromYard: text(candidate.transitCo?.fromYard || candidate.transitOriginalSourceYard),
        toYard: text(candidate.transitCo?.toYard)
      });
    }
    for (const child of Array.isArray(candidate.childOrderDetails) ? candidate.childOrderDetails : []) visit(child);
  };
  visit(order);
  return clearCancelledTransitCoMetadata(order, overlays);
}

function applySplitDispatchDetails(order = {}) {
  const details = order.dispatchDetailsOverride;
  if (!details || typeof details !== "object" || Array.isArray(details)) return order;
  const next = { ...order };
  if (Object.hasOwn(details, "address")) {
    next.address = text(details.address);
    next.destinationAddress = next.address;
    next.defaultDestinationAddress = next.address;
  }
  if (Object.hasOwn(details, "pickupAddress")) {
    next.pickupAddressOverride = text(details.pickupAddress);
    next.sourceAddress = next.pickupAddressOverride || next.defaultSourceAddress || "";
  }
  for (const field of ["expectedDeliveryDate", "windowStart", "windowEnd"]) {
    if (Object.hasOwn(details, field)) next[field] = text(details[field]);
  }
  return next;
}

export async function updateDispatchSalesSplitDetails(orderRef, patch = {}) {
  return withTransaction(async () => {
    // Plan saves read the global definition before writing their snapshot. Share
    // their lock so a save already in flight cannot overwrite this explicit edit.
    await query("SELECT pg_advisory_xact_lock(hashtext($1))", [DISPATCH_FLEET_PLANNING_LOCK]);
    const row = (await query(
      `SELECT split_ref, full_order, active FROM dispatch_global_order_splits
        WHERE lower(split_ref) = lower($1) AND order_type = 'SO' AND definition_kind = 'split'
        FOR UPDATE`, [orderRef]
    )).rows[0];
    if (!row) return null;
    if (!row.active) throw Object.assign(new Error("This split was retired. Reload Dispatch before editing it."), {
      status: 409, code: "DISPATCH_DERIVED_ORDER_RETIRED"
    });
    const details = {
      ...row.full_order.dispatchDetailsOverride,
      address: text(patch.address),
      expectedDeliveryDate: text(patch.expectedDeliveryDate ?? patch.expected_delivery_date),
      windowStart: text(patch.windowStart ?? patch.window_start),
      windowEnd: text(patch.windowEnd ?? patch.window_end)
    };
    if (patch.pickupAddress !== undefined || patch.pickup_address !== undefined) {
      details.pickupAddress = text(patch.pickupAddress ?? patch.pickup_address);
    }
    // Validate even when this split has not yet been materialized for delivery.
    const expectedDeliveryDate = details.expectedDeliveryDate || null;
    await query("SELECT $1::date", [expectedDeliveryDate]);
    const next = applySplitDispatchDetails({ ...row.full_order, dispatchDetailsOverride: details });
    const pickupAddress = next.pickupAddressOverride || "";
    await query(
      `UPDATE dispatch_global_order_splits
          SET full_order = $2::jsonb, card = $3::jsonb, search_text = $4, updated_at = now()
        WHERE split_ref = $1`,
      [row.split_ref, JSON.stringify(next), JSON.stringify(compactDispatchOrderCard(next)), dispatchOrderSearchText(next)]
    );
    await query(
      `UPDATE sales_orders SET dispatch_address = $2, dispatch_pickup_address = $3,
          expected_delivery_date = $4::date, dispatch_window_start = $5, dispatch_window_end = $6,
          dispatch_parse_source = 'manual-dispatch-details', dispatch_parsed_at = now()
        WHERE tranid = $1`,
      [row.split_ref, next.address, pickupAddress, expectedDeliveryDate,
        next.windowStart, next.windowEnd]
    );
    await query("DELETE FROM dispatch_order_catalog_entries WHERE lower(order_ref) = lower($1)", [row.split_ref]);
    await query(`UPDATE dispatch_order_catalog_state SET generation = generation + 1,
      catalog_count = (SELECT count(*)::int FROM dispatch_order_catalog_entries), updated_at = now()
      WHERE singleton = true`);
    await reconcileDispatchGlobalOrderSources({ orders: [next] });
    return { tranid: row.split_ref, dispatch_address: next.address,
      dispatch_pickup_address: pickupAddress, expected_delivery_date: expectedDeliveryDate,
      dispatch_window_start: next.windowStart, dispatch_window_end: next.windowEnd,
      source_table: "sales_orders", order_type: "sales_order", dispatch_details_override: details };
  });
}

function splitWithFreshSource(split = {}, source = {}, { activeBySource, allByRef } = {}) {
  const next = cloneOrder(stripTransitOverlays(split, allByRef));
  for (const field of SPLIT_LIVE_SOURCE_FIELDS) {
    if (Object.prototype.hasOwnProperty.call(source, field)) next[field] = cloneValue(source[field]);
  }
  next.id = orderIdentity(split);
  next.type = canonicalDerivedOrderType(split) || split.type;
  next.originalOrderId = splitParentRef(split);
  next.globalOrderDefinition = true;
  next.globalOrderDefinitionKind = text(split.globalOrderDefinitionKind || "split");
  return applyActiveTransitCoMetadata(applySplitDispatchDetails(next), activeBySource);
}

function groupWithFreshSources(group = {}, freshByRef = new Map(), { activeBySource, allByRef } = {}) {
  const base = stripTransitOverlays(group, allByRef);
  const refreshNested = (candidate = {}) => {
    const ref = orderIdentity(candidate).toLowerCase();
    const direct = freshByRef.get(ref);
    const candidateType = canonicalGroupedOrderType(candidate);
    const directType = canonicalGroupedOrderType(direct);
    // A grouped CO may retain the source SO/TO ref as its member identity.
    // NetSuite source refreshes may update the source lifecycle, but they must
    // not replace the local CO wrapper or turn one member into a mixed type.
    if (direct && !(candidateType === "CO" && directType !== "CO")) {
      return cloneOrder(direct);
    }
    const children = Array.isArray(candidate.childOrderDetails) ? candidate.childOrderDetails : [];
    if (!children.length) return candidate;
    return { ...candidate, childOrderDetails: children.map(refreshNested) };
  };
  const childRefs = (Array.isArray(base.childOrders) ? base.childOrders : [])
    .map(text)
    .filter(Boolean);
  const detailByRef = new Map((Array.isArray(base.childOrderDetails) ? base.childOrderDetails : [])
    .map((child) => [orderIdentity(child).toLowerCase(), child])
    .filter(([ref]) => ref));
  const childOrderDetails = childRefs.map((ref) => {
    const existing = detailByRef.get(ref.toLowerCase());
    if (existing) return refreshNested(existing);
    return freshByRef.get(ref.toLowerCase()) || null;
  }).filter(Boolean).map(cloneOrder);
  let next = childOrderDetails.length === childRefs.length
    ? aggregateGlobalGroup(base, childOrderDetails)
    : {
        ...base,
        childOrderDetails: (Array.isArray(base.childOrderDetails) ? base.childOrderDetails : []).map(refreshNested)
      };
  const firstChild = childOrderDetails[0];
  if (firstChild) {
    for (const field of [
      "netsuiteStatus", "netsuiteStatusText", "fulfillmentStatus",
      "netsuiteActive", "operatorStatus", "localYardOrderStatus"
    ]) {
      if (Object.prototype.hasOwnProperty.call(firstChild, field)) next[field] = cloneValue(firstChild[field]);
    }
  }
  next.globalGroupDefinition = true;
  return applyActiveTransitCoMetadata(next, activeBySource);
}

export async function reconcileDispatchGlobalOrderSources({ orders = [] } = {}) {
  const sourceByRef = new Map((Array.isArray(orders) ? orders : [])
    .filter(isNetSuiteDispatchSourceOrder)
    .map((order) => [orderIdentity(order).toLowerCase(), netSuiteDispatchSourceSnapshot(order)])
    .filter(([ref]) => ref));
  if (!sourceByRef.size) return { updated: 0, groups: [], splits: [] };
  return withTransaction(async () => {
    const sourceRefs = [...sourceByRef.keys()].sort();
    for (const sourceRef of sourceRefs) {
      await query(
        "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
        [`dispatch-global-source-refresh:${sourceRef}`]
      );
    }
    const transitState = await dispatchTransitCoState();
    const freshByRef = new Map(sourceByRef);
    const updatedSplits = [];
    const splitRows = await query(
      `SELECT split_ref, parent_order_ref, full_order, eligible
         FROM dispatch_global_order_splits
        WHERE active = true
          AND lower(parent_order_ref) = ANY($1::text[])
        ORDER BY lower(split_ref)
        FOR UPDATE`,
      [sourceRefs]
    );
    for (const row of splitRows.rows) {
      const source = sourceByRef.get(text(row.parent_order_ref).toLowerCase());
      if (!source) continue;
      const next = splitWithFreshSource(row.full_order || {}, source, transitState);
      const eligible = source.eligible !== false && source.netsuiteActive !== false;
      freshByRef.set(text(row.split_ref).toLowerCase(), next);
      if (JSON.stringify(next) === JSON.stringify(row.full_order || {}) && eligible === row.eligible) continue;
      await query(
        `UPDATE dispatch_global_order_splits
            SET full_order = $2::jsonb,
                card = $3::jsonb,
                search_text = $4,
                eligible = $5,
                updated_at = now()
          WHERE split_ref = $1`,
        [
          row.split_ref,
          JSON.stringify(next),
          JSON.stringify(compactDispatchOrderCard(next)),
          dispatchOrderSearchText(next),
          eligible
        ]
      );
      updatedSplits.push(text(row.split_ref));
    }

    const updatedGroups = [];
    const refreshRefs = [...freshByRef.keys()];
    const groupRows = await query(
      `SELECT global_group.group_ref, global_group.full_order,
              global_group.eligible
         FROM dispatch_global_order_groups global_group
        WHERE global_group.active = true
          AND EXISTS (
            SELECT 1
              FROM dispatch_global_order_group_members member
             WHERE member.group_ref = global_group.group_ref
               AND lower(member.member_order_ref) = ANY($1::text[])
          )
        ORDER BY lower(global_group.group_ref)
        FOR UPDATE OF global_group`,
      [refreshRefs]
    );
    for (const row of groupRows.rows) {
      const next = groupWithFreshSources(row.full_order || {}, freshByRef, transitState);
      const childDetails = Array.isArray(next.childOrderDetails) ? next.childOrderDetails : [];
      const eligible = childDetails.every((child) => child?.eligible !== false && child?.netsuiteActive !== false);
      freshByRef.set(text(row.group_ref).toLowerCase(), next);
      if (JSON.stringify(next) === JSON.stringify(row.full_order || {}) && eligible === row.eligible) continue;
      await query(
        `UPDATE dispatch_global_order_groups
            SET full_order = $2::jsonb,
                card = $3::jsonb,
                search_text = $4,
                eligible = $5,
                updated_at = now()
          WHERE group_ref = $1`,
        [
          row.group_ref,
          JSON.stringify(next),
          JSON.stringify(compactDispatchOrderCard(next)),
          dispatchOrderSearchText(next),
          eligible
        ]
      );
      updatedGroups.push(text(row.group_ref));
    }

    const updatedRefs = [...new Set([...updatedSplits, ...updatedGroups])];
    if (updatedRefs.length) {
      await query(
        `DELETE FROM dispatch_order_catalog_entries
          WHERE lower(order_ref) = ANY($1::text[])`,
        [updatedRefs.map((ref) => ref.toLowerCase())]
      );
      await query(
        `UPDATE dispatch_order_catalog_state
            SET generation = generation + 1,
                catalog_count = (SELECT count(*)::int FROM dispatch_order_catalog_entries),
                updated_at = now()
          WHERE singleton = true`
      );
    }
    return {
      updated: updatedRefs.length,
      groups: updatedGroups,
      splits: updatedSplits
    };
  });
}

function withoutRetiredGlobalOrderRefs(plan = {}, retiredRefs = new Set()) {
  if (!retiredRefs.size) return plan;
  const keepRef = (value) => !retiredRefs.has(text(value).toLowerCase());
  return {
    ...plan,
    orders: (Array.isArray(plan.orders) ? plan.orders : [])
      .filter((order) => keepRef(orderIdentity(order))),
    trucks: (Array.isArray(plan.trucks) ? plan.trucks : []).map((truck) => ({
      ...truck,
      loads: (Array.isArray(truck?.loads) ? truck.loads : []).map((load) => ({
        ...load,
        stops: (Array.isArray(load?.stops) ? load.stops : [])
          .filter((stop) => keepRef(stop?.orderId || stop?.orderRef))
      }))
    }))
  };
}

function withCanonicalGlobalOrderRefs(plan = {}, canonicalByRef = new Map()) {
  if (!canonicalByRef.size) return plan;
  const canonicalRef = (value) => canonicalByRef.get(text(value).toLowerCase()) || text(value);
  return {
    ...plan,
    orders: (Array.isArray(plan.orders) ? plan.orders : []).map((order) => {
      const currentRef = orderIdentity(order);
      const nextRef = canonicalRef(currentRef);
      return currentRef && nextRef !== currentRef ? { ...order, id: nextRef } : order;
    }),
    trucks: (Array.isArray(plan.trucks) ? plan.trucks : []).map((truck) => ({
      ...truck,
      loads: (Array.isArray(truck?.loads) ? truck.loads : []).map((load) => ({
        ...load,
        stops: (Array.isArray(load?.stops) ? load.stops : []).map((stop) => {
          const currentRef = text(stop?.orderId || stop?.orderRef);
          const nextRef = canonicalRef(currentRef);
          if (!currentRef || nextRef === currentRef) return stop;
          return Object.prototype.hasOwnProperty.call(stop || {}, "orderId")
            ? { ...stop, orderId: nextRef }
            : { ...stop, orderRef: nextRef };
        })
      }))
    }))
  };
}

export async function reconcileDispatchPlanGlobalOrderDefinitions(plan, {
  reactivatedGlobalOrderRefs = [],
  rejectRetiredGlobalOrderRefs = false
} = {}) {
  if (!plan) return null;
  const refs = [...new Set([
    ...(Array.isArray(plan.orders) ? plan.orders : [])
      .map((order) => orderIdentity(order).toLowerCase()),
    ...(Array.isArray(plan.trucks) ? plan.trucks : [])
      .flatMap((truck) => Array.isArray(truck?.loads) ? truck.loads : [])
      .flatMap((load) => Array.isArray(load?.stops) ? load.stops : [])
      .map((stop) => text(stop?.orderId || stop?.orderRef).toLowerCase())
  ].filter(Boolean))];
  if (!refs.length) return plan;
  const definitions = await query(
    `SELECT definition.order_ref, definition.full_order, definition.active,
            definition.definition_kind
       FROM (
         SELECT group_ref AS order_ref, CASE WHEN active THEN full_order ELSE '{}'::jsonb END AS full_order,
                active, 'group'::text AS definition_kind
           FROM dispatch_global_order_groups
          WHERE lower(group_ref) = ANY($1::text[])
         UNION ALL
         SELECT split_ref AS order_ref, CASE WHEN active THEN full_order ELSE '{}'::jsonb END AS full_order,
                active, definition_kind
           FROM dispatch_global_order_splits
          WHERE lower(split_ref) = ANY($1::text[])
       ) definition`,
    [refs]
  );
  if (!definitions.rowCount) return plan;
  const byRef = new Map();
  const canonicalByRef = new Map();
  const retiredRefs = new Set();
  for (const row of definitions.rows) {
    const ref = text(row.order_ref).toLowerCase();
    if (!ref) continue;
    canonicalByRef.set(ref, text(row.order_ref));
    if (row.active === true) byRef.set(ref, row.full_order || {});
    else retiredRefs.add(ref);
  }
  for (const ref of byRef.keys()) retiredRefs.delete(ref);
  const allowedReactivations = new Set((Array.isArray(reactivatedGlobalOrderRefs)
    ? reactivatedGlobalOrderRefs
    : [])
    .map((ref) => text(ref).toLowerCase())
    .filter(Boolean));
  const blockedRetiredRefs = new Set([...retiredRefs]
    .filter((ref) => !allowedReactivations.has(ref)));
  if (rejectRetiredGlobalOrderRefs && blockedRetiredRefs.size) {
    const conflicts = definitions.rows
      .filter((row) => row.active !== true && blockedRetiredRefs.has(text(row.order_ref).toLowerCase()))
      .map((row) => ({
        orderRef: text(row.order_ref),
        definitionKind: text(row.definition_kind)
      }));
    const refs = [...new Set(conflicts.map((conflict) => conflict.orderRef).filter(Boolean))];
    throw Object.assign(
      new Error(`Reload this Dispatch plan before saving. Retired derived order(s) cannot be restored by a stale snapshot: ${refs.join(", ")}.`),
      {
        status: 409,
        code: "DISPATCH_DERIVED_ORDER_RETIRED",
        retiredOrderRefs: refs,
        conflicts
      }
    );
  }
  const visiblePlan = withCanonicalGlobalOrderRefs(
    withoutRetiredGlobalOrderRefs(plan, blockedRetiredRefs),
    canonicalByRef
  );
  return {
    ...visiblePlan,
    orders: (visiblePlan.orders || []).map((order) => {
      const current = byRef.get(orderIdentity(order).toLowerCase());
      if (!current) return order;
      const reconciled = cloneOrder(order);
      for (const field of PLAN_LIVE_DEFINITION_FIELDS) {
        if (Object.prototype.hasOwnProperty.call(current, field)) {
          reconciled[field] = cloneValue(current[field]);
        } else if ([
          "transitCo", "transitOriginalPickupLocations", "transitOriginalSourceYard", "dispatchDetailsOverride"
        ].includes(field)) {
          delete reconciled[field];
        }
      }
      return reconciled;
    })
  };
}

export async function removeDispatchGlobalGroupedMember(memberOrderRef = "") {
  const target = text(memberOrderRef);
  if (!target) return { updated: [], deactivated: [] };
  return withTransaction(async () => {
    const candidates = await query(
      `SELECT global_group.group_ref, global_group.full_order
         FROM dispatch_global_order_groups global_group
         JOIN dispatch_global_order_group_members member
           ON member.group_ref = global_group.group_ref
        WHERE global_group.active = true
          AND member.hides_member = true
          AND lower(member.member_order_ref) = lower($1)
        ORDER BY lower(global_group.group_ref)
        FOR UPDATE OF global_group`,
      [target]
    );
    const updated = [];
    const deactivated = [];
    for (const row of candidates.rows) {
      const current = row.full_order || {};
      const listed = (Array.isArray(current.childOrders) ? current.childOrders : [])
        .map(text)
        .filter((ref) => ref && ref.toLowerCase() !== target.toLowerCase());
      const detailByRef = new Map((Array.isArray(current.childOrderDetails) ? current.childOrderDetails : [])
        .map((child) => [text(child?.id).toLowerCase(), child])
        .filter(([ref]) => ref));
      const retainedDetails = listed.map((ref) => detailByRef.get(ref.toLowerCase())).filter(Boolean);
      if (!listed.length) {
        await query(
          `UPDATE dispatch_global_order_groups
              SET active = false, updated_at = now()
            WHERE group_ref = $1`,
          [row.group_ref]
        );
        deactivated.push(text(row.group_ref));
        continue;
      }
      const next = retainedDetails.length === listed.length
        ? aggregateGlobalGroup(current, retainedDetails)
        : {
            ...current,
            childOrders: listed,
            childOrderDetails: retainedDetails,
            groupAliases: (Array.isArray(current.groupAliases) ? current.groupAliases : [])
              .filter((ref) => text(ref).toLowerCase() !== target.toLowerCase())
          };
      await query(
        `UPDATE dispatch_global_order_groups
            SET full_order = $2::jsonb,
                card = $3::jsonb,
                search_text = $4,
                updated_at = now()
          WHERE group_ref = $1`,
        [
          row.group_ref,
          JSON.stringify(next),
          JSON.stringify(compactDispatchOrderCard(next)),
          dispatchOrderSearchText(next)
        ]
      );
      await query(
        "DELETE FROM dispatch_global_order_group_members WHERE group_ref = $1",
        [row.group_ref]
      );
      const members = childOrderMembers(next, canonicalGroupedOrderType(next));
      if (members.length) {
        await query(
          `INSERT INTO dispatch_global_order_group_members (
             group_ref, member_order_ref, position, hides_member
           )
           SELECT $1, source.member_order_ref, source.position, source.hides_member
             FROM jsonb_to_recordset($2::jsonb) AS source(
               member_order_ref text, position integer, hides_member boolean
             )`,
          [row.group_ref, JSON.stringify(members.map((member, position) => ({
            member_order_ref: member.memberOrderRef,
            position,
            hides_member: member.hidesMember
          })))]
        );
      }
      updated.push(text(row.group_ref));
    }
    if (updated.length || deactivated.length) {
      await query(
        `UPDATE dispatch_order_catalog_state
            SET generation = generation + 1,
                updated_at = now()
          WHERE singleton = true`
      );
    }
    return { updated, deactivated };
  });
}

export async function deactivateDispatchGlobalOrderDefinitions(orderRefs = []) {
  const refs = [...new Set((Array.isArray(orderRefs) ? orderRefs : [])
    .map((ref) => text(ref).toLowerCase())
    .filter(Boolean))];
  if (!refs.length) return { groups: [], splits: [] };
  return withTransaction(async () => {
    await lockDispatchGlobalOrderDefinitionRefs(refs);
    const groups = await query(
      `UPDATE dispatch_global_order_groups
          SET active = false,
              updated_at = now()
        WHERE active = true
          AND lower(group_ref) = ANY($1::text[])
        RETURNING group_ref`,
      [refs]
    );
    const splits = await query(
      `UPDATE dispatch_global_order_splits
          SET active = false,
              updated_at = now()
        WHERE active = true
          AND lower(split_ref) = ANY($1::text[])
        RETURNING split_ref`,
      [refs]
    );
    const catalog = await query(
      `DELETE FROM dispatch_order_catalog_entries catalog
        WHERE lower(catalog.order_ref) = ANY($1::text[])
          AND (
            EXISTS (
              SELECT 1
                FROM dispatch_global_order_groups global_group
               WHERE lower(global_group.group_ref) = lower(catalog.order_ref)
            )
            OR EXISTS (
              SELECT 1
                FROM dispatch_global_order_splits global_split
               WHERE lower(global_split.split_ref) = lower(catalog.order_ref)
            )
          )
        RETURNING catalog.order_ref`,
      [refs]
    );
    const assignments = await query(
      `DELETE FROM dispatch_plan_order_assignments assignment
        WHERE lower(assignment.order_ref) = ANY($1::text[])
           OR lower(assignment.planned_order_ref) = ANY($1::text[])
        RETURNING assignment.plan_id`,
      [refs]
    );
    const relations = await query(
      `DELETE FROM dispatch_order_relation_edges relation
        WHERE lower(relation.owner_ref) = ANY($1::text[])
        RETURNING relation.plan_id`,
      [refs]
    );
    if (groups.rowCount || splits.rowCount || catalog.rowCount || assignments.rowCount || relations.rowCount) {
      await query(
        `UPDATE dispatch_order_catalog_state
            SET generation = generation + 1,
                catalog_count = (SELECT count(*)::int FROM dispatch_order_catalog_entries),
                updated_at = now()
          WHERE singleton = true`
      );
    }
    return {
      groups: groups.rows.map((row) => text(row.group_ref)),
      splits: splits.rows.map((row) => text(row.split_ref))
    };
  });
}

function projectGroups(plan = {}) {
  const planDate = dateOnly(plan.planDate || plan.plan_date);
  if (!plan.id || !planDate || text(plan.status).toLowerCase() === "cancelled") return [];
  const groups = [];
  for (const order of plan.orders || []) {
    if (!isGroupedDispatchOrder(order)) continue;
    const orderType = canonicalGroupedOrderType(order);
    if (!["SO", "TO"].includes(orderType)) continue;
    const groupRef = String(order.id || "").trim();
    if (!groupRef) continue;
    const memberRefs = childOrderRefs(order);
    const assignment = findGroupAssignment(plan, groupRef);
    if (!memberRefs.length || !assignment) continue;
    groups.push({
      groupRef,
      planId: Number(plan.id),
      planDate,
      orderType: orderType === "TO" ? "transfer_order" : "sales_order",
      memberRefs,
      ...assignment
    });
  }
  return groups;
}

async function lockDispatchGlobalOrderDefinitionRefs(orderRefs = []) {
  const refs = [...new Set((Array.isArray(orderRefs) ? orderRefs : [])
    .map((ref) => text(ref).toLowerCase())
    .filter(Boolean))].sort();
  for (const ref of refs) {
    await query(
      "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
      [`dispatch-global-order-definition:${ref}`]
    );
  }
}

async function assertNoGroupedSplitParents(plan) {
  const parents = [...new Set((plan.orders || []).map(splitParentRef).filter(Boolean))];
  if (!parents.length) return;
  const stored = await query(`SELECT group_ref FROM dispatch_global_order_groups WHERE group_ref=ANY($1::text[])`, [parents]);
  const local = (plan.orders || []).some(order => parents.includes(orderIdentity(order)) && isGroupedDispatchOrder(order));
  if (stored.rowCount || local) {
    throw Object.assign(new Error("Ungroup first, then split the child order."), {
      status: 409, code: "DISPATCH_GROUP_SPLIT_UNSUPPORTED"
    });
  }
}

async function syncDispatchDeliveryGroupsFromPlanInTransaction(plan = {}, {
  reactivatedGlobalOrderRefs = [],
  rejectRetiredGlobalOrderRefs = false
} = {}) {
  const planId = Number(plan.id);
  if (!Number.isInteger(planId)) return { groups: 0, members: 0 };
  await assertNoGroupedSplitParents(plan);
  const allowedReactivations = new Set((Array.isArray(reactivatedGlobalOrderRefs)
    ? reactivatedGlobalOrderRefs
    : [])
    .map((ref) => text(ref).toLowerCase())
    .filter(Boolean));
  const structuralRefs = [...new Set((Array.isArray(plan.orders) ? plan.orders : [])
    .filter((order) => isGroupedDispatchOrder(order) || isGlobalDerivedOrder(order))
    .map((order) => orderIdentity(order).toLowerCase())
    .filter(Boolean))];
  await lockDispatchGlobalOrderDefinitionRefs(structuralRefs);
  let definitions = { rows: [], rowCount: 0 };
  if (structuralRefs.length) {
    definitions = await query(
      `SELECT group_ref AS order_ref, 'group'::text AS definition_kind, active
         FROM dispatch_global_order_groups
        WHERE lower(group_ref) = ANY($1::text[])
       UNION ALL
       SELECT split_ref AS order_ref, definition_kind, active
         FROM dispatch_global_order_splits
        WHERE lower(split_ref) = ANY($1::text[])
       ORDER BY order_ref`,
      [structuralRefs]
    );
    const blocked = definitions.rows.filter((row) => (
      row.active !== true
      && !allowedReactivations.has(text(row.order_ref).toLowerCase())
    ));
    if (rejectRetiredGlobalOrderRefs && blocked.length) {
      const refs = blocked.map((row) => text(row.order_ref)).filter(Boolean);
      throw Object.assign(
        new Error(`Reload this Dispatch plan before saving. Retired derived order(s) cannot be restored by a stale snapshot: ${refs.join(", ")}.`),
        {
          status: 409,
          code: "DISPATCH_DERIVED_ORDER_RETIRED",
          retiredOrderRefs: refs,
          conflicts: blocked.map((row) => ({
            orderRef: text(row.order_ref),
            definitionKind: text(row.definition_kind)
          }))
        }
      );
    }
  }
  const retiredRefs = new Set(definitions.rows
    .filter((row) => row.active !== true && !allowedReactivations.has(text(row.order_ref).toLowerCase()))
    .map((row) => text(row.order_ref).toLowerCase())
    .filter(Boolean));
  const canonicalByRef = new Map(definitions.rows
    .map((row) => [text(row.order_ref).toLowerCase(), text(row.order_ref)])
    .filter(([key, value]) => key && value));
  const effectivePlan = withCanonicalGlobalOrderRefs(
    withoutRetiredGlobalOrderRefs(plan, retiredRefs),
    canonicalByRef
  );
  const globalGroups = await syncDispatchGlobalOrderGroupsFromPlan(effectivePlan);
  const globalSplits = await syncDispatchGlobalOrderSplitsFromPlan(effectivePlan);
  const groups = projectGroups(effectivePlan);

  await query(
    `UPDATE dispatch_delivery_groups
        SET active = false,
            updated_at = now()
      WHERE plan_id = $1`,
    [planId]
  );
  if (!groups.length) return { groups: 0, members: 0, globalGroups, globalSplits };

  await query(
    `INSERT INTO dispatch_delivery_groups (
       group_ref, plan_id, plan_date, order_type, truck_plate, load_name,
       parking_spot, active, updated_at
     )
     SELECT value->>'groupRef',
            (value->>'planId')::bigint,
            (value->>'planDate')::date,
            value->>'orderType',
            COALESCE(value->>'truckPlate', ''),
            COALESCE(value->>'loadName', ''),
            COALESCE(value->>'parkingSpot', ''),
            true,
            now()
       FROM jsonb_array_elements($1::jsonb) AS projected(value)
     ON CONFLICT (group_ref) DO UPDATE
       SET plan_id = EXCLUDED.plan_id,
           plan_date = EXCLUDED.plan_date,
           order_type = EXCLUDED.order_type,
           truck_plate = EXCLUDED.truck_plate,
           load_name = EXCLUDED.load_name,
           parking_spot = EXCLUDED.parking_spot,
           active = true,
           updated_at = now()`,
    [JSON.stringify(groups)]
  );

  const groupRefs = groups.map((group) => group.groupRef);
  await query("DELETE FROM dispatch_delivery_group_members WHERE group_ref = ANY($1::text[])", [groupRefs]);
  const members = groups.flatMap((group) => group.memberRefs.map((memberOrderRef, position) => ({
    groupRef: group.groupRef,
    memberOrderRef,
    position
  })));
  await query(
    `INSERT INTO dispatch_delivery_group_members (group_ref, member_order_ref, position)
     SELECT value->>'groupRef', value->>'memberOrderRef', (value->>'position')::integer
       FROM jsonb_array_elements($1::jsonb) AS projected(value)
     ON CONFLICT (group_ref, member_order_ref) DO UPDATE
       SET position = EXCLUDED.position`,
    [JSON.stringify(members)]
  );
  return { groups: groups.length, members: members.length, globalGroups, globalSplits };
}

export async function syncDispatchDeliveryGroupsFromPlan(plan = {}, options = {}) {
  return withTransaction(() => syncDispatchDeliveryGroupsFromPlanInTransaction(plan, options));
}

function mapGroup(row) {
  if (!row) return null;
  return {
    id: row.group_ref,
    type: row.order_type === "transfer_order" ? "TO" : "SO",
    orderType: row.order_type,
    childRefs: Array.isArray(row.child_refs) ? row.child_refs : [],
    planId: row.plan_id,
    planDate: dateOnly(row.plan_date),
    truckPlate: row.truck_plate || "",
    loadName: row.load_name || "",
    parkingSpot: row.parking_spot || ""
  };
}

export async function listDispatchDeliveryGroups({ orderType = "sales_order", includePast = false } = {}) {
  const result = await query(
    `SELECT g.*,
            COALESCE(jsonb_agg(m.member_order_ref ORDER BY m.position)
              FILTER (WHERE m.member_order_ref IS NOT NULL), '[]'::jsonb) AS child_refs
       FROM dispatch_delivery_groups g
       LEFT JOIN dispatch_delivery_group_members m ON m.group_ref = g.group_ref
      WHERE g.active = true
        AND g.order_type = $1
        ${includePast ? "" : "AND g.plan_date >= CURRENT_DATE"}
      GROUP BY g.group_ref
      ORDER BY g.plan_date DESC, g.updated_at DESC, g.group_ref`,
    [orderType]
  );
  return result.rows.map(mapGroup);
}

export async function getDispatchDeliveryGroup(groupRef) {
  const result = await query(
    `SELECT g.*,
            COALESCE(jsonb_agg(m.member_order_ref ORDER BY m.position)
              FILTER (WHERE m.member_order_ref IS NOT NULL), '[]'::jsonb) AS child_refs
       FROM dispatch_delivery_groups g
       LEFT JOIN dispatch_delivery_group_members m ON m.group_ref = g.group_ref
      WHERE g.group_ref = $1
        AND g.active = true
      GROUP BY g.group_ref
      LIMIT 1`,
    [String(groupRef || "").trim()]
  );
  return mapGroup(result.rows[0]);
}

export async function rebuildDispatchDeliveryGroups() {
  return withTransaction(async () => {
    await query("UPDATE dispatch_delivery_groups SET active = false, updated_at = now() WHERE active = true");
    const result = await query(
      `SELECT p.id, p.plan_date::text AS plan_date, p.status, p.revision,
              s.orders, s.trucks
         FROM dispatch_plans p
         JOIN dispatch_plan_snapshots s ON s.plan_id = p.id
        ORDER BY p.updated_at, p.id`
    );
    let groupCount = 0;
    let memberCount = 0;
    for (const row of result.rows) {
      const synced = await syncDispatchDeliveryGroupsFromPlan({
        id: row.id,
        planDate: row.plan_date,
        status: row.status,
        revision: Number(row.revision || 0),
        orders: row.orders || [],
        trucks: row.trucks || []
      });
      groupCount += synced.groups;
      memberCount += synced.members;
    }
    return { plans: result.rowCount, groups: groupCount, members: memberCount };
  });
}
